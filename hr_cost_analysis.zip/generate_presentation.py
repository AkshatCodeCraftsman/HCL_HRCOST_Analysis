"""
generate_presentation.py - Generates Professional 16:9 PowerPoint Slide Deck
HCL Final Submission: HR Cost Analysis & Strategic Workforce Optimization System
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "HCL_HR_Cost_Analysis_Presentation.pptx")

# Color Palette (Tailwind Inspired)
BG_DARK = RGBColor(15, 23, 42)       # Slate 900
CARD_BG = RGBColor(30, 41, 59)      # Slate 800
BORDER_COLOR = RGBColor(71, 85, 105) # Slate 600
TEXT_WHITE = RGBColor(248, 250, 252) # Slate 50
TEXT_MUTED = RGBColor(148, 163, 184) # Slate 400
ACCENT_INDIGO = RGBColor(99, 102, 241) # Indigo 500
ACCENT_EMERALD = RGBColor(16, 185, 129) # Emerald 500
ACCENT_AMBER = RGBColor(245, 158, 11)  # Amber 500
ACCENT_CYAN = RGBColor(6, 182, 212)    # Cyan 500
ACCENT_ROSE = RGBColor(239, 68, 68)    # Rose 500

def create_slide(prs):
    """Creates a blank 16:9 slide with dark navy slate background."""
    blank_layout = prs.slide_layouts[6] # Blank
    slide = prs.slides.add_slide(blank_layout)
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = BG_DARK
    bg.line.fill.background()
    return slide

def add_header(slide, title_text, category_text="HCL FINAL PROJECT SUBMISSION"):
    """Adds standardized header with category pill badge and title."""
    # Category badge
    cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(8), Inches(0.35))
    tf_c = cat_box.text_frame
    tf_c.word_wrap = True
    p_c = tf_c.paragraphs[0]
    p_c.text = category_text.upper()
    p_c.font.size = Pt(10)
    p_c.font.bold = True
    p_c.font.color.rgb = ACCENT_INDIGO

    # Main Title
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.7), Inches(11.5), Inches(0.8))
    tf_t = title_box.text_frame
    tf_t.word_wrap = True
    p_t = tf_t.paragraphs[0]
    p_t.text = title_text
    p_t.font.size = Pt(22)
    p_t.font.bold = True
    p_t.font.color.rgb = TEXT_WHITE

def add_card(slide, left, top, width, height, title, value=None, body_lines=None, accent_color=ACCENT_INDIGO):
    """Draws a Tailwind-style card with top accent bar and typography."""
    # Card surface
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    card.fill.solid()
    card.fill.fore_color.rgb = CARD_BG
    card.line.color.rgb = BORDER_COLOR
    card.line.width = Pt(1)

    # Accent top border
    accent_bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, Inches(0.06))
    accent_bar.fill.solid()
    accent_bar.fill.fore_color.rgb = accent_color
    accent_bar.line.fill.background()

    # Content
    tb = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.12), width - Inches(0.4), height - Inches(0.25))
    tf = tb.text_frame
    tf.word_wrap = True

    # Title
    p0 = tf.paragraphs[0]
    p0.text = title.upper()
    p0.font.size = Pt(10)
    p0.font.bold = True
    p0.font.color.rgb = accent_color

    # Value callout (if provided)
    if value:
        p_val = tf.add_paragraph()
        p_val.text = value
        p_val.font.size = Pt(20)
        p_val.font.bold = True
        p_val.font.color.rgb = TEXT_WHITE

    # Body lines
    if body_lines:
        for line in body_lines:
            p = tf.add_paragraph()
            p.text = line
            p.font.size = Pt(11)
            p.font.color.rgb = TEXT_MUTED

def generate_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # ==========================================================
    # SLIDE 1: Title Slide
    # ==========================================================
    s1 = create_slide(prs)
    # Background accent glow box
    glow = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.8), Inches(11.733), Inches(4.0))
    glow.fill.solid()
    glow.fill.fore_color.rgb = CARD_BG
    glow.line.color.rgb = ACCENT_INDIGO
    glow.line.width = Pt(1.5)

    tb1 = s1.shapes.add_textbox(Inches(1.2), Inches(2.2), Inches(11.0), Inches(3.2))
    tf1 = tb1.text_frame
    tf1.word_wrap = True

    p0 = tf1.paragraphs[0]
    p0.text = "HCL FINAL TECHNICAL PROJECT SUBMISSION"
    p0.font.size = Pt(13)
    p0.font.bold = True
    p0.font.color.rgb = ACCENT_INDIGO

    p1 = tf1.add_paragraph()
    p1.text = "HR Cost Analysis & Strategic Optimization"
    p1.font.size = Pt(32)
    p1.font.bold = True
    p1.font.color.rgb = TEXT_WHITE

    p2 = tf1.add_paragraph()
    p2.text = "Enterprise Workforce Economics, Overtime Diagnostics, Attrition Forensics & Predictive Budgeting"
    p2.font.size = Pt(15)
    p2.font.color.rgb = ACCENT_CYAN

    p3 = tf1.add_paragraph()
    p3.text = "\nTech Stack: Python 3.12 | Streamlit | SQLite3 | Plotly | SciPy | Tailwind UI | pytest"
    p3.font.size = Pt(12)
    p3.font.color.rgb = TEXT_MUTED

    # ==========================================================
    # SLIDE 2: Executive Problem Statement & Context
    # ==========================================================
    s2 = create_slide(prs)
    add_header(s2, "Executive Context: The Workforce Cost Challenge at Scale")
    add_card(s2, Inches(0.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "1. Human Capital Burden",
             value="65% – 75%",
             body_lines=[
                 "\n• Human capital represents the largest operating expense in IT enterprises like HCL.",
                 "• Small percentage inefficiencies translate to multi-million dollar margin erosion.",
                 "• Direct payroll is only 60% of total cost—benefits and overtime account for the rest."
             ], accent_color=ACCENT_INDIGO)

    add_card(s2, Inches(4.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "2. The Hidden Turnover Drain",
             value="$3.8M Lost",
             body_lines=[
                 "\n• Traditional accounting fails to track full-lifecycle attrition replacement costs.",
                 "• Offboarding admin, vacancy productivity voids, recruitment fees, and ramp-up losses.",
                 "• Average cost per departed employee exceeds $26,000 in specialized engineering roles."
             ], accent_color=ACCENT_ROSE)

    add_card(s2, Inches(8.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "3. The Solution Approach",
             value="Data-Driven ROI",
             body_lines=[
                 "\n• Unified relational SQLite data model consolidating 1,000 workforce records.",
                 "• Interactive Plotly visual diagnostics with Tailwind UI dark styling.",
                 "• Real-time what-if scenario budgeting and inferential hypothesis testing lab."
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 3: System Architecture & Technical Stack
    # ==========================================================
    s3 = create_slide(prs)
    add_header(s3, "Enterprise System Architecture & Technology Stack")
    add_card(s3, Inches(0.8), Inches(1.8), Inches(2.7), Inches(5.0),
             "Frontend & UI",
             value="Streamlit",
             body_lines=[
                 "\n• Streamlit 1.35+ Reactive App",
                 "• Persistent sidebar view navigation",
                 "• Injected Tailwind-inspired CSS",
                 "• Dynamic filter notification pills",
                 "• Multi-tab analytics console"
             ], accent_color=ACCENT_INDIGO)

    add_card(s3, Inches(3.8), Inches(1.8), Inches(2.7), Inches(5.0),
             "Analytics Engine",
             value="SciPy & Plotly",
             body_lines=[
                 "\n• SciPy & Statsmodels",
                 "• Parametric & Shape Stats",
                 "• One-Way ANOVA & T-Test",
                 "• Chi-Square Independence",
                 "• Dark-mode Plotly Visuals"
             ], accent_color=ACCENT_CYAN)

    add_card(s3, Inches(6.8), Inches(1.8), Inches(2.7), Inches(5.0),
             "Data Persistence",
             value="SQLite3",
             body_lines=[
                 "\n• 7 Normalized tables",
                 "• PRAGMA Foreign Keys",
                 "• Indexed lookup columns",
                 "• In-memory @st.cache_data",
                 "• Safe read-only SQL editor"
             ], accent_color=ACCENT_AMBER)

    add_card(s3, Inches(9.8), Inches(1.8), Inches(2.7), Inches(5.0),
             "Quality & Cloud",
             value="pytest & Cloud",
             body_lines=[
                 "\n• 11 pytest unit tests",
                 "• 100% Passing test suite",
                 "• Streamlit Community Cloud",
                 "• Auto-bootstrap DB seeding",
                 "• Zero-configuration deploy"
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 4: Normalized Database Schema & Data Modeling
    # ==========================================================
    s4 = create_slide(prs)
    add_header(s4, "Normalized Relational Data Schema (7 Tables)")
    add_card(s4, Inches(0.8), Inches(1.8), Inches(5.6), Inches(2.3),
             "departments (1:N with employees)",
             body_lines=[
                 "• department_id (PK), department_name, cost_center_code (UK)",
                 "• headcount_target, annual_training_budget, annual_recruitment_budget",
                 "• Encompasses 8 major IT divisions (Software, Cloud, Data/AI, ERS, Cyber, etc.)"
             ], accent_color=ACCENT_INDIGO)

    add_card(s4, Inches(6.8), Inches(1.8), Inches(5.6), Inches(2.3),
             "employees (Central Entity - 1,000 Records)",
             body_lines=[
                 "• employee_id (PK), first_name, last_name, gender, age, education",
                 "• department_id (FK), job_role, job_level, location/state, employment_type",
                 "• tenure_years, performance_rating (1-5), is_attrited (0/1), flight_risk"
             ], accent_color=ACCENT_CYAN)

    add_card(s4, Inches(0.8), Inches(4.4), Inches(3.7), Inches(2.4),
             "compensation (1:1)",
             body_lines=[
                 "• base_salary, annual_bonus",
                 "• health_insurance, retirement, allowances",
                 "• overtime_hours, overtime_rate, total_cost"
             ], accent_color=ACCENT_EMERALD)

    add_card(s4, Inches(4.8), Inches(4.4), Inches(3.7), Inches(2.4),
             "talent_acq & training (1:1)",
             body_lines=[
                 "• channel, sourcing_cost, agency_fees",
                 "• time_to_hire_days, total_acquisition_cost",
                 "• courses_completed, training_hours, certs"
             ], accent_color=ACCENT_AMBER)

    add_card(s4, Inches(8.8), Inches(4.4), Inches(3.7), Inches(2.4),
             "turnover_costs (1:0..1)",
             body_lines=[
                 "• exit_interview_admin_cost, vacancy_loss",
                 "• replacement_recruitment_cost, rampup_loss",
                 "• total_attrition_cost ($3.8M aggregate)"
             ], accent_color=ACCENT_ROSE)

    # ==========================================================
    # SLIDE 5: Executive Dashboard & Core KPIs
    # ==========================================================
    s5 = create_slide(prs)
    add_header(s5, "Executive Workforce & HR Cost Command Center")
    # Metric cards row
    add_card(s5, Inches(0.8), Inches(1.8), Inches(2.2), Inches(1.8), "Total Headcount", value="1,000", body_lines=["Active: 855 | Leavers: 145"], accent_color=ACCENT_INDIGO)
    add_card(s5, Inches(3.2), Inches(1.8), Inches(2.2), Inches(1.8), "Total HR Spend", value="$112.8M", body_lines=["Full-load annual cost"], accent_color=ACCENT_EMERALD)
    add_card(s5, Inches(5.6), Inches(1.8), Inches(2.2), Inches(1.8), "Cost / Employee", value="$112,800", body_lines=["Median: $98,450"], accent_color=ACCENT_CYAN)
    add_card(s5, Inches(8.0), Inches(1.8), Inches(2.2), Inches(1.8), "Overtime Spend", value="$2.44M", body_lines=["3.4% of Base Payroll"], accent_color=ACCENT_AMBER)
    add_card(s5, Inches(10.4), Inches(1.8), Inches(2.2), Inches(1.8), "Attrition Loss", value="$3.81M", body_lines=["14.5% Turnover Rate"], accent_color=ACCENT_ROSE)

    # Lower explanatory cards
    add_card(s5, Inches(0.8), Inches(3.9), Inches(5.6), Inches(2.9),
             "Cost Composition Insights",
             body_lines=[
                 "• Base Payroll: 63.8% ($72.0M) represents the foundation of workforce spend.",
                 "• Benefits & Perks: 22.1% ($25.0M) includes health, retirement, and wellness.",
                 "• Overtime: 2.2% ($2.4M) concentrated heavily in Operations and Cloud Support.",
                 "• Talent Acquisition & L&D: 8.5% ($9.6M) invested in talent pipeline growth.",
                 "• Turnover Financial Loss: 3.4% ($3.8M) lost to avoidable employee exits."
             ], accent_color=ACCENT_CYAN)

    add_card(s5, Inches(6.8), Inches(3.9), Inches(5.6), Inches(2.9),
             "Human Capital ROI (HC ROI) Macro Trend",
             body_lines=[
                 "• Evaluates how effectively HR spend converts into enterprise revenue.",
                 "• FY2023: Revenue $142M | HR Spend $85.4M | HC ROI Ratio: 1.38",
                 "• FY2024: Revenue $161M | HR Spend $94.6M | HC ROI Ratio: 1.41",
                 "• FY2025: Revenue $184M | HR Spend $104.2M | HC ROI Ratio: 1.45",
                 "• FY2026: Revenue $205M | HR Spend $112.8M | HC ROI Ratio: 1.48 (Positive Trend)"
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 6: Compensation, Payroll & Overtime Diagnostics
    # ==========================================================
    s6 = create_slide(prs)
    add_header(s6, "Compensation Dispersion & Overtime Hotspots")
    add_card(s6, Inches(0.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "1. Salary Dispersion",
             value="Wide Variance",
             body_lines=[
                 "\n• Base Salary Range: $35,500 to $260,000+.",
                 "• Junior Tier: $48K - $68K (Median $56K).",
                 "• Mid-Level: $72K - $115K (Median $88K).",
                 "• Senior & Lead: $102K - $195K.",
                 "• Executive / Director: $190K - $260K.",
                 "• Onsite locations (New York, London) carry a 1.65x geographic index."
             ], accent_color=ACCENT_INDIGO)

    add_card(s6, Inches(4.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "2. Overtime Hotspots",
             value="High Concentration",
             body_lines=[
                 "\n• Overtime is severely skewed towards 2 divisions:",
                 "  - Digital Foundation (Cloud Support): 42.1 hrs/emp.",
                 "  - Digital Process Operations: 48.5 hrs/emp.",
                 "• 80% of all overtime incurred by Junior & Mid-level staff.",
                 "• Indicates operational shift imbalances and staffing bottlenecks during peak releases."
             ], accent_color=ACCENT_AMBER)

    add_card(s6, Inches(8.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "3. Pay Equity Audit",
             value="Welch's t-Test",
             body_lines=[
                 "\n• Formal two-sample statistical test:",
                 "  - Male Average Salary: $73,200",
                 "  - Female Average Salary: $70,800",
                 "  - Raw Gap: 3.3%",
                 "• P-value > 0.05 indicates no statistically significant bias after controlling for tenure and job level."
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 7: Turnover Dynamics & Replacement Cost Forensics
    # ==========================================================
    s7 = create_slide(prs)
    add_header(s7, "The Financial Anatomy of Employee Turnover")
    add_card(s7, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "The 4 Cost Drivers of Attrition (Waterfall Breakdown)",
             value="$3.81M Total Loss",
             body_lines=[
                 "\n1. Administrative Offboarding ($108.7K):",
                 "   - Exit interviews, legal clearance, asset recovery, payroll processing.",
                 "\n2. Lost Vacancy Productivity ($1.38M - 36.2%):",
                 "   - Open positions average 45-75 vacancy days with lost revenue.",
                 "\n3. Replacement Hiring & Agency Fees ($1.52M - 39.9%):",
                 "   - Sourcing, job ads, recruitment headhunter fees (15-20% of salary).",
                 "\n4. Ramp-Up Learning Curve Loss ($0.80M - 21.0%):",
                 "   - New hires operate at ~50% productivity during first 90 days of onboarding."
             ], accent_color=ACCENT_ROSE)

    add_card(s7, Inches(6.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "High Flight-Risk Critical Talent Watchlist",
             value="18 Key Personnel",
             body_lines=[
                 "\n• Identification Criteria:",
                 "   - Performance Rating >= 3.8 (Top Performer).",
                 "   - Flight Risk = 'High' (Market headhunter target / burnout).",
                 "   - Tenure > 2.5 years without recent role promotion.",
                 "\n• Financial Exposure:",
                 "   - Aggregate replacement liability: $785,000.",
                 "   - Average replacement cost per key individual: $43,600.",
                 "\n• Strategic Action:",
                 "   - Immediate retention package allocation ($500-$1,000/emp creates 4.5x ROI)."
             ], accent_color=ACCENT_AMBER)

    # ==========================================================
    # SLIDE 8: Talent Acquisition & Learning Development ROI
    # ==========================================================
    s8 = create_slide(prs)
    add_header(s8, "Talent Acquisition Efficiency & Learning ROI")
    add_card(s8, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Recruitment Channel Efficiency Matrix",
             body_lines=[
                 "• Direct / Employee Referral: Most cost-effective ($1,450/hire, 28 days to fill).",
                 "• Campus Placement: High volume, low unit cost ($1,850/hire, 31 days to fill).",
                 "• LinkedIn / Job Portals: Balanced channel ($2,450/hire, 42 days to fill).",
                 "• Recruitment Agencies: Highest cost ($14,200/hire, 48 days to fill).",
                 "\nRecommendation: Shift 25% of agency spend into internal employee referral bonuses to save $420,000 annually while reducing time-to-hire by 14 days."
             ], accent_color=ACCENT_CYAN)

    add_card(s8, Inches(6.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Learning & Development Impact (OLS Regression)",
             body_lines=[
                 "• Evaluates correlation between Training Hours and Skill Gap Reduction %.",
                 "• Regression Output: R² = 0.68 (Strong positive linear relationship).",
                 "• Key Takeaway: Employees completing > 45 hours of technical certifications display 28% higher performance ratings.",
                 "• Retention Impact: Employees enrolled in active upskilling programs exhibit 40% lower voluntary turnover in their subsequent 12 months.",
                 "\nUpskilling is self-funding through turnover avoidance."
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 9: Exploratory Data Analysis & Inferential Statistics
    # ==========================================================
    s9 = create_slide(prs)
    add_header(s9, "Exploratory Data Analysis & Inferential Statistics Lab")
    add_card(s9, Inches(0.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "1. Distribution Shapes",
             value="Non-Gaussian",
             body_lines=[
                 "\n• Base Salary Skewness: +0.82 (Moderately right-skewed).",
                 "• Overtime Kurtosis: +2.45 (Leptokurtic, heavy tails).",
                 "• IQR Spread: $38,500.",
                 "• Conclusion: Non-parametric metrics (Median, IQR) must accompany mean for compensation decisions."
             ], accent_color=ACCENT_INDIGO)

    add_card(s9, Inches(4.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "2. One-Way ANOVA",
             value="F = 42.18",
             body_lines=[
                 "\n• Null Hypothesis: Department mean salaries are equal.",
                 "• F-Statistic: 42.18, P-Value: < 0.0001.",
                 "• Decision: Reject H0.",
                 "• Finding: Data & AI and ERS exhibit statistically significant compensation premiums over Operations and Corporate Functions."
             ], accent_color=ACCENT_CYAN)

    add_card(s9, Inches(8.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "3. Chi-Square Test",
             value="Chi² = 28.45",
             body_lines=[
                 "\n• Null Hypothesis: Attrition is independent of department.",
                 "• Chi²: 28.45, P-Value: 0.0002, df: 7.",
                 "• Decision: Reject H0.",
                 "• Finding: Voluntary turnover is clustered significantly in Cloud Support and Operations due to on-call burnout."
             ], accent_color=ACCENT_AMBER)

    # ==========================================================
    # SLIDE 10: Interactive What-If Budget Scenario Simulator
    # ==========================================================
    s10 = create_slide(prs)
    add_header(s10, "Strategic What-If Budget Scenario Modeling")
    add_card(s10, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Policy Input Parameters Tested",
             body_lines=[
                 "1. Annual Merit Raise: 3.5% across active workforce ($2.52M investment).",
                 "2. Overtime Capping Target: -25% via workload balancing (-$610K savings).",
                 "3. Attrition Reduction Target: -20% turnover decrease (-$762K savings).",
                 "4. Targeted Retention Program: $450/emp allocated to flight risks ($384K investment).",
                 "5. Upskilling Fund Adjustment: +15% technical certifications ($184K investment).",
                 "\nNet Financial Outcome:",
                 "• Baseline Spend: $112.80M",
                 "• Simulated Spend: $114.52M (+$1.72M net variance)",
                 "• Net Retention Value Created: $378,000 net positive return!"
             ], accent_color=ACCENT_INDIGO)

    add_card(s10, Inches(6.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Strategic Takeaways for Leadership",
             body_lines=[
                 "• Funding Retention via Overtime Rationalization:",
                 "   - A 25% reduction in overtime leakage fully funds the enterprise retention and upskilling program.",
                 "\n• High Human Capital ROI:",
                 "   - Proactive retention programs generate an estimated 2.2x financial return through avoided replacement hiring and vacancy productivity void.",
                 "\n• Real-Time Slicing:",
                 "   - Enterprise leaders can simulate targeted scenarios per department or geography before committing fiscal budgets."
             ], accent_color=ACCENT_EMERALD)

    # ==========================================================
    # SLIDE 11: Testing, QA & Cloud Deployment
    # ==========================================================
    s11 = create_slide(prs)
    add_header(s11, "Software Engineering Rigor: Testing & Cloud Readiness")
    add_card(s11, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Automated pytest Test Suite (11 Tests)",
             value="100% Passing",
             body_lines=[
                 "\n• test_db.py (3 Tests):",
                 "   - Validates 7-table schema, 1,000 headcount integrity, and read-only SQL security.",
                 "\n• test_analytics.py (4 Tests):",
                 "   - Validates mathematical consistency of KPIs, department rollups, parametric stats, ANOVA, t-test, and Chi-square.",
                 "\n• test_simulator.py (4 Tests):",
                 "   - Verifies 0% change stability, merit raise scaling, overtime reduction arithmetic, and retention net ROI calculation."
             ], accent_color=ACCENT_EMERALD)

    add_card(s11, Inches(6.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Streamlit Community Cloud Deployment",
             value="Cloud Ready",
             body_lines=[
                 "\n• Zero-Configuration Self-Bootstrapping:",
                 "   - Automatically executes seed_data.py on cloud startup if SQLite database is absent.",
                 "\n• Headless Server Settings:",
                 "   - Configured in .streamlit/config.toml (CORS disabled, XSRF protection active, dark palette pre-set).",
                 "\n• Clean Dependency Tree:",
                 "   - Pinned in requirements.txt (streamlit, pandas, plotly, scipy, statsmodels, pytest)."
             ], accent_color=ACCENT_CYAN)

    # ==========================================================
    # SLIDE 12: Recommendations & Conclusion
    # ==========================================================
    s12 = create_slide(prs)
    add_header(s12, "Summary, Recommendations & Project Conclusion")
    add_card(s12, Inches(0.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "Rec 1: Overtime Rationalization",
             value="Save $610K",
             body_lines=[
                 "\n• Cap overtime in Cloud Support & Operations.",
                 "• Implement automated workload scheduling to prevent junior engineer burnout.",
                 "• Reallocate overtime savings directly into retention and wellness bonuses."
             ], accent_color=ACCENT_AMBER)

    add_card(s12, Inches(4.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "Rec 2: Proactive Retention",
             value="Save $760K",
             body_lines=[
                 "\n• Deploy retention packages ($450-$1,000) for the 18 high flight-risk top performers.",
                 "• Prevents $785K in vacancy and replacement agency costs.",
                 "• Delivers a net positive ROI of $378K."
             ], accent_color=ACCENT_EMERALD)

    add_card(s12, Inches(8.8), Inches(1.8), Inches(3.7), Inches(5.0),
             "Rec 3: Referral Maximization",
             value="Save $420K",
             body_lines=[
                 "\n• Transition 25% of agency sourcing to employee referral programs.",
                 "• Reduces average time-to-hire by 14 days.",
                 "• Doubles employee engagement and onboarding ramp-up speed."
             ], accent_color=ACCENT_CYAN)

    # Save presentation
    prs.save(OUTPUT_FILE)
    print(f"Presentation successfully created at: {OUTPUT_FILE}")

if __name__ == "__main__":
    generate_deck()
