# SOFTWARE REQUIREMENTS SPECIFICATION (SRS)
## HR Cost Analysis & Strategic Workforce Optimization System
### Final Project Submission — HCL Technologies
**Document Version:** 1.0  
**Standard:** IEEE Std 830-1998 Conforming  
**Prepared For:** HCL Final Technical Evaluation Committee  
**Authors:** HR Analytics & Engineering Project Team  

---

## 1. INTRODUCTION

### 1.1 Purpose
This Software Requirements Specification (SRS) document provides a formal, comprehensive specification of the requirements for the **HR Cost Analysis and Strategic Workforce Optimization System**. The application is designed to ingest, process, model, and visualize full-lifecycle human capital cost structures for large technology enterprises such as HCL Technologies. It details both functional and non-functional requirements, data entity models, system architectural design, and operational workflows.

### 1.2 Scope of the System
The HR Cost Analysis System is an enterprise analytical dashboard and decision-support system built using **Python, Streamlit, SQLite, Plotly, SciPy, and Tailwind UI styling principles**. It addresses the critical business challenge of workforce cost opacity by consolidating:
- Direct payroll and performance bonuses
- Employer-funded statutory and healthcare benefits
- Overtime expenditures and operational burn rates
- Talent acquisition sourcing and agency recruitment costs
- Learning and development investments vs. capability ROI
- Attrition forensics, vacancy productivity losses, and ramp-up replacement costs
- Predictive what-if scenario budgeting and policy modeling

### 1.3 Definitions, Acronyms, and Abbreviations
- **SRS:** Software Requirements Specification
- **TWC:** Total Workforce Cost (Base Salary + Benefits + Overtime + Talent Acquisition + Training + Turnover Loss)
- **HC ROI:** Human Capital Return on Investment = `(Annual Revenue - (Operating Expenses - HR Spend)) / HR Spend`
- **ACPE:** Average Cost Per Employee
- **OLS:** Ordinary Least Squares Linear Regression
- **ANOVA:** Analysis of Variance (parametric hypothesis test for $\ge 3$ groups)
- **IQR:** Interquartile Range ($Q_3 - Q_1$)
- **KDE:** Kernel Density Estimation
- **EDA:** Exploratory Data Analysis
- **PRAGMA:** SQLite execution directive (e.g., `PRAGMA foreign_keys = ON`)

---

## 2. OVERALL SYSTEM DESCRIPTION

### 2.1 Product Perspective
The system operates as an interactive analytical decision-support web application. It connects directly to an internal, self-bootstrapping SQLite relational data engine, caches processed subsets in memory via `@st.cache_data`, and delivers real-time reactive analytics through an asynchronous browser-based presentation layer.

```
+-------------------------------------------------------------------------+
|                         PRESENTATION LAYER                              |
|   Streamlit Framework | Tailwind UI Dark Theme | Interactive Plotly    |
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                      ANALYTICS & COMPUTATION ENGINE                     |
|  - Core KPI Engine (Full-load TWC, ACPE, Overtime %)                   |
|  - Inferential Statistics Lab (One-Way ANOVA, Welch's T-Test, Chi2)     |
|  - What-If Policy Simulation Engine (Merit Raises, OT Caps, Retention)  |
+-------------------------------------------------------------------------+
                                    |
                                    v
+-------------------------------------------------------------------------+
|                         DATA ACCESS LAYER                               |
|   SQLite3 Relational DB | PRAGMA Foreign Keys | In-Memory Data Caching  |
+-------------------------------------------------------------------------+
```

### 2.2 User Personas
1. **Chief Human Resources Officer (CHRO) & People Directors:** Require high-level executive KPIs, HC ROI trends, and strategic budget simulation.
2. **HR Financial Controllers & Cost Center Managers:** Require granular breakdown of overtime leakage, compensation dispersion, and departmental budget variances.
3. **Talent Acquisition & L&D Leads:** Require channel cost-efficiency matrices, time-to-hire benchmarks, and training ROI impact curves.
4. **Data Analysts & HR Business Partners (HRBPs):** Require univariate/multivariate EDA, hypothesis testing (pay equity, attrition dependency), and custom SQL execution.

---

## 3. SYSTEM ARCHITECTURE & TECH STACK

| Architecture Tier | Technology | Technical Purpose |
| :--- | :--- | :--- |
| **Runtime Environment** | Python 3.12+ | Core programming runtime providing high performance and typing support. |
| **Application Framework** | Streamlit 1.35+ | Reactive, state-driven UI framework with reactive re-rendering. |
| **Design System** | Tailwind-Inspired CSS | Slate-900 surface, Inter typography, gradient accent bars, and badge pills. |
| **Data Engine** | SQLite3 | ACID-compliant relational persistence with foreign keys and index structures. |
| **Data Wrangling** | Pandas & NumPy | High-speed vectorized data aggregation, slicing, and matrix computations. |
| **Visual Analytics** | Plotly Express & Graph Objects | Dark-mode interactive charts with hover tooltips and dynamic callbacks. |
| **Mathematical Engine** | SciPy (stats) & Statsmodels | Parametric/non-parametric distributions, ANOVA, Welch's t-test, Chi-square. |
| **Testing & QA** | pytest 8.0+ | Automated unit test suite verifying schema, arithmetic, and simulations. |

---

## 4. DATA MODEL & ENTITY-RELATIONSHIP (ER) DIAGRAM

### 4.1 Mermaid Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : "allocates"
    EMPLOYEES ||--|| COMPENSATION : "compensated_via"
    EMPLOYEES ||--|| TALENT_ACQUISITION : "recruited_through"
    EMPLOYEES ||--|| LEARNING_DEVELOPMENT : "participates_in"
    EMPLOYEES ||--o| TURNOVER_COSTS : "generates_on_departure"

    DEPARTMENTS {
        string department_id PK "e.g. DEP-01"
        string department_name "Business Division Name"
        string cost_center_code UK "Unique Cost Center Code"
        int headcount_target "Allocated Headcount"
        float annual_training_budget "L&D Budget Allocation"
        float annual_recruitment_budget "Talent Acquisition Budget"
    }

    EMPLOYEES {
        string employee_id PK "e.g. HCL-0001"
        string first_name "Given Name"
        string last_name "Surname"
        string gender "Male, Female, Non-Binary"
        int age "Age in Years"
        string education "Degree Level"
        string department_id FK "References DEPARTMENTS"
        string job_role "Organizational Title"
        string job_level "Junior to Director"
        string location "Geographic Office/State"
        string employment_type "Full-Time, Contract, Part-Time"
        date hire_date "Employment Commencement Date"
        float tenure_years "Service Duration"
        float performance_rating "Score 1.0 to 5.0"
        int is_attrited "0 for Active, 1 for Departed"
        date attrition_date "Departure Date (Nullable)"
        string attrition_reason "Exit Interview Rationale"
        string flight_risk "Low, Medium, High"
    }

    COMPENSATION {
        int comp_id PK "Auto Increment"
        string employee_id FK "References EMPLOYEES"
        float base_salary "Annual Base Salary ($)"
        float annual_bonus "Variable Performance Bonus ($)"
        float health_insurance_cost "Employer Health Coverage ($)"
        float retirement_benefits_cost "401k / EPF Contribution ($)"
        float allowances "Travel, Remote, Wellness ($)"
        float annual_overtime_hours "Overtime Hours Accumulated"
        float overtime_hourly_rate "Overtime Rate (1.5x Base)"
        float total_overtime_cost "Overtime Total Expenditure ($)"
        float total_direct_comp "Base + Bonus + Overtime ($)"
        float total_benefits_cost "Insurance + Benefits + Allowances ($)"
        float total_annual_cost "Direct Comp + Total Benefits ($)"
    }

    TALENT_ACQUISITION {
        int recruitment_id PK "Auto Increment"
        string employee_id FK "References EMPLOYEES"
        string recruitment_channel "Conduit Name"
        float sourcing_cost "Job Board / Advertising ($)"
        float agency_fees "External Headhunting Fee ($)"
        float onboarding_cost "Background & IT Provisioning ($)"
        float signon_bonus "Signing Incentive ($)"
        int time_to_hire_days "Requisition to Offer Days"
        float total_acquisition_cost "Aggregated Cost Per Hire ($)"
    }

    LEARNING_DEVELOPMENT {
        int training_id PK "Auto Increment"
        string employee_id FK "References EMPLOYEES"
        int courses_completed "Catalog Courses Passed"
        float training_hours "Hours Spent Upskilling"
        float certification_cost "Exam & Credential Fees ($)"
        float lms_license_cost "Enterprise Seat Cost ($)"
        float external_workshop_cost "Third-party Training Cost ($)"
        float total_training_cost "Aggregated L&D Spend ($)"
        float skill_gap_reduction_pct "Capability Gain Percentage"
    }

    TURNOVER_COSTS {
        int turnover_id PK "Auto Increment"
        string employee_id FK "References EMPLOYEES"
        float exit_interview_admin_cost "HR Offboarding Admin Cost ($)"
        float lost_productivity_cost "Vacancy Productivity Void ($)"
        float replacement_recruitment_cost "Replacement Sourcing Cost ($)"
        float replacement_training_rampup_cost "Onboarding Ramp-Up Loss ($)"
        float total_attrition_cost "Total Replacement Liability ($)"
    }

    COMPANY_KPIS {
        int fiscal_year PK "e.g. 2023 to 2026"
        float annual_revenue "Corporate Revenue ($)"
        float operating_expense "Total Operating Spend ($)"
        int total_headcount "Fiscal Headcount"
        float total_hr_spend "Aggregated Enterprise HR Spend ($)"
        float hc_roi "Human Capital ROI Ratio"
    }
```

### 4.2 Data Dictionary & Referential Integrity
- **Cardinality Rules:**
  - One Department has Many Employees (`1:N`).
  - One Employee has exactly One Compensation record (`1:1`).
  - One Employee has exactly One Talent Acquisition record (`1:1`).
  - One Employee has exactly One Learning & Development record (`1:1`).
  - One Employee has Zero or One Turnover record (`1:0..1`), instantiated only when `is_attrited = 1`.
- **Constraint Enforcement:** Enforced at SQLite connection initialization via `PRAGMA foreign_keys = ON;` with cascade delete safety.

---

## 5. FUNCTIONAL REQUIREMENTS SPECIFICATION

### 5.1 FR-01: Executive Overview & Command Center
- **FR-01.1:** The system shall compute and render headline KPIs: Total Headcount, Active Headcount, Total HR Spend (\$M), Average Cost per Employee (\$), Total Overtime Spend (\$), and Total Attrition Loss (\$).
- **FR-01.2:** The system shall render an interactive Donut Chart illustrating the proportional breakdown of workforce costs across Base Payroll, Benefits, Overtime, Talent Acquisition, Training, and Turnover Loss.
- **FR-01.3:** The system shall generate a stacked horizontal bar chart benchmarked across all 8 enterprise departments.
- **FR-01.4:** The system shall render a multi-year historical trend chart comparing Annual Revenue, Total HR Spend, and the Human Capital ROI (HC ROI) ratio.

### 5.2 FR-02: Compensation & Payroll Analytics
- **FR-02.1:** The system shall compute Base Payroll, Benefits & Perks, Total Overtime, and Bonus Spend with interactive quartile metrics.
- **FR-02.2:** The system shall provide an interactive Box/Violin plot sliceable by Job Level, Department, Education, or Geographic Location.
- **FR-02.3:** The system shall render a two-dimensional Overtime Heatmap plotting Department vs. Job Level to highlight overtime hotspots.
- **FR-02.4:** The system shall execute an automated Welch's Two-Sample t-test auditing gender base pay disparity with statistical significance notifications.

### 5.3 FR-03: Turnover Forensics & Replacement Cost Impact
- **FR-03.1:** The system shall compute Annualized Attrition Rate (%) and Total Replacement Financial Loss ($).
- **FR-03.2:** The system shall render an interactive Waterfall Chart showing the financial components of turnover: Offboarding Admin, Vacancy Productivity Void, Replacement Recruitment, and Ramp-up Learning Curve Loss.
- **FR-03.3:** The system shall analyze exit interview rationales and display active workforce Flight Risk profiles (Low, Medium, High).
- **FR-03.4:** The system shall maintain an active watchlist identifying high-performing personnel (`rating >= 3.8`) with High Flight Risk, computing their individual replacement financial liabilities.

### 5.4 FR-04: Talent Acquisition & Learning ROI Analytics
- **FR-04.1:** The system shall compute Average Cost per Hire ($) and Average Time-to-Hire (days) across recruitment conduits.
- **FR-04.2:** The system shall render a Recruitment Channel Efficiency Matrix (Bubble Chart) correlating hiring duration vs. sourcing costs.
- **FR-04.3:** The system shall correlate training hours against skill gap reduction percentages using Ordinary Least Squares (OLS) linear trendline analysis.

### 5.5 FR-05: Exploratory Data Analysis & Inferential Statistics Lab
- **FR-05.1:** The system shall compute parametric and non-parametric shape metrics for all numeric dimensions: Mean, Median, Standard Deviation, IQR, Skewness, and Kurtosis.
- **FR-05.2:** The system shall render empirical histograms with marginal box plots for distribution validation.
- **FR-05.3:** The system shall compute and visualize a Pearson Correlation Heatmap across all numerical workforce metrics.
- **FR-05.4:** The system shall provide a formal Hypothesis Testing Lab executing:
  - One-Way ANOVA (Department vs. Salary variance)
  - Welch's Two-Sample t-Test (Gender pay equity)
  - Chi-Square Test of Independence (Department vs. Attrition dependence)

### 5.6 FR-06: Strategic What-If Budget Scenario Simulator
- **FR-06.1:** The system shall provide dynamic policy sliders for:
  - Annual Merit Salary Increment (0% to 15%)
  - Overtime Reduction Target (0% to 60%)
  - Target Attrition Reduction (0% to 50%)
  - Targeted Retention Investment ($0 to $2,500 per active employee)
  - Training Budget Adjustment (-25% to +50%)
- **FR-06.2:** The system shall simulate projected expenditures in real-time, computing Net Budget Variance and Retention Net Value Created.
- **FR-06.3:** The system shall output a comparative grouped bar chart and line-item variance table.

### 5.7 FR-07: Interactive SQLite Data Explorer
- **FR-07.1:** The system shall provide an interactive SQL console with built-in read-only verification (preventing `DROP`, `DELETE`, `UPDATE`, or `INSERT` mutations).
- **FR-07.2:** The system shall provide one-click analytical query templates (Top Overtime Earners, High-Risk Talent, Department Cost Summary).
- **FR-07.3:** The system shall support instant data export to CSV format.

---

## 6. NON-FUNCTIONAL REQUIREMENTS (NFR)

### 6.1 Performance and Response Time
- **NFR-01 (Query Latency):** Aggregations across 1,000 workforce records shall compute in under 250 milliseconds.
- **NFR-02 (Caching Strategy):** Unified workforce tables shall be cached in memory via Streamlit `@st.cache_data` with a 600-second TTL to eliminate redundant SQLite disk reads.

### 6.2 Usability & UI Design Standards
- **NFR-03 (Tailwind Aesthetics):** UI components must comply with Tailwind UI dark styling: Slate-900 background (`#0f172a`), Slate-800 card surface (`#1e293b`), Indigo-600 accents (`#4f46e5`), and Inter font hierarchy.
- **NFR-04 (Persistent State Navigation):** View switching shall be controlled via persistent sidebar radio routing to prevent state resets during filter changes.

### 6.3 Security & Query Isolation
- **NFR-05 (Read-Only SQL Safety):** The interactive SQL executor shall inspect user input and reject all non-read commands (`DROP`, `DELETE`, `UPDATE`, `ALTER`, `INSERT`).
- **NFR-06 (No Sensitive Personal Identifiers):** Synthetic records shall not contain real PII or live credentials.

### 6.4 Reliability & Cloud Portability
- **NFR-07 (Zero-Configuration Bootstrap):** When deployed on Streamlit Community Cloud or fresh environments, `modules/db.py` shall verify database existence and automatically seed schema and records if absent.
- **NFR-08 (Cross-Platform Execution):** The system shall run seamlessly on Windows, macOS, and Linux without OS-specific path bindings.

---

## 7. QUALITY ASSURANCE & VERIFICATION

### 7.1 Automated Unit Test Suite (`pytest`)
The project incorporates 11 automated unit tests organized into three functional test modules:

1. **`test_db.py`**:
   - `test_db_exists_and_connects`: Validates table schema and SQLite connection.
   - `test_workforce_headcount`: Asserts exactly 1,000 employee records with valid salary ranges.
   - `test_execute_custom_sql_readonly`: Validates that `SELECT` queries succeed while mutation statements raise `ValueError`.
2. **`test_analytics.py`**:
   - `test_calculate_core_kpis`: Validates mathematical consistency of totals and averages.
   - `test_department_summary`: Asserts departmental rollups sum to total headcount.
   - `test_statistical_summary`: Verifies IQR, Mean, Skewness, and Kurtosis formulas.
   - `test_hypothesis_tests`: Asserts ANOVA, t-test, and Chi-square outputs produce valid $p$-values between 0.0 and 1.0.
3. **`test_simulator.py`**:
   - `test_simulation_zero_change`: Asserts 0% change yields identical baseline and scenario spends.
   - `test_salary_increase_simulation`: Validates a 10% salary increase properly scales base and benefits.
   - `test_overtime_reduction_simulation`: Asserts 25% overtime reduction saves exactly 25% of overtime cost.
   - `test_retention_program_roi`: Verifies retention investment mathematics and net savings.

---
*End of Software Requirements Specification Document.*
