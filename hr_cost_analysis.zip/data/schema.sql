-- HR Cost Analysis Database Schema (HCL Final Submission)
-- SQLite Engine Schema

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS departments (
    department_id TEXT PRIMARY KEY,
    department_name TEXT NOT NULL,
    cost_center_code TEXT UNIQUE NOT NULL,
    headcount_target INTEGER NOT NULL,
    annual_training_budget REAL NOT NULL,
    annual_recruitment_budget REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS employees (
    employee_id TEXT PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    gender TEXT NOT NULL,
    age INTEGER NOT NULL,
    education TEXT NOT NULL,
    department_id TEXT NOT NULL,
    job_role TEXT NOT NULL,
    job_level TEXT NOT NULL,
    location TEXT NOT NULL,
    employment_type TEXT NOT NULL,
    hire_date DATE NOT NULL,
    tenure_years REAL NOT NULL,
    performance_rating REAL NOT NULL,
    is_attrited INTEGER NOT NULL DEFAULT 0,
    attrition_date DATE,
    attrition_reason TEXT,
    flight_risk TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

CREATE TABLE IF NOT EXISTS compensation (
    comp_id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL UNIQUE,
    base_salary REAL NOT NULL,
    annual_bonus REAL NOT NULL,
    health_insurance_cost REAL NOT NULL,
    retirement_benefits_cost REAL NOT NULL,
    allowances REAL NOT NULL,
    annual_overtime_hours REAL NOT NULL,
    overtime_hourly_rate REAL NOT NULL,
    total_overtime_cost REAL NOT NULL,
    total_direct_comp REAL NOT NULL,
    total_benefits_cost REAL NOT NULL,
    total_annual_cost REAL NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS talent_acquisition (
    recruitment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL UNIQUE,
    recruitment_channel TEXT NOT NULL,
    sourcing_cost REAL NOT NULL,
    agency_fees REAL NOT NULL,
    onboarding_cost REAL NOT NULL,
    signon_bonus REAL NOT NULL,
    time_to_hire_days INTEGER NOT NULL,
    total_acquisition_cost REAL NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS learning_development (
    training_id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL UNIQUE,
    courses_completed INTEGER NOT NULL,
    training_hours REAL NOT NULL,
    certification_cost REAL NOT NULL,
    lms_license_cost REAL NOT NULL,
    external_workshop_cost REAL NOT NULL,
    total_training_cost REAL NOT NULL,
    skill_gap_reduction_pct REAL NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS turnover_costs (
    turnover_id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL UNIQUE,
    exit_interview_admin_cost REAL NOT NULL,
    lost_productivity_cost REAL NOT NULL,
    replacement_recruitment_cost REAL NOT NULL,
    replacement_training_rampup_cost REAL NOT NULL,
    total_attrition_cost REAL NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS company_kpis (
    fiscal_year INTEGER PRIMARY KEY,
    annual_revenue REAL NOT NULL,
    operating_expense REAL NOT NULL,
    total_headcount INTEGER NOT NULL,
    total_hr_spend REAL NOT NULL,
    hc_roi REAL NOT NULL
);

-- Indexing for high-performance dashboard slicing
CREATE INDEX IF NOT EXISTS idx_emp_dept ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_emp_role ON employees(job_role);
CREATE INDEX IF NOT EXISTS idx_emp_attrited ON employees(is_attrited);
CREATE INDEX IF NOT EXISTS idx_comp_salary ON compensation(base_salary);
CREATE INDEX IF NOT EXISTS idx_comp_total ON compensation(total_annual_cost);
