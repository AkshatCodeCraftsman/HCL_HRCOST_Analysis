"""
seed_data.py - Enterprise HR Cost Dataset Generator and Seeder
Populates SQLite database `hr_cost_analysis.db` with realistic synthetic HR records.
Designed for HCL HR Cost Analysis Project.
"""

import sqlite3
import random
import os
from datetime import datetime, timedelta
import numpy as np

DB_FILE = os.path.join(os.path.dirname(__file__), "hr_cost_analysis.db")
SCHEMA_FILE = os.path.join(os.path.dirname(__file__), "schema.sql")

FIRST_NAMES = [
    "Aarav", "Aditi", "Rahul", "Priya", "Vikram", "Sneha", "Rohan", "Ananya", "Arjun", "Pooja",
    "Michael", "Emily", "David", "Sarah", "James", "Emma", "Daniel", "Olivia", "Alexander", "Sophia",
    "Karthik", "Divya", "Suresh", "Meera", "Amit", "Neha", "Rajesh", "Kavita", "Sanjay", "Swati",
    "John", "Jessica", "Robert", "Ashley", "William", "Amanda", "Brian", "Melissa", "Kevin", "Laura"
]

LAST_NAMES = [
    "Sharma", "Verma", "Patel", "Reddy", "Nair", "Iyer", "Choudhury", "Gupta", "Malhotra", "Kapoor",
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Wilson",
    "Rao", "Joshi", "Bhat", "Menon", "Saxena", "Agarwal", "Bose", "Ghosh", "Mukherjee", "Das"
]

DEPARTMENTS = [
    {
        "id": "DEP-01",
        "name": "Digital Business (Software Eng.)",
        "cost_center": "CC-101",
        "headcount_target": 280,
        "training_budget": 350000.0,
        "recruitment_budget": 240000.0
    },
    {
        "id": "DEP-02",
        "name": "Digital Foundation (Cloud & Infra)",
        "cost_center": "CC-102",
        "headcount_target": 180,
        "training_budget": 220000.0,
        "recruitment_budget": 160000.0
    },
    {
        "id": "DEP-03",
        "name": "Data & AI Solutions",
        "cost_center": "CC-103",
        "headcount_target": 160,
        "training_budget": 280000.0,
        "recruitment_budget": 210000.0
    },
    {
        "id": "DEP-04",
        "name": "Engineering & R&D Services (ERS)",
        "cost_center": "CC-104",
        "headcount_target": 150,
        "training_budget": 200000.0,
        "recruitment_budget": 140000.0
    },
    {
        "id": "DEP-05",
        "name": "Cybersecurity & GRC",
        "cost_center": "CC-105",
        "headcount_target": 90,
        "training_budget": 180000.0,
        "recruitment_budget": 130000.0
    },
    {
        "id": "DEP-06",
        "name": "Enterprise Apps (SAP/Oracle)",
        "cost_center": "CC-106",
        "headcount_target": 80,
        "training_budget": 130000.0,
        "recruitment_budget": 95000.0
    },
    {
        "id": "DEP-07",
        "name": "Digital Process Operations",
        "cost_center": "CC-107",
        "headcount_target": 80,
        "training_budget": 90000.0,
        "recruitment_budget": 70000.0
    },
    {
        "id": "DEP-08",
        "name": "Corporate Functions (HR & Finance)",
        "cost_center": "CC-108",
        "headcount_target": 60,
        "training_budget": 85000.0,
        "recruitment_budget": 65000.0
    }
]

ROLE_MATRIX = {
    "DEP-01": [("Software Engineer", "Junior", 48000, 68000),
               ("Senior Software Engineer", "Mid-Level", 72000, 98000),
               ("Technical Lead", "Senior", 102000, 135000),
               ("Principal Architect", "Lead", 140000, 185000),
               ("Engineering Director", "Director", 195000, 245000)],
    "DEP-02": [("Cloud Support Associate", "Junior", 45000, 62000),
               ("DevOps / Cloud Engineer", "Mid-Level", 68000, 94000),
               ("Cloud Solutions Architect", "Senior", 105000, 140000),
               ("Infra Delivery Lead", "Lead", 135000, 175000),
               ("Infrastructure Director", "Director", 190000, 235000)],
    "DEP-03": [("Junior Data Analyst", "Junior", 50000, 70000),
               ("Machine Learning Engineer", "Mid-Level", 80000, 115000),
               ("Senior Data Scientist", "Senior", 115000, 155000),
               ("AI Research Lead", "Lead", 150000, 195000),
               ("Head of AI / Data Director", "Director", 205000, 260000)],
    "DEP-04": [("Embedded Systems Engineer", "Junior", 47000, 65000),
               ("Hardware / Firmware Specialist", "Mid-Level", 70000, 96000),
               ("Systems Architect", "Senior", 102000, 138000),
               ("R&D Program Lead", "Lead", 138000, 180000),
               ("R&D Practice Director", "Director", 192000, 240000)],
    "DEP-05": [("SOC Analyst", "Junior", 52000, 72000),
               ("Security Engineer", "Mid-Level", 75000, 105000),
               ("Penetration Tester / GRC Lead", "Senior", 110000, 148000),
               ("Information Security Lead", "Lead", 145000, 188000),
               ("CISO / Security Director", "Director", 200000, 255000)],
    "DEP-06": [("Associate Consultant", "Junior", 46000, 64000),
               ("ERP Functional Consultant", "Mid-Level", 69000, 95000),
               ("Senior ERP Solution Architect", "Senior", 104000, 142000),
               ("Enterprise Project Lead", "Lead", 136000, 178000),
               ("Practice Director", "Director", 188000, 235000)],
    "DEP-07": [("Process Associate", "Junior", 34000, 48000),
               ("Senior Operations Analyst", "Mid-Level", 49000, 68000),
               ("Team Lead - Operations", "Senior", 70000, 95000),
               ("Operations Manager", "Lead", 98000, 130000),
               ("Operations Director", "Director", 155000, 195000)],
    "DEP-08": [("HR / Finance Executive", "Junior", 40000, 58000),
               ("Senior HR Specialist", "Mid-Level", 60000, 82000),
               ("Finance Manager", "Senior", 90000, 125000),
               ("People Partner Lead", "Lead", 125000, 160000),
               ("HR / Finance Director", "Director", 175000, 220000)]
}

LOCATIONS = ["Noida (HQ)", "Bangalore", "Chennai", "Hyderabad", "Pune", "London", "New York"]
LOCATION_WEIGHTS = [0.26, 0.28, 0.16, 0.14, 0.08, 0.04, 0.04]

CHANNELS = ["Direct / Referral", "Campus Placement", "LinkedIn / Job Portal", "Recruitment Agency", "Internal Transfer"]
CHANNEL_WEIGHTS = [0.32, 0.24, 0.26, 0.12, 0.06]

ATTRITION_REASONS = [
    "Compensation & Benefits",
    "Better Career Opportunity",
    "Work-Life Balance & Burnout",
    "Relocation / Family",
    "Higher Education",
    "Involuntary / Restructuring"
]

def generate_database(num_employees=1000, seed=42):
    random.seed(seed)
    np.random.seed(seed)

    if os.path.exists(DB_FILE):
        try:
            os.remove(DB_FILE)
        except Exception:
            pass

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Load and execute schema
    with open(SCHEMA_FILE, "r") as f:
        cursor.executescript(f.read())

    # Insert departments
    for dep in DEPARTMENTS:
        cursor.execute("""
            INSERT INTO departments (
                department_id, department_name, cost_center_code,
                headcount_target, annual_training_budget, annual_recruitment_budget
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (dep["id"], dep["name"], dep["cost_center"], dep["headcount_target"],
              dep["training_budget"], dep["recruitment_budget"]))

    employees_data = []
    compensation_data = []
    recruitment_data = []
    training_data = []
    turnover_data = []

    dept_ids = [d["id"] for d in DEPARTMENTS]
    dept_probs = [0.28, 0.18, 0.16, 0.15, 0.09, 0.06, 0.05, 0.03]

    today = datetime(2026, 11, 1)

    for i in range(1, num_employees + 1):
        emp_id = f"HCL-{i:04d}"
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        gender = random.choices(["Male", "Female", "Non-Binary"], weights=[0.58, 0.40, 0.02])[0]
        education = random.choices(["Bachelor", "Master", "Doctorate", "Diploma"], weights=[0.60, 0.32, 0.04, 0.04])[0]
        
        dept_id = random.choices(dept_ids, weights=dept_probs)[0]
        roles_available = ROLE_MATRIX[dept_id]
        role_weights = [0.42, 0.32, 0.16, 0.07, 0.03]
        selected_role_meta = random.choices(roles_available, weights=role_weights)[0]
        role_name, role_level, sal_min, sal_max = selected_role_meta

        location = random.choices(LOCATIONS, weights=LOCATION_WEIGHTS)[0]
        emp_type = random.choices(["Full-Time", "Contract", "Part-Time"], weights=[0.92, 0.06, 0.02])[0]

        # Experience & tenure
        level_exp_ranges = {
            "Junior": (1.0, 3.5),
            "Mid-Level": (3.5, 7.0),
            "Senior": (7.0, 11.5),
            "Lead": (11.0, 17.0),
            "Director": (16.0, 25.0)
        }
        exp_min, exp_max = level_exp_ranges[role_level]
        total_exp = round(random.uniform(exp_min, exp_max), 1)
        tenure_years = round(min(total_exp, random.uniform(0.5, total_exp)), 1)
        age = int(22 + total_exp + random.uniform(0, 3))
        hire_date = today - timedelta(days=int(tenure_years * 365))

        # Performance rating (1.0 - 5.0, centered around 3.6)
        perf_rating = round(float(np.clip(np.random.normal(3.6, 0.7), 1.5, 5.0)), 2)

        # Attrition probability (correlated with lower salary ratio, high overtime, or low perf)
        base_attrition_rate = 0.14
        if role_level == "Junior":
            base_attrition_rate += 0.05
        elif role_level == "Director":
            base_attrition_rate -= 0.08
        if perf_rating < 2.5:
            base_attrition_rate += 0.12
        elif perf_rating > 4.5:
            base_attrition_rate += 0.04  # poached by market

        is_attrited = 1 if (random.random() < base_attrition_rate) else 0
        attrition_date = None
        attrition_reason = None
        if is_attrited:
            attr_days_ago = random.randint(10, 340)
            attrition_date = (today - timedelta(days=attr_days_ago)).strftime("%Y-%m-%d")
            attrition_reason = random.choice(ATTRITION_REASONS)

        flight_risk = "Low"
        if not is_attrited:
            if perf_rating > 4.2 and tenure_years > 2.5:
                flight_risk = random.choice(["Medium", "High"])
            elif perf_rating < 2.8:
                flight_risk = random.choice(["Medium", "High"])
            elif random.random() < 0.25:
                flight_risk = "Medium"

        employees_data.append((
            emp_id, first, last, gender, age, education, dept_id,
            role_name, role_level, location, emp_type,
            hire_date.strftime("%Y-%m-%d"), tenure_years, perf_rating,
            is_attrited, attrition_date, attrition_reason, flight_risk
        ))

        # --- Compensation Computation ---
        # Base salary sampled between bounds, slightly higher for onsite US/UK locations
        loc_multiplier = 1.65 if location in ["New York", "London"] else 1.0
        sampled_base = random.uniform(sal_min, sal_max) * loc_multiplier
        # Tenured employees have slight increment
        base_salary = round(sampled_base * (1 + 0.025 * tenure_years), 2)
        
        bonus_pct = {
            "Junior": random.uniform(0.05, 0.10),
            "Mid-Level": random.uniform(0.08, 0.14),
            "Senior": random.uniform(0.12, 0.20),
            "Lead": random.uniform(0.15, 0.25),
            "Director": random.uniform(0.25, 0.40)
        }[role_level]
        # Performance adjusts bonus
        bonus_factor = perf_rating / 3.5
        annual_bonus = round(base_salary * bonus_pct * bonus_factor, 2)

        health_insurance_cost = round(random.uniform(4200, 6800) * (1.3 if location in ["New York", "London"] else 1.0), 2)
        retirement_benefits_cost = round(base_salary * random.uniform(0.06, 0.09), 2)
        allowances = round(base_salary * random.uniform(0.04, 0.08), 2)

        # Overtime calculation
        if role_level in ["Junior", "Mid-Level"] and emp_type == "Full-Time":
            ot_hours = round(max(0, np.random.exponential(scale=65 if dept_id in ["DEP-02", "DEP-07"] else 30)), 1)
        elif role_level == "Senior":
            ot_hours = round(max(0, np.random.exponential(scale=15)), 1)
        else:
            ot_hours = 0.0

        hourly_rate = round((base_salary / 2080) * 1.5, 2)  # 1.5x standard overtime factor
        total_overtime_cost = round(ot_hours * hourly_rate, 2)

        total_direct_comp = round(base_salary + annual_bonus + total_overtime_cost, 2)
        total_benefits_cost = round(health_insurance_cost + retirement_benefits_cost + allowances, 2)
        total_annual_cost = round(total_direct_comp + total_benefits_cost, 2)

        compensation_data.append((
            emp_id, base_salary, annual_bonus, health_insurance_cost,
            retirement_benefits_cost, allowances, ot_hours, hourly_rate,
            total_overtime_cost, total_direct_comp, total_benefits_cost, total_annual_cost
        ))

        # --- Talent Acquisition Computation ---
        channel = random.choices(CHANNELS, weights=CHANNEL_WEIGHTS)[0]
        if channel == "Recruitment Agency":
            agency_fee = round(base_salary * random.uniform(0.15, 0.22), 2)
            sourcing_cost = round(random.uniform(800, 1500), 2)
            time_to_hire = random.randint(25, 60)
        elif channel == "Campus Placement":
            agency_fee = 0.0
            sourcing_cost = round(random.uniform(1200, 2500), 2)
            time_to_hire = random.randint(15, 45)
        elif channel == "LinkedIn / Job Portal":
            agency_fee = 0.0
            sourcing_cost = round(random.uniform(1500, 3500), 2)
            time_to_hire = random.randint(30, 75)
        elif channel == "Direct / Referral":
            agency_fee = 0.0
            sourcing_cost = round(random.uniform(1000, 2000), 2)  # Referral reward
            time_to_hire = random.randint(18, 40)
        else:  # Internal Transfer
            agency_fee = 0.0
            sourcing_cost = round(random.uniform(300, 800), 2)
            time_to_hire = random.randint(10, 25)

        onboarding_cost = round(random.uniform(1200, 2800), 2)
        signon_bonus = round(base_salary * random.uniform(0.04, 0.10) if role_level in ["Lead", "Director"] and channel in ["Recruitment Agency", "LinkedIn / Job Portal"] else 0.0, 2)
        total_acq_cost = round(sourcing_cost + agency_fee + onboarding_cost + signon_bonus, 2)

        recruitment_data.append((
            emp_id, channel, sourcing_cost, agency_fee, onboarding_cost,
            signon_bonus, time_to_hire, total_acq_cost
        ))

        # --- Learning & Development Computation ---
        courses = random.randint(1, 8)
        training_hours = round(courses * random.uniform(6.0, 16.0), 1)
        cert_cost = round(random.choice([0, 350, 650, 1200, 2500]) if dept_id in ["DEP-01", "DEP-03", "DEP-05"] else random.choice([0, 250, 500]), 2)
        lms_license = 450.0
        ext_workshop = round(random.choice([0, 0, 800, 1800]) if role_level in ["Senior", "Lead", "Director"] else 0.0, 2)
        total_train_cost = round(cert_cost + lms_license + ext_workshop, 2)
        skill_gap_red = round(min(95.0, (training_hours * 1.2) + (courses * 3.5) + random.uniform(5, 20)), 1)

        training_data.append((
            emp_id, courses, training_hours, cert_cost, lms_license,
            ext_workshop, total_train_cost, skill_gap_red
        ))

        # --- Turnover & Attrition Cost ---
        if is_attrited:
            exit_admin = 750.0
            # Lost productivity during vacancy (avg 45-75 days vacancy at daily wage)
            vacancy_days = random.randint(35, 75)
            daily_cost = base_salary / 250.0
            lost_prod = round(vacancy_days * daily_cost * 0.65, 2)
            # Replacement recruitment cost: typically 20-30% of base salary
            repl_recruitment = round(base_salary * random.uniform(0.18, 0.28), 2)
            # Rampup learning curve loss: 3 months at 50% productivity
            rampup = round((base_salary / 4.0) * 0.40, 2)
            total_turnover = round(exit_admin + lost_prod + repl_recruitment + rampup, 2)

            turnover_data.append((
                emp_id, exit_admin, lost_prod, repl_recruitment, rampup, total_turnover
            ))

    # Bulk insert
    cursor.executemany("""
        INSERT INTO employees (
            employee_id, first_name, last_name, gender, age, education,
            department_id, job_role, job_level, location, employment_type,
            hire_date, tenure_years, performance_rating, is_attrited,
            attrition_date, attrition_reason, flight_risk
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, employees_data)

    cursor.executemany("""
        INSERT INTO compensation (
            employee_id, base_salary, annual_bonus, health_insurance_cost,
            retirement_benefits_cost, allowances, annual_overtime_hours,
            overtime_hourly_rate, total_overtime_cost, total_direct_comp,
            total_benefits_cost, total_annual_cost
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, compensation_data)

    cursor.executemany("""
        INSERT INTO talent_acquisition (
            employee_id, recruitment_channel, sourcing_cost, agency_fees,
            onboarding_cost, signon_bonus, time_to_hire_days, total_acquisition_cost
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, recruitment_data)

    cursor.executemany("""
        INSERT INTO learning_development (
            employee_id, courses_completed, training_hours, certification_cost,
            lms_license_cost, external_workshop_cost, total_training_cost,
            skill_gap_reduction_pct
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, training_data)

    cursor.executemany("""
        INSERT INTO turnover_costs (
            employee_id, exit_interview_admin_cost, lost_productivity_cost,
            replacement_recruitment_cost, replacement_training_rampup_cost,
            total_attrition_cost
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, turnover_data)

    # Insert historical company fiscal KPIs
    fiscal_records = [
        (2023, 142000000.0, 110000000.0, 880, 85400000.0, 1.38),
        (2024, 161000000.0, 122000000.0, 940, 94600000.0, 1.41),
        (2025, 184000000.0, 137000000.0, 985, 104200000.0, 1.45),
        (2026, 205000000.0, 151000000.0, 1000, 112800000.0, 1.48)
    ]
    cursor.executemany("""
        INSERT INTO company_kpis (
            fiscal_year, annual_revenue, operating_expense,
            total_headcount, total_hr_spend, hc_roi
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, fiscal_records)

    conn.commit()
    conn.close()
    print(f"Successfully generated database with {num_employees} records at {DB_FILE}")

if __name__ == "__main__":
    generate_database()
