"""
modules/charts.py - Plotly Interactive Chart Generation
Styled with modern dark theme, Tailwind color palette, and responsive tooltips.
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

# Theme Color Palette (Tailwind Inspired)
PALETTE = {
    "indigo": "#6366f1",
    "emerald": "#10b981",
    "amber": "#f59e0b",
    "rose": "#ef4444",
    "cyan": "#06b6d4",
    "violet": "#8b5cf6",
    "blue": "#3b82f6",
    "slate": "#64748b",
    "dark_card": "#1e293b",
    "text": "#f8fafc",
    "grid": "#334155"
}

SEQUENCE = ["#6366f1", "#10b981", "#06b6d4", "#f59e0b", "#ec4899", "#8b5cf6", "#3b82f6", "#14b8a6"]

def _apply_dark_layout(fig, title: str = "", height: int = 420):
    """Standardizes sleek dark-mode aesthetics across all Plotly figures."""
    fig.update_layout(
        title={
            'text': f"<b>{title}</b>",
            'y': 0.95,
            'x': 0.03,
            'xanchor': 'left',
            'yanchor': 'top',
            'font': {'size': 15, 'color': PALETTE['text'], 'family': 'Inter, sans-serif'}
        },
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=height,
        margin=dict(l=40, r=30, t=55, b=40),
        font=dict(family="Inter, sans-serif", color="#cbd5e1", size=12),
        legend=dict(
            bgcolor="rgba(30, 41, 59, 0.7)",
            bordercolor="rgba(71, 85, 105, 0.3)",
            borderwidth=1,
            font=dict(size=11)
        )
    )
    fig.update_xaxes(showgrid=True, gridcolor=PALETTE['grid'], gridwidth=0.5, zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor=PALETTE['grid'], gridwidth=0.5, zeroline=False)
    return fig

def chart_cost_composition_donut(df: pd.DataFrame):
    """Donut chart illustrating total workforce cost breakdown."""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No records in current filter", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#cbd5e1"))
        return _apply_dark_layout(fig, "HR Cost Distribution by Component")

    labels = ["Base Payroll", "Benefits & Allowances", "Overtime Spend", "Recruitment", "Training & Dev", "Turnover Loss"]
    values = [
        float(df['base_salary'].sum()),
        float(df['total_benefits_cost'].sum()),
        float(df['total_overtime_cost'].sum()),
        float(df['total_acquisition_cost'].sum()),
        float(df['total_training_cost'].sum()),
        float(df['total_attrition_cost'].sum())
    ]
    
    total_spend = sum(values)
    if total_spend <= 0:
        fig = go.Figure()
        fig.add_annotation(text="Total Cost $0 in Filter", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#cbd5e1"))
        return _apply_dark_layout(fig, "HR Cost Distribution by Component")

    fig = go.Figure(data=[go.Pie(
        labels=labels,
        values=values,
        hole=0.55,
        marker=dict(colors=SEQUENCE[:6], line=dict(color='#0f172a', width=2)),
        textinfo='label+percent',
        insidetextorientation='radial',
        hoverinfo='label+value+percent',
        hovertemplate="<b>%{label}</b><br>Total: $%{value:,.0f}<br>Share: %{percent}<extra></extra>"
    )])
    
    fig.add_annotation(
        text=f"Filtered Spend<br><b>${total_spend/1e6:.2f}M</b>" if total_spend >= 1e6 else f"Filtered Spend<br><b>${total_spend/1e3:.0f}K</b>",
        x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=14, color="#f8fafc", family="Inter, sans-serif")
    )
    return _apply_dark_layout(fig, "HR Cost Distribution by Component")

def chart_dept_cost_breakdown(df: pd.DataFrame):
    """Stacked horizontal bar chart of cost components by department."""
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No records in current filter", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#cbd5e1"))
        return _apply_dark_layout(fig, "Departmental Cost Stack Breakdown ($)")

    dept_agg = df.groupby('department_name').agg({
        'base_salary': 'sum',
        'total_benefits_cost': 'sum',
        'total_overtime_cost': 'sum',
        'total_training_cost': 'sum'
    }).reset_index()

    dept_agg['total'] = dept_agg['base_salary'] + dept_agg['total_benefits_cost'] + dept_agg['total_overtime_cost'] + dept_agg['total_training_cost']
    dept_agg = dept_agg.sort_values(by='total', ascending=True)

    fig = go.Figure()
    fig.add_trace(go.Bar(
        y=dept_agg['department_name'], x=dept_agg['base_salary'],
        name='Base Salary', orientation='h', marker_color=PALETTE['indigo']
    ))
    fig.add_trace(go.Bar(
        y=dept_agg['department_name'], x=dept_agg['total_benefits_cost'],
        name='Benefits & Perks', orientation='h', marker_color=PALETTE['cyan']
    ))
    fig.add_trace(go.Bar(
        y=dept_agg['department_name'], x=dept_agg['total_overtime_cost'],
        name='Overtime Spend', orientation='h', marker_color=PALETTE['amber']
    ))
    fig.add_trace(go.Bar(
        y=dept_agg['department_name'], x=dept_agg['total_training_cost'],
        name='Training & Upskilling', orientation='h', marker_color=PALETTE['emerald']
    ))

    fig.update_layout(barmode='stack')
    return _apply_dark_layout(fig, "Departmental Cost Stack Breakdown ($)")

def chart_salary_distribution_box(df: pd.DataFrame, group_col: str = 'job_level'):
    """Violin and box plot of base salary distributions."""
    if df.empty:
        fig = go.Figure()
        return _apply_dark_layout(fig, f"Salary Dispersion by {group_col.replace('_', ' ').title()}")

    fig = px.box(
        df,
        x=group_col,
        y="base_salary",
        color=group_col,
        color_discrete_sequence=SEQUENCE,
        points="outliers",
        labels={"base_salary": "Base Salary ($)", group_col: group_col.replace('_', ' ').title()}
    )
    fig.update_layout(showlegend=False)
    return _apply_dark_layout(fig, f"Salary Dispersion by {group_col.replace('_', ' ').title()}")

def chart_overtime_heatmap(df: pd.DataFrame):
    """2D Heatmap of average overtime hours across Department vs Job Level."""
    if df.empty:
        fig = go.Figure()
        return _apply_dark_layout(fig, "Overtime Hotspots: Department vs. Job Level")

    pivot = df.pivot_table(
        index='department_name',
        columns='job_level',
        values='annual_overtime_hours',
        aggfunc='mean'
    ).fillna(0)

    level_order = [lvl for lvl in ["Junior", "Mid-Level", "Senior", "Lead", "Director"] if lvl in pivot.columns]
    if level_order:
        pivot = pivot[level_order]

    fig = go.Figure(data=go.Heatmap(
        z=pivot.values,
        x=pivot.columns,
        y=pivot.index,
        colorscale="Viridis",
        colorbar=dict(title="Avg Hrs"),
        hovertemplate="Dept: %{y}<br>Level: %{x}<br>Avg Overtime: %{z:.1f} hrs<extra></extra>"
    ))
    return _apply_dark_layout(fig, "Overtime Hotspots: Department vs. Job Level (Annual Hours)")

def chart_attrition_waterfall(df: pd.DataFrame):
    """Waterfall chart showing cost components of employee turnover."""
    attrited = df[df['is_attrited'] == 1]
    if attrited.empty:
        fig = go.Figure()
        fig.add_annotation(
            text="No Departed Personnel in Current Filter Selection<br><span style='font-size:12px;color:#94a3b8;'>Switch filter to 'All Personnel' or 'Attrited Only'</span>",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14, color="#cbd5e1", family="Inter, sans-serif")
        )
        return _apply_dark_layout(fig, "Financial Anatomy of Attrition & Replacement Cost ($)")

    exit_admin = float(attrited['exit_interview_admin_cost'].sum())
    lost_prod = float(attrited['lost_productivity_cost'].sum())
    recruitment_repl = float(attrited['replacement_recruitment_cost'].sum())
    rampup = float(attrited['replacement_training_rampup_cost'].sum())
    total_loss = float(attrited['total_attrition_cost'].sum())

    fig = go.Figure(go.Waterfall(
        name="Turnover Costs",
        orientation="v",
        measure=["relative", "relative", "relative", "relative", "total"],
        x=["Admin & Offboarding", "Lost Vacancy Prod.", "Replacement Hiring", "Ramp-up Training", "Total Attrition Loss"],
        textposition="outside",
        text=[f"${exit_admin/1e3:.1f}K", f"${lost_prod/1e3:.1f}K", f"${recruitment_repl/1e3:.1f}K", f"${rampup/1e3:.1f}K", f"${total_loss/1e3:.1f}K"],
        y=[exit_admin, lost_prod, recruitment_repl, rampup, total_loss],
        connector={"line": {"color": PALETTE["slate"]}},
        decreasing={"marker": {"color": PALETTE["emerald"]}},
        increasing={"marker": {"color": PALETTE["rose"]}},
        totals={"marker": {"color": PALETTE["indigo"]}}
    ))
    return _apply_dark_layout(fig, "Financial Anatomy of Attrition & Replacement Cost ($)")

def chart_recruitment_efficiency(df: pd.DataFrame):
    """Bubble chart: Channel efficiency (Time to Hire vs. Cost per Hire)."""
    if df.empty:
        fig = go.Figure()
        return _apply_dark_layout(fig, "Recruitment Channel Efficiency Matrix")

    channel_agg = df.groupby('recruitment_channel').agg({
        'total_acquisition_cost': 'mean',
        'time_to_hire_days': 'mean',
        'employee_id': 'count'
    }).reset_index()

    fig = px.scatter(
        channel_agg,
        x="time_to_hire_days",
        y="total_acquisition_cost",
        size="employee_id",
        color="recruitment_channel",
        text="recruitment_channel",
        color_discrete_sequence=SEQUENCE,
        labels={
            "time_to_hire_days": "Average Time-to-Hire (Days)",
            "total_acquisition_cost": "Average Cost per Hire ($)",
            "employee_id": "Headcount"
        }
    )
    fig.update_traces(textposition='top center')
    return _apply_dark_layout(fig, "Recruitment Channel Efficiency Matrix")

def chart_training_roi_scatter(df: pd.DataFrame):
    """Scatter plot: Training Hours vs Skill Gap Reduction % with safe trendline."""
    if df.empty:
        fig = go.Figure()
        return _apply_dark_layout(fig, "Learning & Development Impact: Hours vs. Skill Gap Reduction")

    sample = df.sample(min(300, len(df)), random_state=42)
    use_trend = "ols" if len(sample) >= 5 and sample['training_hours'].nunique() > 1 else None

    fig = px.scatter(
        sample,
        x="training_hours",
        y="skill_gap_reduction_pct",
        color="job_level",
        size="performance_rating",
        trendline=use_trend,
        color_discrete_sequence=SEQUENCE,
        labels={
            "training_hours": "Training Hours Completed",
            "skill_gap_reduction_pct": "Skill Gap Reduction (%)",
            "job_level": "Job Level"
        }
    )
    return _apply_dark_layout(fig, "Learning & Development Impact: Hours vs. Skill Gap Reduction")

def chart_correlation_heatmap(df: pd.DataFrame):
    """Correlation matrix heatmap across key HR metrics."""
    numeric_cols = [
        'age', 'tenure_years', 'performance_rating',
        'base_salary', 'total_overtime_cost', 'total_benefits_cost',
        'total_annual_cost', 'training_hours', 'time_to_hire_days'
    ]
    available_cols = [c for c in numeric_cols if c in df.columns]
    if len(df) < 2 or not available_cols:
        fig = go.Figure()
        fig.add_annotation(text="Insufficient data points for correlation", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color="#cbd5e1"))
        return _apply_dark_layout(fig, "Workforce Metrics Correlation Heatmap")

    corr = df[available_cols].corr().fillna(0)
    labels = [c.replace('_', ' ').title() for c in available_cols]

    fig = go.Figure(data=go.Heatmap(
        z=corr.values,
        x=labels,
        y=labels,
        colorscale="RdBu",
        zmin=-1, zmax=1,
        colorbar=dict(title="Correlation"),
        hovertemplate="%{x} vs %{y}: <b>%{z:.2f}</b><extra></extra>"
    ))
    return _apply_dark_layout(fig, "Workforce Metrics Correlation Heatmap", height=480)

def chart_scenario_comparison(sim_results: dict):
    """Grouped bar chart comparing Baseline vs Simulated scenario costs."""
    categories = ["Base Salary", "Overtime", "Benefits", "Training", "Attrition Loss", "Total HR Spend"]
    b = sim_results["baseline"]
    s = sim_results["scenario"]

    baseline_vals = [b["base_salary"], b["overtime"], b["benefits"], b["training"], b["attrition_loss"], b["total_spend"]]
    scenario_vals = [s["base_salary"], s["overtime"], s["benefits"], s["training"], s["attrition_loss"], s["total_spend"]]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name='Current Baseline',
        x=categories,
        y=baseline_vals,
        marker_color=PALETTE['slate']
    ))
    fig.add_trace(go.Bar(
        name='Simulated Scenario',
        x=categories,
        y=scenario_vals,
        marker_color=PALETTE['indigo']
    ))

    fig.update_layout(barmode='group')
    return _apply_dark_layout(fig, "Baseline vs. What-If Scenario Cost Comparison ($)")

def chart_historical_hc_roi(kpi_df: pd.DataFrame):
    """Dual-axis chart showing Revenue, HR Spend, and Human Capital ROI over fiscal years."""
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=kpi_df['fiscal_year'],
        y=kpi_df['annual_revenue'],
        name='Annual Revenue ($)',
        marker_color=PALETTE['cyan'],
        yaxis='y'
    ))
    fig.add_trace(go.Bar(
        x=kpi_df['fiscal_year'],
        y=kpi_df['total_hr_spend'],
        name='Total HR Spend ($)',
        marker_color=PALETTE['indigo'],
        yaxis='y'
    ))
    fig.add_trace(go.Scatter(
        x=kpi_df['fiscal_year'],
        y=kpi_df['hc_roi'],
        name='Human Capital ROI Ratio',
        mode='lines+markers',
        line=dict(color=PALETTE['emerald'], width=3),
        marker=dict(size=8),
        yaxis='y2'
    ))

    fig.update_layout(
        yaxis=dict(title='Financial Amount ($)', showgrid=True, gridcolor=PALETTE['grid']),
        yaxis2=dict(title='HC ROI Ratio', overlaying='y', side='right', showgrid=False),
        barmode='group'
    )
    return _apply_dark_layout(fig, "Historical Fiscal Trend: Revenue, HR Spend & HC ROI")
