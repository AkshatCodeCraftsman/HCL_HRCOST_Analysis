"""
modules/analytics.py - Statistical Analysis, Hypothesis Testing, and KPI Engine
Calculates executive metrics, parametric/non-parametric summaries, ANOVA,
t-tests, chi-square tests, and what-if simulation modeling.
"""

import pandas as pd
import numpy as np
from scipy import stats

def calculate_core_kpis(df: pd.DataFrame) -> dict:
    """Computes headline workforce and financial KPIs."""
    if df.empty:
        return {}

    total_headcount = len(df)
    active_headcount = int((df['is_attrited'] == 0).sum())
    attrited_headcount = int((df['is_attrited'] == 1).sum())
    attrition_rate = (attrited_headcount / total_headcount * 100) if total_headcount > 0 else 0.0

    total_annual_cost = float(df['total_annual_cost'].sum())
    avg_cost_per_employee = float(df['total_annual_cost'].mean())
    median_cost_per_employee = float(df['total_annual_cost'].median())

    total_base_payroll = float(df['base_salary'].sum())
    avg_base_salary = float(df['base_salary'].mean())
    median_base_salary = float(df['base_salary'].median())

    total_overtime_cost = float(df['total_overtime_cost'].sum())
    total_overtime_hours = float(df['annual_overtime_hours'].sum())
    overtime_pct_base = (total_overtime_cost / total_base_payroll * 100) if total_base_payroll > 0 else 0.0

    total_benefits_cost = float(df['total_benefits_cost'].sum())
    benefits_pct_base = (total_benefits_cost / total_base_payroll * 100) if total_base_payroll > 0 else 0.0

    total_recruitment_cost = float(df['total_acquisition_cost'].sum())
    avg_cost_per_hire = float(df['total_acquisition_cost'].mean())
    avg_time_to_hire = float(df['time_to_hire_days'].mean())

    total_training_cost = float(df['total_training_cost'].sum())
    avg_training_per_employee = float(df['total_training_cost'].mean())
    avg_training_hours = float(df['training_hours'].mean())

    total_attrition_financial_loss = float(df['total_attrition_cost'].sum())
    avg_attrition_cost_per_leaver = (total_attrition_financial_loss / attrited_headcount) if attrited_headcount > 0 else 0.0

    return {
        "total_headcount": total_headcount,
        "active_headcount": active_headcount,
        "attrited_headcount": attrited_headcount,
        "attrition_rate": attrition_rate,
        "total_annual_cost": total_annual_cost,
        "avg_cost_per_employee": avg_cost_per_employee,
        "median_cost_per_employee": median_cost_per_employee,
        "total_base_payroll": total_base_payroll,
        "avg_base_salary": avg_base_salary,
        "median_base_salary": median_base_salary,
        "total_overtime_cost": total_overtime_cost,
        "total_overtime_hours": total_overtime_hours,
        "overtime_pct_base": overtime_pct_base,
        "total_benefits_cost": total_benefits_cost,
        "benefits_pct_base": benefits_pct_base,
        "total_recruitment_cost": total_recruitment_cost,
        "avg_cost_per_hire": avg_cost_per_hire,
        "avg_time_to_hire": avg_time_to_hire,
        "total_training_cost": total_training_cost,
        "avg_training_per_employee": avg_training_per_employee,
        "avg_training_hours": avg_training_hours,
        "total_attrition_financial_loss": total_attrition_financial_loss,
        "avg_attrition_cost_per_leaver": avg_attrition_cost_per_leaver
    }

def calculate_department_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregates cost and operational metrics by department."""
    if df.empty:
        return pd.DataFrame()

    agg_funcs = {
        'employee_id': 'count',
        'is_attrited': 'sum',
        'total_annual_cost': 'sum',
        'base_salary': 'mean',
        'total_overtime_cost': 'sum',
        'annual_overtime_hours': 'sum',
        'total_benefits_cost': 'sum',
        'total_acquisition_cost': 'mean',
        'total_training_cost': 'mean',
        'total_attrition_cost': 'sum'
    }
    
    dept_df = df.groupby('department_name').agg(agg_funcs).reset_index()
    dept_df.rename(columns={
        'employee_id': 'Headcount',
        'is_attrited': 'Attrition Count',
        'total_annual_cost': 'Total Spend ($)',
        'base_salary': 'Avg Base Salary ($)',
        'total_overtime_cost': 'Total Overtime ($)',
        'annual_overtime_hours': 'Total Overtime (Hrs)',
        'total_benefits_cost': 'Total Benefits ($)',
        'total_acquisition_cost': 'Avg Cost Per Hire ($)',
        'total_training_cost': 'Avg Training Spend ($)',
        'total_attrition_cost': 'Turnover Loss ($)'
    }, inplace=True)

    dept_df['Attrition Rate (%)'] = (dept_df['Attrition Count'] / dept_df['Headcount'] * 100).round(1)
    dept_df['Avg Cost Per Employee ($)'] = (dept_df['Total Spend ($)'] / dept_df['Headcount']).round(2)
    return dept_df.sort_values(by='Total Spend ($)', ascending=False)

def calculate_statistical_summary(df: pd.DataFrame, col_name: str) -> dict:
    """Computes detailed parametric and non-parametric distribution statistics."""
    series = df[col_name].dropna()
    if series.empty:
        return {}

    q1 = float(series.quantile(0.25))
    q3 = float(series.quantile(0.75))
    iqr = q3 - q1

    return {
        "count": int(series.count()),
        "mean": float(series.mean()),
        "std": float(series.std()),
        "median": float(series.median()),
        "q1": q1,
        "q3": q3,
        "iqr": iqr,
        "min": float(series.min()),
        "max": float(series.max()),
        "skewness": float(stats.skew(series, bias=False)),
        "kurtosis": float(stats.kurtosis(series, bias=False))
    }

def run_anova_salary_by_department(df: pd.DataFrame) -> dict:
    """
    Performs One-Way ANOVA to test whether base salary differs significantly
    across different departments.
    """
    depts = [group['base_salary'].values for _, group in df.groupby('department_name') if len(group) > 5]
    if len(depts) < 2:
        return {"error": "Insufficient groups for ANOVA"}

    f_stat, p_val = stats.f_oneway(*depts)
    is_sig = p_val < 0.05

    interp = (
        f"Statistically significant difference detected (F = {f_stat:.2f}, p = {p_val:.4e} < 0.05). "
        "Departmental specialization (e.g., AI/Data vs Operations) drives meaningful base compensation disparities."
        if is_sig else
        f"No statistically significant difference detected across departments (F = {f_stat:.2f}, p = {p_val:.4f} >= 0.05)."
    )

    return {
        "f_statistic": float(f_stat),
        "p_value": float(p_val),
        "is_significant": bool(is_sig),
        "interpretation": interp
    }

def run_ttest_gender_pay(df: pd.DataFrame) -> dict:
    """
    Independent two-sample Welch's t-test comparing Male vs Female base salaries.
    """
    male_sal = df[df['gender'] == 'Male']['base_salary'].dropna()
    female_sal = df[df['gender'] == 'Female']['base_salary'].dropna()

    if len(male_sal) < 10 or len(female_sal) < 10:
        return {"error": "Insufficient sample size for T-Test"}

    t_stat, p_val = stats.ttest_ind(male_sal, female_sal, equal_var=False)
    male_mean = float(male_sal.mean())
    female_mean = float(female_sal.mean())
    gap_pct = ((male_mean - female_mean) / male_mean) * 100 if male_mean != 0 else 0

    is_sig = p_val < 0.05
    interp = (
        f"Statistically significant pay difference observed (t = {t_stat:.2f}, p = {p_val:.4e} < 0.05). "
        f"Male mean: ${male_mean:,.0f} vs Female mean: ${female_mean:,.0f} (Gap: {gap_pct:.1f}%)."
        if is_sig else
        f"No statistically significant gender pay difference found (t = {t_stat:.2f}, p = {p_val:.4f} >= 0.05). "
        f"Male mean: ${male_mean:,.0f} vs Female mean: ${female_mean:,.0f} (Gap: {gap_pct:.1f}%)."
    )

    return {
        "t_statistic": float(t_stat),
        "p_value": float(p_val),
        "male_mean": male_mean,
        "female_mean": female_mean,
        "pay_gap_pct": gap_pct,
        "is_significant": bool(is_sig),
        "interpretation": interp
    }

def run_chi_square_attrition_department(df: pd.DataFrame) -> dict:
    """
    Chi-Square Test of Independence between Department and Attrition status.
    """
    contingency_table = pd.crosstab(df['department_name'], df['is_attrited'])
    if contingency_table.shape[0] < 2 or contingency_table.shape[1] < 2:
        return {"error": "Insufficient contingency dimensions"}

    chi2, p_val, dof, _ = stats.chi2_contingency(contingency_table)
    is_sig = p_val < 0.05
    interp = (
        f"Significant association between department and employee turnover (Chi2 = {chi2:.2f}, p = {p_val:.4e}, df = {dof}). "
        "Certain departments suffer disproportionately higher attrition."
        if is_sig else
        f"Attrition is uniformly distributed across departments without significant dependence (Chi2 = {chi2:.2f}, p = {p_val:.4f}, df = {dof})."
    )

    return {
        "chi2": float(chi2),
        "p_value": float(p_val),
        "dof": int(dof),
        "is_significant": bool(is_sig),
        "interpretation": interp
    }

def simulate_cost_scenario(
    df: pd.DataFrame,
    salary_increment_pct: float = 0.0,
    overtime_reduction_pct: float = 0.0,
    attrition_reduction_pct: float = 0.0,
    retention_program_spend_per_head: float = 0.0,
    training_adjustment_pct: float = 0.0
) -> dict:
    """
    Simulates What-If budget scenarios against the active workforce.
    Returns comparison between baseline spend and simulated scenario spend.
    """
    if df.empty:
        return {}

    # Baseline calculations
    base_salary_total = float(df['base_salary'].sum())
    base_ot_total = float(df['total_overtime_cost'].sum())
    base_benefits_total = float(df['total_benefits_cost'].sum())
    base_training_total = float(df['total_training_cost'].sum())
    base_attrition_total = float(df['total_attrition_cost'].sum())
    total_baseline = base_salary_total + base_ot_total + base_benefits_total + base_training_total + base_attrition_total

    # Scenario adjustments
    sim_salary_total = base_salary_total * (1.0 + salary_increment_pct / 100.0)
    # Benefits scale with base salary proportionally
    sim_benefits_total = base_benefits_total * (1.0 + (salary_increment_pct * 0.7) / 100.0)
    sim_ot_total = base_ot_total * (1.0 - overtime_reduction_pct / 100.0)
    sim_attrition_total = base_attrition_total * (1.0 - attrition_reduction_pct / 100.0)
    sim_training_total = base_training_total * (1.0 + training_adjustment_pct / 100.0)
    
    # Retention program investment
    active_count = int((df['is_attrited'] == 0).sum())
    retention_investment = active_count * retention_program_spend_per_head

    total_scenario = (
        sim_salary_total +
        sim_ot_total +
        sim_benefits_total +
        sim_training_total +
        sim_attrition_total +
        retention_investment
    )

    net_variance = total_scenario - total_baseline
    net_savings = -net_variance

    return {
        "baseline": {
            "base_salary": base_salary_total,
            "overtime": base_ot_total,
            "benefits": base_benefits_total,
            "training": base_training_total,
            "attrition_loss": base_attrition_total,
            "retention_program": 0.0,
            "total_spend": total_baseline
        },
        "scenario": {
            "base_salary": sim_salary_total,
            "overtime": sim_ot_total,
            "benefits": sim_benefits_total,
            "training": sim_training_total,
            "attrition_loss": sim_attrition_total,
            "retention_program": retention_investment,
            "total_spend": total_scenario
        },
        "variance": {
            "net_difference": net_variance,
            "net_savings": net_savings,
            "pct_change": (net_variance / total_baseline * 100) if total_baseline > 0 else 0.0
        }
    }
