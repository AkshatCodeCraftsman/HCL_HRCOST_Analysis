"""
modules/db.py - SQLite Database Connector and Query Manager
Provides caching, initialization checks, and unified workforce views.
"""

import sqlite3
import os
import pandas as pd
import streamlit as st

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "hr_cost_analysis.db")

def get_connection():
    """Establish and return SQLite connection."""
    ensure_db_initialized()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_db_initialized():
    """Checks if SQLite database exists; if not, triggers seed_data generator automatically."""
    if not os.path.exists(DB_PATH) or os.path.getsize(DB_PATH) < 1000:
        from data.seed_data import generate_database
        generate_database()

@st.cache_data(ttl=600, show_spinner=False)
def load_workforce_data():
    """
    Loads unified workforce dataset with all joined dimensions:
    employees, departments, compensation, talent_acquisition,
    learning_development, and turnover_costs.
    """
    ensure_db_initialized()
    conn = sqlite3.connect(DB_PATH)
    
    query = """
    SELECT 
        e.employee_id,
        e.first_name,
        e.last_name,
        (e.first_name || ' ' || e.last_name) AS full_name,
        e.gender,
        e.age,
        e.education,
        e.department_id,
        d.department_name,
        d.cost_center_code,
        e.job_role,
        e.job_level,
        e.location,
        e.employment_type,
        e.hire_date,
        e.tenure_years,
        e.performance_rating,
        e.is_attrited,
        e.attrition_date,
        e.attrition_reason,
        e.flight_risk,
        -- Compensation
        c.base_salary,
        c.annual_bonus,
        c.health_insurance_cost,
        c.retirement_benefits_cost,
        c.allowances,
        c.annual_overtime_hours,
        c.overtime_hourly_rate,
        c.total_overtime_cost,
        c.total_direct_comp,
        c.total_benefits_cost,
        c.total_annual_cost,
        -- Recruitment
        ta.recruitment_channel,
        ta.sourcing_cost,
        ta.agency_fees,
        ta.onboarding_cost,
        ta.signon_bonus,
        ta.time_to_hire_days,
        ta.total_acquisition_cost,
        -- Learning & Development
        ld.courses_completed,
        ld.training_hours,
        ld.certification_cost,
        ld.lms_license_cost,
        ld.external_workshop_cost,
        ld.total_training_cost,
        ld.skill_gap_reduction_pct,
        -- Turnover Costs (NULL for active employees)
        tc.exit_interview_admin_cost,
        tc.lost_productivity_cost,
        tc.replacement_recruitment_cost,
        tc.replacement_training_rampup_cost,
        COALESCE(tc.total_attrition_cost, 0.0) AS total_attrition_cost
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    JOIN compensation c ON e.employee_id = c.employee_id
    JOIN talent_acquisition ta ON e.employee_id = ta.employee_id
    JOIN learning_development ld ON e.employee_id = ld.employee_id
    LEFT JOIN turnover_costs tc ON e.employee_id = tc.employee_id
    """
    
    df = pd.read_sql_query(query, conn)
    conn.close()
    
    # Cast date columns
    df['hire_date'] = pd.to_datetime(df['hire_date'], errors='coerce')
    df['attrition_date'] = pd.to_datetime(df['attrition_date'], errors='coerce')
    return df

@st.cache_data(ttl=600, show_spinner=False)
def get_departments_meta():
    """Fetch departments metadata including budgets and targets."""
    ensure_db_initialized()
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM departments ORDER BY department_name", conn)
    conn.close()
    return df

@st.cache_data(ttl=600, show_spinner=False)
def get_company_kpis():
    """Fetch historical company financials for HC ROI tracking."""
    ensure_db_initialized()
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM company_kpis ORDER BY fiscal_year ASC", conn)
    conn.close()
    return df

def execute_custom_sql(sql_query: str):
    """
    Executes a user-provided SQL query safely for the SQL Explorer tab.
    Enforces read-only operations for dashboard safety.
    """
    ensure_db_initialized()
    clean_sql = sql_query.strip()
    first_word = clean_sql.split()[0].upper() if clean_sql else ""
    if first_word not in ["SELECT", "WITH", "EXPLAIN", "PRAGMA"]:
        raise ValueError("Only read-only queries (SELECT, WITH, PRAGMA) are permitted.")
        
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(clean_sql, conn)
    conn.close()
    return df
