"""
modules/ui_components.py - Modern Tailwind UI Component Library for Streamlit
Provides responsive card grids, KPI stat tiles, badge pills, callout alerts,
and custom Tailwind CSS styling.
"""

import streamlit as st

def inject_tailwind_styles():
    """Injects comprehensive Tailwind-inspired CSS into Streamlit DOM."""
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

    /* Global Typography & Background */
    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    
    code, pre, .stCode {
        font-family: 'JetBrains Mono', monospace !important;
    }

    /* Streamlit Main Content Container Padding */
    .block-container {
        padding-top: 1.5rem !important;
        padding-bottom: 3.5rem !important;
        padding-left: 2rem !important;
        padding-right: 2rem !important;
        max-width: 1440px !important;
    }

    /* Tailwind-style Metric Cards */
    .tw-card {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.85) 0%, rgba(15, 23, 42, 0.95) 100%);
        border: 1px solid rgba(71, 85, 105, 0.45);
        border-radius: 1rem;
        padding: 1.25rem 1.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -4px rgba(0, 0, 0, 0.2);
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }
    
    .tw-card:hover {
        transform: translateY(-2px);
        border-color: rgba(99, 102, 241, 0.6);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4), 0 8px 10px -6px rgba(0, 0, 0, 0.3);
    }

    /* Accent top bars */
    .tw-card-accent-indigo::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #4f46e5, #818cf8);
    }

    .tw-card-accent-emerald::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #10b981, #34d399);
    }

    .tw-card-accent-amber::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #f59e0b, #fbbf24);
    }

    .tw-card-accent-rose::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #ef4444, #f87171);
    }

    .tw-card-accent-cyan::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #06b6d4, #38bdf8);
    }

    .tw-card-accent-violet::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #8b5cf6, #c084fc);
    }

    /* Card Typography */
    .tw-card-title {
        color: #94a3b8;
        font-size: 0.8125rem;
        font-weight: 600;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-bottom: 0.375rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .tw-card-value {
        color: #f8fafc;
        font-size: 1.875rem;
        font-weight: 800;
        line-height: 2.25rem;
        letter-spacing: -0.025em;
        margin-bottom: 0.25rem;
    }

    .tw-card-subtext {
        color: #64748b;
        font-size: 0.8125rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Badges */
    .tw-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.2rem 0.625rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.025em;
        line-height: 1;
    }

    .tw-badge-indigo {
        background-color: rgba(99, 102, 241, 0.15);
        color: #a5b4fc;
        border: 1px solid rgba(99, 102, 241, 0.35);
    }

    .tw-badge-emerald {
        background-color: rgba(16, 185, 129, 0.15);
        color: #6ee7b7;
        border: 1px solid rgba(16, 185, 129, 0.35);
    }

    .tw-badge-amber {
        background-color: rgba(245, 158, 11, 0.15);
        color: #fcd34d;
        border: 1px solid rgba(245, 158, 11, 0.35);
    }

    .tw-badge-rose {
        background-color: rgba(239, 68, 68, 0.15);
        color: #fca5a5;
        border: 1px solid rgba(239, 68, 68, 0.35);
    }

    .tw-badge-cyan {
        background-color: rgba(6, 182, 212, 0.15);
        color: #67e8f9;
        border: 1px solid rgba(6, 182, 212, 0.35);
    }

    /* Alert / Callout Boxes */
    .tw-alert {
        border-radius: 0.75rem;
        padding: 1rem 1.25rem;
        margin-bottom: 1.25rem;
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        border: 1px solid transparent;
    }

    .tw-alert-info {
        background-color: rgba(30, 41, 59, 0.7);
        border-color: rgba(99, 102, 241, 0.3);
        color: #cbd5e1;
    }

    .tw-alert-success {
        background-color: rgba(6, 78, 59, 0.35);
        border-color: rgba(16, 185, 129, 0.35);
        color: #a7f3d0;
    }

    .tw-alert-warning {
        background-color: rgba(120, 53, 15, 0.35);
        border-color: rgba(245, 158, 11, 0.35);
        color: #fde68a;
    }

    /* Hero Banner Header */
    .tw-hero {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.9) 0%, rgba(15, 23, 42, 0.98) 100%);
        border: 1px solid rgba(71, 85, 105, 0.5);
        border-radius: 1.25rem;
        padding: 1.75rem 2rem;
        margin-bottom: 1.75rem;
        position: relative;
        overflow: hidden;
    }

    .tw-hero::after {
        content: '';
        position: absolute;
        top: -50%; right: -20%;
        width: 350px; height: 350px;
        background: radial-gradient(circle, rgba(99, 102, 241, 0.15) 0%, transparent 70%);
        pointer-events: none;
    }

    .tw-hero-title {
        font-size: 1.875rem;
        font-weight: 800;
        color: #f8fafc;
        letter-spacing: -0.025em;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .tw-hero-subtitle {
        color: #94a3b8;
        font-size: 0.9375rem;
        line-height: 1.5;
        max-width: 850px;
    }

    /* Section Subheaders */
    .tw-section-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #f1f5f9;
        margin-top: 1.5rem;
        margin-bottom: 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Streamlit Tab Enhancements */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
        background-color: rgba(15, 23, 42, 0.75);
        padding: 0.375rem;
        border-radius: 0.75rem;
        border: 1px solid rgba(51, 65, 85, 0.5);
    }

    .stTabs [data-baseweb="tab"] {
        border-radius: 0.5rem;
        padding: 0.5rem 1rem;
        color: #94a3b8;
        font-weight: 600;
        font-size: 0.875rem;
        border: none !important;
        background: transparent;
        transition: all 0.15s ease;
    }

    .stTabs [aria-selected="true"] {
        background-color: #4f46e5 !important;
        color: #ffffff !important;
        box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.3);
    }

    /* Custom Scrollbars */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    ::-webkit-scrollbar-track {
        background: #0f172a;
    }
    ::-webkit-scrollbar-thumb {
        background: #334155;
        border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: #475569;
    }
    </style>
    """, unsafe_allow_html=True)

def render_hero_header(title: str, subtitle: str, badge_text: str = "HCL Project Submission"):
    """Renders sleek hero banner with title, description, and metadata badge."""
    st.markdown(f"""
    <div class="tw-hero">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 0.75rem;">
            <div>
                <div class="tw-hero-title">
                    <span>{title}</span>
                </div>
                <div class="tw-hero-subtitle">{subtitle}</div>
            </div>
            <div>
                <span class="tw-badge tw-badge-indigo">{badge_text}</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

def render_kpi_card(title: str, value: str, subtext: str = "", delta: str = None, 
                    delta_positive: bool = True, color_accent: str = "indigo", icon: str = None):
    """
    Renders an individual Tailwind-styled KPI card.
    `color_accent` options: 'indigo', 'emerald', 'amber', 'rose', 'cyan', 'violet'.
    """
    delta_html = ""
    if delta:
        delta_class = "tw-badge-emerald" if delta_positive else "tw-badge-rose"
        delta_sign = "+" if delta_positive and not delta.startswith("+") and not delta.startswith("-") else ""
        delta_html = f'<span class="tw-badge {delta_class}">{delta_sign}{delta}</span>'

    icon_html = f'<span style="font-size: 1.1rem; opacity: 0.85;">{icon}</span>' if icon else ''

    html = f"""
    <div class="tw-card tw-card-accent-{color_accent}">
        <div class="tw-card-title">
            <span>{title}</span>
            {icon_html}
        </div>
        <div class="tw-card-value">{value}</div>
        <div class="tw-card-subtext">
            {delta_html}
            <span>{subtext}</span>
        </div>
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)

def render_section_header(title: str, subtitle: str = None, badge: str = None):
    """Renders a section title with optional subtitle and badge."""
    badge_html = f'<span class="tw-badge tw-badge-cyan" style="margin-left: 0.5rem;">{badge}</span>' if badge else ""
    st.markdown(f"""
    <div style="margin-top: 1.75rem; margin-bottom: 0.75rem;">
        <div class="tw-section-title">
            <span>{title}</span>
            {badge_html}
        </div>
        {f'<div style="color: #64748b; font-size: 0.875rem; margin-top: -0.25rem;">{subtitle}</div>' if subtitle else ''}
    </div>
    """, unsafe_allow_html=True)

def render_alert(message: str, alert_type: str = "info", title: str = None):
    """
    Renders Tailwind alert callout.
    alert_type: 'info', 'success', 'warning'
    """
    icons = {
        "info": "💡",
        "success": "✅",
        "warning": "⚠️"
    }
    icon = icons.get(alert_type, "ℹ️")
    title_html = f'<strong style="display: block; margin-bottom: 0.25rem; color: #f1f5f9;">{title}</strong>' if title else ""
    st.markdown(f"""
    <div class="tw-alert tw-alert-{alert_type}">
        <div style="font-size: 1.25rem; line-height: 1;">{icon}</div>
        <div>
            {title_html}
            <div style="font-size: 0.875rem; line-height: 1.45;">{message}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
