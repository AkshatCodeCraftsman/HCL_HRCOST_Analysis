# 💼 HR Cost Analysis & Workforce Economics System
### HCL Final Project Submission | Executive Intelligence & Strategic Optimization Portal

[![Python](https://img.shields.io/badge/Python-3.12-3776AB?logo=python&logoColor=white)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.40+-FF4B4B?logo=streamlit&logoColor=white)](https://streamlit.io)
[![SQLite](https://img.shields.io/badge/Database-SQLite3-003B57?logo=sqlite&logoColor=white)](https://sqlite.org)
[![Plotly](https://img.shields.io/badge/Charts-Plotly%20Interactive-3F4F75?logo=plotly&logoColor=white)](https://plotly.com)
[![SciPy](https://img.shields.io/badge/Statistics-SciPy%20%26%20Hypothesis%20Testing-8CAAE6?logo=scipy&logoColor=white)](https://scipy.org)
[![pytest](https://img.shields.io/badge/Tests-pytest%20Passing-0A9EDC?logo=pytest&logoColor=white)](https://pytest.org)
[![Design](https://img.shields.io/badge/UI-Tailwind%20Styled%20Design-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com)

---

## 📌 Executive Summary

Human capital represents the single largest operational expenditure in global IT and technology enterprises such as **HCL Technologies**—frequently accounting for **60% to 75% of total operating expenses**. Inefficiencies in overtime allocation, recruitment churn, unplanned turnover, and training misalignment directly depress operating margins.

This project delivers an end-to-end, enterprise-ready **HR Cost Analysis and Strategic Optimization Application** built using **Python, Streamlit, SQLite, Plotly, SciPy, and Tailwind UI aesthetics**. It transforms transactional workforce data into actionable fiscal intelligence, pinpointing overtime cost leakage, replacement cost liabilities, pay equity balance, and what-if financial projections.

---

## 🛠️ Complete Tech Stack

| Layer | Technology | Purpose & Capabilities |
| :--- | :--- | :--- |
| **Frontend & Application** | **Streamlit** (v1.35+) | High-performance reactive web application with interactive tab routing and global filters. |
| **UI Design System** | **Tailwind-inspired CSS** | Modern dark-slate aesthetic (`#0f172a`), responsive metric cards, accent bars, badge pills, and custom typography. |
| **Database & Persistence** | **SQLite3** | Normalized relational database with referential integrity, indexing, and auto-seeding. |
| **Data Manipulation** | **Pandas & NumPy** | In-memory data aggregation, feature engineering, and high-speed multi-dimensional slicing. |
| **Data Visualization** | **Plotly Express & Graph Objects** | Interactive charts: waterfall analysis, 2D heatmaps, violin/box dispersion, donut breakdowns, and regression scatter plots. |
| **Inferential Statistics** | **SciPy (stats)** | Parametric/non-parametric distribution modeling, One-Way ANOVA, Welch's T-Test, and Chi-Square tests. |
| **Quality Assurance** | **pytest** | Automated unit test suite verifying database integrity, KPI calculations, and scenario logic. |
| **Cloud Deployment** | **Streamlit Community Cloud** | 100% cloud-ready repository structure with headless configuration and automated DB initialization. |

---

## 🏛️ Application Architecture & Project Layout

```
hr_cost_analysis/
│
├── .streamlit/
│   └── config.toml             # Streamlit theme (primary: #4f46e5, bg: #0f172a, text: #f8fafc)
│
├── data/
│   ├── schema.sql              # Normalized DDL schema for SQLite (7 tables, indexes, foreign keys)
│   ├── seed_data.py            # Synthetic enterprise HR data generator (1,000 employees across 8 departments)
│   └── hr_cost_analysis.db     # Populated SQLite database (auto-generated on startup if missing)
│
├── modules/
│   ├── __init__.py
│   ├── db.py                   # SQLite connection manager, caching (@st.cache_data), and safe SQL runner
│   ├── analytics.py            # Business logic: KPIs, parametric stats, ANOVA, T-Test, Chi-Square, what-if engine
│   ├── charts.py               # Dark-mode Plotly visualizations with consistent Tailwind styling
│   └── ui_components.py        # Tailwind UI components: metric cards, badges, hero headers, alert boxes
│
├── views/
│   ├── __init__.py
│   ├── overview.py             # Executive summary dashboard, high-level KPIs, and HC ROI trends
│   ├── compensation.py         # Base salary bands, benefits, overtime hotspots, and pay equity audit
│   ├── attrition.py            # Turnover rate, replacement cost waterfall, exit reasons, and flight risk watch
│   ├── recruitment_training.py # Cost-per-hire matrix, channel efficiency, and learning ROI regression
│   ├── statistics_eda.py       # Univariate shape analysis (skew/kurtosis), correlation matrix, hypothesis tests
│   ├── scenario_planner.py     # Interactive what-if policy simulator (merit raise, overtime reduction, retention ROI)
│   └── sql_explorer.py         # Live SQLite query editor, preset queries, schema reference, and CSV export
│
├── tests/
│   ├── __init__.py
│   ├── test_db.py              # Tests for DB connectivity, table schema, employee count, and SQL safety
│   ├── test_analytics.py       # Tests for KPI arithmetic, summary rollups, and hypothesis tests
│   └── test_simulator.py       # Tests for what-if scenario mathematics and retention ROI
│
├── app.py                      # Main application entry point with sidebar filtering and tab routing
├── pytest.ini                  # Pytest configuration
├── requirements.txt            # Production dependencies
└── README.md                   # Comprehensive project documentation
```

---

## 📊 Core Application Features & Business Modules

### 1. 📊 Executive Overview & Workforce Economics
- **Real-Time KPIs**: Total Headcount, Full-Load Annual HR Spend, Average Cost per Employee, Overtime % of Base Payroll, and Total Attrition Loss.
- **Cost Composition Donut**: Visualizes the proportional split between Base Payroll, Benefits, Overtime, Talent Acquisition, Training, and Turnover.
- **Departmental Cost Stacking**: Comparative horizontal bar chart benchmarked across all 8 enterprise divisions.
- **Human Capital ROI (HC ROI)**: Multi-year trend correlating annual corporate revenue against workforce investments.

### 2. 💵 Compensation, Payroll & Overtime Diagnostics
- **Salary Dispersion Analysis**: Violin and box plots sliceable by Job Level, Department, Education, or Location.
- **Overtime Hotspots Heatmap**: Two-dimensional heatmap identifying acute overtime hours across Department vs. Job Level (highlighting Operations and Cloud Support tiers).
- **Pay Equity Audit**: Independent Welch's Two-Sample T-test auditing gender base pay variance.
- **Top Overtime Burden Roles**: Tabular ranking of roles driving excessive overtime expenditures.

### 3. 📉 Attrition Dynamics & Replacement Cost Forensics
- **Turnover Financial Anatomy (Waterfall Chart)**:
  - Exit & administrative processing
  - Lost productivity during position vacancy
  - Replacement recruitment & agency sourcing costs
  - Onboarding ramp-up learning curve productivity loss
- **Exit Driver Analysis**: Distribution of exit interview rationales (Compensation, Career Growth, Burnout, Relocation).
- **Critical Talent Flight-Risk Watchlist**: Identifies high-performing staff (`performance_rating >= 3.8`) flagged as High Flight Risk, computing their individual replacement financial liability.

### 4. 🎯 Talent Acquisition & Learning ROI Analytics
- **Channel Efficiency Matrix**: Multi-dimensional bubble chart plotting Average Time-to-Hire (days) vs. Average Cost per Hire ($), sized by volume of hires.
- **Conduit Comparison**: Benchmarks Agency Fees, Campus Placement, Direct Referrals, LinkedIn Job Portals, and Internal Transfers.
- **Learning & Development Impact**: Scatter plot with Ordinary Least Squares (OLS) trendline proving the positive relationship between Training Hours and Skill Gap Reduction %.

### 5. 🔬 Exploratory Data Analysis & Inferential Statistics Lab
- **Univariate Distribution Inspector**:
  - Computes Mean ($\mu$), Median, Standard Deviation ($\sigma$), Interquartile Range (IQR), Skewness, and Kurtosis.
  - Empirical histogram with box-plot marginals for any selected numeric dimension.
- **Multivariate Pearson Correlation Matrix**: Full correlation heatmap uncovering collinearity between compensation, age, tenure, overtime, and performance.
- **Hypothesis Testing Lab**:
  1. **One-Way ANOVA**: Validates whether mean base salaries differ significantly across departments ($F$-statistic, $p$-value).
  2. **Welch's Two-Sample T-Test**: Evaluates compensation parity between demographic cohorts.
  3. **Chi-Square ($\chi^2$) Test of Independence**: Tests whether employee turnover depends on departmental placement.

### 6. 🔮 Interactive What-If Budget Scenario Simulator
- Dynamic sliders allowing enterprise leaders to test policy interventions:
  - **Annual Merit Salary Increment (%)**: 0% to 15%
  - **Overtime Reduction Target (%)**: 0% to 60%
  - **Attrition Reduction Target (%)**: 0% to 50%
  - **Targeted Retention Investment ($ / employee)**: $0 to $2,500
  - **Training Budget Adjustment (%)**: -25% to +50%
- Real-time comparison between Baseline and Projected Spend.
- Computes **Net Budget Variance** and **Retention Net Value Created** (Turnover financial loss avoided minus retention program budget).

### 7. 💾 Interactive SQLite Query Console
- Live SQL query editor with safety checks (enforcing read-only `SELECT` statements).
- Curated preset queries (e.g., Top Overtime Earners, High-Risk Talent, Department Cost Summary).
- Interactive results table with instant **CSV Export** functionality.

---

## 🗄️ Database Schema & Data Modeling

The SQLite database (`hr_cost_analysis.db`) contains 7 normalized tables:

1. **`departments`**: Cost center codes, headcount targets, training budgets, and recruitment budgets.
2. **`employees`**: Demographics (gender, age, education), role, level, location, hire date, tenure, performance rating, flight risk, and attrition status.
3. **`compensation`**: Base salary, annual bonus, health insurance, retirement benefits, allowances, overtime hours, and full-load annual cost.
4. **`talent_acquisition`**: Recruitment channel, sourcing expense, agency fees, onboarding cost, sign-on bonus, and time-to-hire.
5. **`learning_development`**: Courses completed, training hours, certification expense, LMS license, and skill gap reduction %.
6. **`turnover_costs`**: Granular breakdown of administrative, vacancy, recruitment replacement, and ramp-up costs for departed personnel.
7. **`company_kpis`**: Multi-year corporate fiscal records (Revenue, Opex, Total Headcount, Total HR Spend, and HC ROI).

---

## 🚀 Running the Project Locally

### Prerequisites
- Python 3.10, 3.11, or 3.12 installed.

### Step 1: Clone or Navigate to Project Directory
```bash
cd "C:\Users\aksha\.gemini\antigravity\scratch\hr_cost_analysis"
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: (Optional) Re-seed the Database
The database seeds automatically on first launch, but can be regenerated anytime:
```bash
python data/seed_data.py
```

### Step 4: Run the Streamlit Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 🧪 Running Automated Tests (pytest)

The project includes an automated unit test suite verifying database integrity, KPI calculations, and simulation logic:

```bash
pytest -v
```

### Sample Output:
```text
============================= test session starts =============================
platform win32 -- Python 3.12.10, pytest-9.2.0, pluggy-1.7.0
rootdir: C:\Users\aksha\.gemini\antigravity\scratch\hr_cost_analysis
configfile: pytest.ini
testpaths: tests
collected 11 items

tests/test_analytics.py::test_calculate_core_kpis PASSED                 [  9%]
tests/test_analytics.py::test_department_summary PASSED                  [ 18%]
tests/test_analytics.py::test_statistical_summary PASSED                 [ 27%]
tests/test_analytics.py::test_hypothesis_tests PASSED                    [ 36%]
tests/test_db.py::test_db_exists_and_connects PASSED                     [ 45%]
tests/test_db.py::test_workforce_headcount PASSED                        [ 54%]
tests/test_db.py::test_execute_custom_sql_readonly PASSED                [ 63%]
tests/test_simulator.py::test_simulation_zero_change PASSED              [ 72%]
tests/test_simulator.py::test_salary_increase_simulation PASSED          [ 81%]
tests/test_simulator.py::test_overtime_reduction_simulation PASSED       [ 90%]
tests/test_simulator.py::test_retention_program_roi PASSED               [100%]

======================== 11 passed, 1 warning in 6.96s ========================
```

---

## ☁️ Streamlit Community Cloud Deployment Guide

This repository is ready for immediate one-click deployment to **Streamlit Community Cloud**:

1. **Push the project to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: HCL HR Cost Analysis System"
   git remote add origin https://github.com/<your-username>/hr-cost-analysis.git
   git push -u origin main
   ```
2. **Deploy on Streamlit Community Cloud**:
   - Navigate to [share.streamlit.io](https://share.streamlit.io).
   - Sign in with your GitHub account.
   - Click **"New app"**.
   - Select your repository (`<your-username>/hr-cost-analysis`) and branch (`main`).
   - Set **Main file path** to `app.py`.
   - Click **"Deploy!"**.
3. **Automatic DB Bootstrap**:
   - `modules/db.py` contains `ensure_db_initialized()`, ensuring the SQLite database is automatically generated in the cloud container on startup without any manual steps!

---

## 🏆 HCL Evaluation Checklist

- [x] **Python + Streamlit application** with responsive sidebar filters and multi-tab routing.
- [x] **Full-spectrum HR Cost Analytics**: Payroll, Benefits, Overtime, Recruitment, Learning, and Turnover.
- [x] **Statistical EDA & Inferential Tests**: Parametric/non-parametric summaries, One-Way ANOVA, Welch's T-Test, and Chi-Square.
- [x] **Interactive Plotly Visualizations**: Waterfall, 2D Heatmap, Box/Violin, Donut, and Regression Bubble charts.
- [x] **Tailwind UI Aesthetics**: Custom dark-mode typography, gradient accent cards, status badges, and alert banners.
- [x] **SQLite Relational Engine**: Normalized schema with indexes, foreign keys, and read-only ad-hoc query console.
- [x] **pytest Unit Test Suite**: 11 passing tests validating data, math, and simulations.
- [x] **Streamlit Community Cloud Ready**: Configured `.streamlit/config.toml`, clean `requirements.txt`, and zero-friction deployment.

---
*Created for the HCL Final Project Review.*
