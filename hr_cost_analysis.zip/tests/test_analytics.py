"""
tests/test_analytics.py - Unit Tests for Core HR Cost Analytics and Hypothesis Testing
"""

import pytest
import pandas as pd
import numpy as np
from modules.analytics import (
    calculate_core_kpis,
    calculate_department_summary,
    calculate_statistical_summary,
    run_anova_salary_by_department,
    run_ttest_gender_pay,
    run_chi_square_attrition_department
)

@pytest.fixture
def sample_workforce_df():
    """Generates synthetic dataframe fixture for isolated unit testing."""
    np.random.seed(42)
    n = 100
    depts = ["Engineering", "Operations", "Sales", "Data & AI"]
    genders = ["Male", "Female"]
    
    data = {
        "employee_id": [f"TEST-{i:03d}" for i in range(n)],
        "department_name": np.random.choice(depts, n),
        "gender": np.random.choice(genders, n),
        "job_level": np.random.choice(["Junior", "Mid-Level", "Senior"], n),
        "is_attrited": np.random.choice([0, 1], n, p=[0.85, 0.15]),
        "base_salary": np.random.normal(85000, 20000, n).clip(40000, 180000),
        "total_overtime_cost": np.random.exponential(2500, n),
        "annual_overtime_hours": np.random.exponential(40, n),
        "total_benefits_cost": np.random.normal(15000, 3000, n).clip(8000, 30000),
        "total_annual_cost": np.random.normal(110000, 25000, n).clip(50000, 220000),
        "total_acquisition_cost": np.random.uniform(2000, 8000, n),
        "time_to_hire_days": np.random.randint(15, 60, n),
        "total_training_cost": np.random.uniform(500, 3000, n),
        "training_hours": np.random.uniform(10, 60, n),
        "total_attrition_cost": np.where(np.random.choice([0, 1], n, p=[0.85, 0.15]) == 1, 25000.0, 0.0)
    }
    return pd.DataFrame(data)

def test_calculate_core_kpis(sample_workforce_df):
    """Test core KPI arithmetic accuracy."""
    kpis = calculate_core_kpis(sample_workforce_df)
    assert kpis["total_headcount"] == 100
    assert kpis["active_headcount"] + kpis["attrited_headcount"] == 100
    assert kpis["total_annual_cost"] == pytest.approx(sample_workforce_df["total_annual_cost"].sum())
    assert kpis["total_base_payroll"] == pytest.approx(sample_workforce_df["base_salary"].sum())
    assert kpis["avg_cost_per_employee"] == pytest.approx(sample_workforce_df["total_annual_cost"].mean())
    assert 0 <= kpis["attrition_rate"] <= 100

def test_department_summary(sample_workforce_df):
    """Test departmental rollup matches aggregate workforce totals."""
    summary = calculate_department_summary(sample_workforce_df)
    assert len(summary) == 4  # 4 departments
    assert summary["Headcount"].sum() == 100

def test_statistical_summary(sample_workforce_df):
    """Test parametric and shape stats calculation."""
    stats = calculate_statistical_summary(sample_workforce_df, "base_salary")
    assert stats["count"] == 100
    assert stats["q3"] >= stats["median"] >= stats["q1"]
    assert stats["iqr"] == pytest.approx(stats["q3"] - stats["q1"])
    assert isinstance(stats["skewness"], float)
    assert isinstance(stats["kurtosis"], float)

def test_hypothesis_tests(sample_workforce_df):
    """Verify ANOVA, T-Test, and Chi-Square outputs."""
    anova_res = run_anova_salary_by_department(sample_workforce_df)
    assert "f_statistic" in anova_res
    assert "p_value" in anova_res
    assert 0.0 <= anova_res["p_value"] <= 1.0

    ttest_res = run_ttest_gender_pay(sample_workforce_df)
    assert "t_statistic" in ttest_res
    assert "p_value" in ttest_res
    assert 0.0 <= ttest_res["p_value"] <= 1.0

    chi_res = run_chi_square_attrition_department(sample_workforce_df)
    assert "chi2" in chi_res
    assert "p_value" in chi_res
    assert chi_res["dof"] > 0
