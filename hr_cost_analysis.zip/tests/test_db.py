"""
tests/test_db.py - Unit Tests for SQLite Database & Data Layer
"""

import os
import sqlite3
import pytest
import pandas as pd
from modules.db import get_connection, ensure_db_initialized, load_workforce_data, execute_custom_sql

def test_db_exists_and_connects():
    """Verify database initializes properly and connection is active."""
    ensure_db_initialized()
    conn = get_connection()
    assert conn is not None
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cursor.fetchall()]
    conn.close()

    expected_tables = ["departments", "employees", "compensation", "talent_acquisition", "learning_development", "turnover_costs", "company_kpis"]
    for t in expected_tables:
        assert t in tables, f"Expected table '{t}' not found in database."

def test_workforce_headcount():
    """Verify exactly 1,000 employees seeded with referential integrity."""
    df = load_workforce_data()
    assert len(df) == 1000
    assert "base_salary" in df.columns
    assert "total_annual_cost" in df.columns
    assert "department_name" in df.columns
    assert df["base_salary"].min() > 20000

def test_execute_custom_sql_readonly():
    """Verify SQL safety: SELECT permitted, mutations blocked."""
    # Permitted query
    res = execute_custom_sql("SELECT COUNT(*) AS total FROM employees")
    assert isinstance(res, pd.DataFrame)
    assert res.iloc[0]["total"] == 1000

    # Blocked mutations
    with pytest.raises(ValueError, match="Only read-only queries"):
        execute_custom_sql("DROP TABLE employees")

    with pytest.raises(ValueError, match="Only read-only queries"):
        execute_custom_sql("DELETE FROM compensation")
