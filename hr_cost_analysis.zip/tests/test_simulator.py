"""
tests/test_simulator.py - Unit Tests for What-If Scenario Planning Engine
"""

import pytest
import pandas as pd
import numpy as np
from modules.analytics import simulate_cost_scenario

@pytest.fixture
def sim_fixture():
    return pd.DataFrame({
        "employee_id": [f"E-{i}" for i in range(50)],
        "is_attrited": [0]*40 + [1]*10,
        "base_salary": [100000.0] * 50,
        "total_overtime_cost": [10000.0] * 50,
        "total_benefits_cost": [20000.0] * 50,
        "total_training_cost": [2000.0] * 50,
        "total_attrition_cost": [30000.0 if i >= 40 else 0.0 for i in range(50)]
    })

def test_simulation_zero_change(sim_fixture):
    """Test scenario with 0% adjustments matches baseline exactly."""
    res = simulate_cost_scenario(sim_fixture, 0.0, 0.0, 0.0, 0.0, 0.0)
    assert res["baseline"]["total_spend"] == pytest.approx(res["scenario"]["total_spend"])
    assert res["variance"]["net_difference"] == pytest.approx(0.0)
    assert res["variance"]["pct_change"] == pytest.approx(0.0)

def test_salary_increase_simulation(sim_fixture):
    """Test a 10% salary increase correctly increases base salary and scales benefits."""
    res = simulate_cost_scenario(sim_fixture, salary_increment_pct=10.0)
    baseline_sal = res["baseline"]["base_salary"]
    scenario_sal = res["scenario"]["base_salary"]
    assert scenario_sal == pytest.approx(baseline_sal * 1.10)
    assert res["scenario"]["total_spend"] > res["baseline"]["total_spend"]

def test_overtime_reduction_simulation(sim_fixture):
    """Test 25% overtime reduction correctly saves 25% of overtime costs."""
    res = simulate_cost_scenario(sim_fixture, overtime_reduction_pct=25.0)
    baseline_ot = res["baseline"]["overtime"]
    scenario_ot = res["scenario"]["overtime"]
    assert scenario_ot == pytest.approx(baseline_ot * 0.75)

def test_retention_program_roi(sim_fixture):
    """Test retention program investment reduces turnover loss."""
    res = simulate_cost_scenario(
        sim_fixture,
        attrition_reduction_pct=50.0,
        retention_program_spend_per_head=500.0
    )
    baseline_loss = res["baseline"]["attrition_loss"]
    scenario_loss = res["scenario"]["attrition_loss"]
    assert scenario_loss == pytest.approx(baseline_loss * 0.50)
    # Active headcount is 40 -> 40 * 500 = $20,000 investment
    assert res["scenario"]["retention_program"] == pytest.approx(20000.0)
