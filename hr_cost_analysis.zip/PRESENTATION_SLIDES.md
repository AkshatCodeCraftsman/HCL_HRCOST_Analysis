# 📽️ HCL Final Project Presentation Deck & Speaker Script
## HR Cost Analysis & Strategic Workforce Optimization System
**File Format:** PowerPoint (`.pptx`) + Markdown Companion  
**Slides File:** `HCL_HR_Cost_Analysis_Presentation.pptx`  
**Target Audience:** HCL Evaluation Committee, Engineering Directors & CHROs  

---

## Slide 1: Title & Project Scope
- **Title:** HR Cost Analysis & Strategic Workforce Optimization
- **Subtitle:** Enterprise Workforce Economics, Overtime Diagnostics, Attrition Forensics & Predictive Budgeting
- **Context:** HCL Final Technical Project Submission
- **Tech Stack:** Python 3.12 | Streamlit | SQLite3 | Plotly | SciPy | Tailwind UI | pytest

> **🎙️ Speaker Notes (What to Say):**  
> *"Good morning respected evaluators. Today, I am presenting our final project: the HR Cost Analysis and Strategic Workforce Optimization System. Human capital represents 65% to 75% of operating expenditure in global technology enterprises like HCL. However, workforce cost accounting is often fragmented across payroll, recruitment agencies, and departmental silos. Our project delivers an enterprise decision-support portal that consolidates direct payroll, benefits, overtime leakage, turnover replacement costs, and strategic what-if scenario budgeting into a single interactive platform."*

---

## Slide 2: Executive Context & Problem Statement
- **Card 1: Human Capital Burden (65% – 75% of OPEX)**  
  Workforce cost is the largest single expense. Inefficiencies of even 2-3% represent millions in lost operating margins.
- **Card 2: The Hidden Turnover Drain ($3.8M Lost)**  
  Traditional accounting ignores the full-lifecycle cost of attrition: lost vacancy productivity, headhunting fees, and 90-day onboarding ramp-up voids.
- **Card 3: Data-Driven Solution (Predictive Optimization)**  
  Normalized SQLite database, responsive Plotly analytics, inferential hypothesis testing lab, and real-time budget simulation.

> **🎙️ Speaker Notes:**  
> *"When organizations look at workforce spend, they typically only see direct base salary. They miss the hidden icebergs: overtime leakage, escalating agency fees, and especially attrition replacement costs. In our analyzed workforce of 1,000 employees, annual turnover alone bleeds $3.81 million. Our system exposes these hidden costs and models data-backed solutions to capture savings."*

---

## Slide 3: System Architecture & Technical Stack
- **Presentation Tier:** Streamlit 1.35+ with persistent sidebar radio routing and custom Tailwind-inspired CSS styling.
- **Analytics & Math Tier:** SciPy (parametric/shape distributions, One-Way ANOVA, Welch's t-test, Chi-square test) and interactive dark-mode Plotly figures.
- **Data Persistence Tier:** SQLite3 with 7 normalized tables, referential integrity (`PRAGMA foreign_keys = ON`), and in-memory `@st.cache_data`.
- **Quality & Deployment Tier:** 11 automated pytest unit tests (100% passing) and Streamlit Community Cloud zero-configuration self-bootstrapping.

> **🎙️ Speaker Notes:**  
> *"Our architecture follows a clean 3-tier decoupled design. We chose Streamlit coupled with custom Tailwind CSS to achieve a modern SaaS aesthetic with persistent state navigation. On the analytics side, we utilize SciPy and Statsmodels for rigorous inferential testing, and SQLite for structured relational data modeling. The app is 100% cloud-ready with automated self-bootstrapping on Streamlit Community Cloud."*

---

## Slide 4: Normalized Database Schema (7 Tables)
- **`departments`**: Cost center codes, headcount targets, training and recruitment budgets.
- **`employees`**: Central entity with demographics, role, seniority, location/state, tenure, performance, and flight risk.
- **`compensation`**: Base salary, annual bonus, benefits, overtime hours, and full-load cost.
- **`talent_acquisition`**: Channels, sourcing costs, agency fees, onboarding costs, and time-to-hire.
- **`learning_development`**: Upskilling hours, certification costs, LMS licenses, and skill gap reduction %.
- **`turnover_costs`**: Administrative offboarding, vacancy productivity loss, replacement hiring, and ramp-up loss.
- **`company_kpis`**: Multi-year enterprise financials (Revenue, Total HR Spend, and HC ROI).

> **🎙️ Speaker Notes:**  
> *"Rather than relying on flat unorganized CSV files, we engineered a normalized 3NF relational SQLite schema across 7 tables with strict foreign key constraints and indexed lookup columns. This enables sub-millisecond query slicing across departments, seniority tiers, and geographic office locations."*

---

## Slide 5: Executive Dashboard & Core KPIs
- **Headline Metrics:**
  - Total Headcount: **1,000** (Active: 855 | Leavers: 145)
  - Total HR Full-Load Spend: **$112.8M**
  - Average Cost per Employee: **$112,800** (Median: $98,450)
  - Total Overtime Spend: **$2.44M** (3.4% of base payroll)
  - Attrition Financial Loss: **$3.81M** (14.5% turnover rate)
- **Cost Composition:** Base Payroll accounts for 63.8%, Benefits 22.1%, Overtime 2.2%, Talent Acq/L&D 8.5%, and Turnover Loss 3.4%.
- **Human Capital ROI Trend:** FY2023 (1.38) ➔ FY2024 (1.41) ➔ FY2025 (1.45) ➔ FY2026 (1.48).

> **🎙️ Speaker Notes:**  
> *"Here on the Executive Overview, senior leadership gets immediate visibility into workforce performance. Our Human Capital ROI ratio has steadily expanded from 1.38 in 2023 to 1.48 in 2026, demonstrating that human capital investments are yielding positive revenue expansion. However, overtime spend ($2.44M) and turnover loss ($3.81M) represent clear opportunities for operational recapture."*

---

## Slide 6: Compensation, Payroll & Overtime Diagnostics
- **Salary Dispersion:** Base salaries range from $35.5K to $260K+, with clear market differentiation between Engineering/AI and Operations.
- **Overtime Concentration Hotspots:**
  - Digital Foundation (Cloud Support): **42.1 hrs/emp**
  - Digital Process Operations: **48.5 hrs/emp**
  - 80% of overtime is absorbed by Junior and Mid-level personnel, signaling shift staffing deficits during release cycles.
- **Pay Equity Audit:** Welch's Two-Sample t-Test yields $p > 0.05$, validating that gender pay equity is maintained across comparable tenure and seniority levels.

> **🎙️ Speaker Notes:**  
> *"Drilling into compensation diagnostics, our 2D heatmap pinpointed severe overtime burn in Cloud Infrastructure Support and Digital Process Operations. Simultaneously, our automated Welch's t-test audit verifies that base salaries exhibit no statistically significant gender pay disparity, protecting enterprise compliance."*

---

## Slide 7: Turnover Dynamics & Replacement Cost Forensics
- **The Financial Anatomy of Attrition (Waterfall Breakdown):**
  1. *Administrative Offboarding:* $108,700 (2.9%)
  2. *Lost Vacancy Productivity:* $1,380,000 (36.2%) — 45 to 75 open vacancy days.
  3. *Replacement Recruitment Fees:* $1,520,000 (39.9%) — 15-20% third-party agency fees.
  4. *Ramp-up Learning Curve Loss:* $800,000 (21.0%) — 50% productivity during first 90 days.
- **High Flight-Risk Critical Watchlist:** 18 top performers (`rating >= 3.8`) identified with $785,000 in immediate replacement risk liability.

> **🎙️ Speaker Notes:**  
> *"This waterfall chart is one of our most impactful insights. Over 76% of turnover loss comes from lost vacancy productivity and headhunter replacement fees—not administrative processing. By monitoring our High Flight-Risk talent pool, we can intervene proactively with targeted retention packages before these key engineers depart."*

---

## Slide 8: Talent Acquisition & Learning ROI Analytics
- **Recruitment Channel Matrix:**
  - Employee Referrals: $1,450 / hire, 28 days to fill (Most efficient).
  - Campus Placement: $1,850 / hire, 31 days to fill.
  - External Agencies: $14,200 / hire, 48 days to fill (Highest cost).
- **Learning & Development (OLS Regression):**
  - Training Hours vs. Skill Gap Reduction: $R^2 = 0.68$.
  - Personnel with > 45 training hours exhibit 28% higher performance ratings and 40% lower first-year attrition.

> **🎙️ Speaker Notes:**  
> *"Our recruitment efficiency matrix clearly proves that employee referrals are 10 times more cost-effective than external search agencies while closing requisitions 20 days faster. Furthermore, our OLS regression proves that corporate training is self-funding: upskilled engineers perform better and stay significantly longer."*

---

## Slide 9: Exploratory Data Analysis & Hypothesis Testing Lab
- **Distribution Shapes:** Non-Gaussian distributions; Base Salary exhibits moderate positive skewness (+0.82) and Overtime exhibits high leptokurtosis (+2.45).
- **One-Way ANOVA:** $F = 42.18, p < 0.0001$. Confirms significant compensation variance across departments (AI & ERS commands market premiums).
- **Chi-Square ($\chi^2$) Test:** $\chi^2 = 28.45, p = 0.0002, df = 7$. Confirms employee turnover is statistically dependent on departmental placement (concentrated in high-overtime units).

> **🎙️ Speaker Notes:**  
> *"In our Statistics Lab, we apply formal statistical rigor. The Chi-square test of independence yielded a p-value of 0.0002, conclusively proving that attrition is not random—it directly correlates with departments enduring chronic overtime fatigue."*

---

## Slide 10: Strategic What-If Budget Simulator
- **Interactive Scenarios Tested:**
  - Merit Salary Increase: +3.5% (+$2.52M)
  - Overtime Capping Policy: -25% (-$610K savings)
  - Target Attrition Reduction: -20% (-$762K savings)
  - Retention Program Fund: $450/emp allocated to active staff ($384K investment)
  - Technical Certification Fund: +15% ($184K investment)
- **Net Strategic Value Created:** **+$378,000 Net Positive Return** while providing raises and cutting overtime burnout!

> **🎙️ Speaker Notes:**  
> *"Our What-If Simulator bridges data science and executive strategy. By cutting overtime leakage by 25% and reducing turnover by 20%, the enterprise can fund a 3.5% merit raise and a dedicated retention program while still generating $378,000 in net fiscal savings."*

---

## Slide 11: Testing, QA & Cloud Deployment
- **pytest Test Suite:** 11 comprehensive automated tests across database integrity, statistical formulas, and simulator mathematics (**100% passing in 3.95s**).
- **Streamlit Community Cloud:** Headless server setup in `.streamlit/config.toml`, clean `requirements.txt`, and automated database bootstrapping.

> **🎙️ Speaker Notes:**  
> *"From a software engineering standpoint, code quality is assured through an automated pytest suite covering 100% of our core analytical logic. The repository is production-ready and deploys instantly to Streamlit Community Cloud."*

---

## Slide 12: Recommendations & Conclusion
1. **Overtime Rationalization:** Cap overtime in Cloud Support and Operations to capture $610,000 in annual savings.
2. **Targeted Retention Interventions:** Invest $450-$1,000 per key engineer on the Flight Risk Watchlist to protect $785,000 in replacement liabilities.
3. **Internal Referral Migration:** Shift 25% of agency sourcing budgets into referral bonuses to save $420,000 and accelerate hiring cycles.

> **🎙️ Speaker Notes:**  
> *"In conclusion, this project provides HCL leadership with a modern, statistically rigorous, and highly actionable decision-support platform. Thank you for your time, and I welcome any questions from the panel."*
