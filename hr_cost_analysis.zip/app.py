"""
app.py - Main Streamlit Application Entrypoint
HCL Final Submission: HR Cost Analysis & Strategic Optimization System
Tech Stack: Python + Streamlit + SQLite + Plotly + SciPy + Tailwind UI
"""

import streamlit as st
import pandas as pd
import os
import sys

# Ensure root directory is on Python path
sys.path.insert(0, os.path.dirname(__file__))

from modules.ui_components import inject_tailwind_styles, render_hero_header, render_alert
from modules.db import load_workforce_data, ensure_db_initialized
from views.overview import render_overview_view
from views.compensation import render_compensation_view
from views.attrition import render_attrition_view
from views.recruitment_training import render_recruitment_training_view
from views.statistics_eda import render_statistics_eda_view
from views.scenario_planner import render_scenario_planner_view
from views.sql_explorer import render_sql_explorer_view

# Initialize Streamlit Page
st.set_page_config(
    page_title="HR Cost Analysis | HCL Final Submission",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject custom Tailwind-inspired CSS
inject_tailwind_styles()

def main():
    # Make sure DB exists and load data
    ensure_db_initialized()
    raw_df = load_workforce_data()

    # --- Sidebar Header & Persistent Navigation ---
    with st.sidebar:
        st.markdown("""
        <div style="padding: 0.25rem 0 0.75rem 0;">
            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.2rem;">
                <span style="font-size: 1.4rem;">🏢</span>
                <span style="font-size: 1.15rem; font-weight: 800; color: #f8fafc; letter-spacing: -0.02em;">HCL Enterprise</span>
            </div>
            <div style="font-size: 0.8rem; color: #94a3b8; font-weight: 500;">
                HR Cost Analysis & Workforce Economics
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")
        st.markdown("<span style='font-size: 0.75rem; font-weight: 700; color: #818cf8; letter-spacing: 0.05em; text-transform: uppercase;'>📍 Dashboard Navigation</span>", unsafe_allow_html=True)
        
        # Navigation in sidebar ensures switching filters DOES NOT reset user's current view!
        nav_views = [
            "📊 Executive Overview",
            "💵 Compensation & Payroll",
            "📉 Attrition & Replacement",
            "🎯 Recruitment & Training",
            "🔬 Statistics & EDA Lab",
            "🔮 What-If Simulator",
            "💾 SQLite Data Explorer"
        ]
        selected_view = st.radio("Select View", nav_views, index=0, label_visibility="collapsed")

        st.markdown("---")
        st.markdown("<span style='font-size: 0.75rem; font-weight: 700; color: #818cf8; letter-spacing: 0.05em; text-transform: uppercase;'>🔍 Dynamic Slicers & Filters</span>", unsafe_allow_html=True)

        # 1. Department / Category Filter
        all_depts = sorted(raw_df['department_name'].unique().tolist())
        dept_options = ["All Departments / Categories"] + all_depts
        selected_dept_option = st.selectbox(
            "📁 Category / Department",
            dept_options,
            index=0,
            help="Filter workforce by organizational business unit or department category"
        )

        # 2. State / Location Filter
        all_locations = sorted(raw_df['location'].unique().tolist())
        loc_options = ["All States / Locations"] + all_locations
        selected_loc_option = st.selectbox(
            "📍 State / Location",
            loc_options,
            index=0,
            help="Filter workforce by office branch, state, or geographic location"
        )

        # 3. Job Level Filter
        level_order = ["All Levels", "Junior", "Mid-Level", "Senior", "Lead", "Director"]
        selected_level_option = st.selectbox(
            "💼 Job Level",
            level_order,
            index=0
        )

        # 4. Salary Tier Filter (Quick Segmenter)
        salary_tier_options = [
            "All Salary Tiers",
            "Entry Level (< $60,000)",
            "Mid-Market ($60,000 - $100,000)",
            "Senior Tier ($100,000 - $150,000)",
            "Executive / Lead (> $150,000)",
            "Custom Range Slider"
        ]
        selected_tier = st.selectbox(
            "💰 Compensation Tier",
            salary_tier_options,
            index=0,
            help="Instantly slice data by compensation bracket"
        )

        # 5. Salary Range Slider
        min_sal = int(raw_df['base_salary'].min())
        max_sal = int(raw_df['base_salary'].max())
        
        # Calculate dynamic defaults based on selected tier
        if selected_tier == "Entry Level (< $60,000)":
            default_range = (min_sal, 60000)
        elif selected_tier == "Mid-Market ($60,000 - $100,000)":
            default_range = (60000, 100000)
        elif selected_tier == "Senior Tier ($100,000 - $150,000)":
            default_range = (100000, 150000)
        elif selected_tier == "Executive / Lead (> $150,000)":
            default_range = (150000, max_sal)
        else:
            default_range = (min_sal, max_sal)

        sal_range = st.slider(
            "Base Salary Range ($)",
            min_value=min_sal,
            max_value=max_sal,
            value=default_range,
            step=2500,
            help="Fine-tune exact minimum and maximum base salary bounds"
        )

        # 6. Employment Status Radio
        status_choice = st.radio("Employment Status", ["All Personnel", "Active Only", "Attrited Only"], index=0)

        # Quick Reset Button
        st.markdown("<div style='height: 0.5rem;'></div>", unsafe_allow_html=True)
        if st.button("🔄 Reset All Filters", use_container_width=True):
            st.rerun()

        st.markdown("---")
        st.markdown("""
        <div style="font-size: 0.73rem; color: #64748b; line-height: 1.4;">
            <strong>Tech Stack:</strong><br>
            • Python 3.12 + Streamlit<br>
            • SQLite3 Relational Engine<br>
            • Plotly Interactive Visuals<br>
            • SciPy Inferential Statistics<br>
            • Tailwind UI CSS Components<br>
            • pytest Automated Test Suite
        </div>
        """, unsafe_allow_html=True)

    # --- Apply Filters Reactively ---
    filtered_df = raw_df.copy()

    # Apply Department / Category
    if selected_dept_option != "All Departments / Categories":
        filtered_df = filtered_df[filtered_df['department_name'] == selected_dept_option]

    # Apply State / Location
    if selected_loc_option != "All States / Locations":
        filtered_df = filtered_df[filtered_df['location'] == selected_loc_option]

    # Apply Job Level
    if selected_level_option != "All Levels":
        filtered_df = filtered_df[filtered_df['job_level'] == selected_level_option]

    # Apply Employment Status
    if status_choice == "Active Only":
        filtered_df = filtered_df[filtered_df['is_attrited'] == 0]
    elif status_choice == "Attrited Only":
        filtered_df = filtered_df[filtered_df['is_attrited'] == 1]
    
    # Apply Salary Range
    filtered_df = filtered_df[
        (filtered_df['base_salary'] >= sal_range[0]) & 
        (filtered_df['base_salary'] <= sal_range[1])
    ]

    total_recs = len(raw_df)
    active_recs = len(filtered_df)
    pct_active = (active_recs / total_recs * 100) if total_recs > 0 else 0

    # Hero Banner
    render_hero_header(
        title="HR Cost Analysis & Workforce Economics",
        subtitle="Enterprise intelligence portal for payroll optimization, overtime diagnostics, attrition cost forensics, and strategic what-if budget simulation.",
        badge_text=f"Matching {active_recs:,} of {total_recs:,} Employees ({pct_active:.1f}%)"
    )

    # --- Live Filter Status Pill Banner ---
    filter_desc = []
    if selected_dept_option != "All Departments / Categories":
        filter_desc.append(f"📁 <strong>Dept:</strong> {selected_dept_option}")
    if selected_loc_option != "All States / Locations":
        filter_desc.append(f"📍 <strong>State/Loc:</strong> {selected_loc_option}")
    if selected_level_option != "All Levels":
        filter_desc.append(f"💼 <strong>Level:</strong> {selected_level_option}")
    if status_choice != "All Personnel":
        filter_desc.append(f"👤 <strong>Status:</strong> {status_choice}")
    if sal_range != (min_sal, max_sal):
        filter_desc.append(f"💵 <strong>Salary:</strong> ${sal_range[0]:,} - ${sal_range[1]:,}")

    if filter_desc:
        filters_html = " &nbsp;|&nbsp; ".join(filter_desc)
        st.markdown(f"""
        <div style="background: rgba(79, 70, 229, 0.12); border: 1px solid rgba(99, 102, 241, 0.4); border-radius: 0.625rem; padding: 0.5rem 1rem; margin-bottom: 1.25rem; font-size: 0.8125rem; color: #cbd5e1; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
            <div>
                <span style="color: #818cf8; font-weight: 700; margin-right: 0.5rem;">⚡ ACTIVE FILTERS:</span>
                {filters_html}
            </div>
            <div>
                <span style="background: #4f46e5; color: #ffffff; padding: 0.15rem 0.5rem; border-radius: 9999px; font-weight: 700; font-size: 0.75rem;">
                    {active_recs:,} Records
                </span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Check if filters resulted in 0 matching records
    if filtered_df.empty:
        render_alert(
            "No employee records matched your current filter selection. Try widening the base salary range slider, or changing the Department / State dropdown back to 'All'.",
            alert_type="warning",
            title="Zero Matching Records"
        )
        return

    # --- Render Selected Persistent View ---
    if selected_view == "📊 Executive Overview":
        render_overview_view(filtered_df)
    elif selected_view == "💵 Compensation & Payroll":
        render_compensation_view(filtered_df)
    elif selected_view == "📉 Attrition & Replacement":
        render_attrition_view(filtered_df)
    elif selected_view == "🎯 Recruitment & Training":
        render_recruitment_training_view(filtered_df)
    elif selected_view == "🔬 Statistics & EDA Lab":
        render_statistics_eda_view(filtered_df)
    elif selected_view == "🔮 What-If Simulator":
        render_scenario_planner_view(filtered_df)
    elif selected_view == "💾 SQLite Data Explorer":
        render_sql_explorer_view()

    # Footer
    st.markdown("<div style='height: 2.5rem;'></div>", unsafe_allow_html=True)
    st.markdown("""
    <div style="border-top: 1px solid rgba(51, 65, 85, 0.4); padding-top: 1.25rem; text-align: center; color: #64748b; font-size: 0.8125rem;">
        HCL Final Project Submission • HR Cost Analysis & Optimization Portal • Built for Streamlit Community Cloud Deployment
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
