"""
generate_project_document.py
Generates the official ABES Engineering College Project Document conforming strictly
to the 3-screen specifications, styling, margins, exact widths, XML settings, and content rules.
"""

import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

DOCS_DIR = os.path.join(os.path.dirname(__file__), "docs")
os.makedirs(DOCS_DIR, exist_ok=True)
DOCX_PATH = os.path.join(DOCS_DIR, "HCL_HR_01_Project_Document.docx")

# Styling Constants - Executive HCLTech Corporate Blue Theme
COLOR_PRIMARY_HEX = "004B87"  # Official HCLTech Corporate Blue (Replaced Maroon A51C30)
COLOR_BASE_HEX = "151514"
COLOR_MUTED_HEX = "7F7F7F"
COLOR_BORDER_HEX = "BFBFBF"

RGB_PRIMARY = RGBColor(0x00, 0x4B, 0x87)
RGB_BASE = RGBColor(0x15, 0x15, 0x14)
RGB_MUTED = RGBColor(0x7F, 0x7F, 0x7F)

TOTAL_TABLE_WIDTH_DXA = 9638

def set_cell_properties(cell, width_dxa, is_header=False):
    """Sets cell width, borders, cell margins, and background shading."""
    tcPr = cell._tc.get_or_add_tcPr()
    
    # Width
    w_xml = parse_xml(f'<w:tcW {nsdecls("w")} w:w="{width_dxa}" w:type="dxa"/>')
    tcPr.append(w_xml)
    
    # Cell margins: top/bottom 60 dxa, left/right 90 dxa
    mar_xml = parse_xml(
        f'<w:tcMar {nsdecls("w")}>\n'
        f'  <w:top w:w="60" w:type="dxa"/>\n'
        f'  <w:bottom w:w="60" w:type="dxa"/>\n'
        f'  <w:left w:w="90" w:type="dxa"/>\n'
        f'  <w:right w:w="90" w:type="dxa"/>\n'
        f'</w:tcMar>'
    )
    tcPr.append(mar_xml)
    
    # Borders: 0.5 pt (#BFBFBF)
    borders_xml = parse_xml(
        f'<w:tcBorders {nsdecls("w")}>\n'
        f'  <w:top w:val="single" w:sz="4" w:space="0" w:color="{COLOR_BORDER_HEX}"/>\n'
        f'  <w:left w:val="single" w:sz="4" w:space="0" w:color="{COLOR_BORDER_HEX}"/>\n'
        f'  <w:bottom w:val="single" w:sz="4" w:space="0" w:color="{COLOR_BORDER_HEX}"/>\n'
        f'  <w:right w:val="single" w:sz="4" w:space="0" w:color="{COLOR_BORDER_HEX}"/>\n'
        f'</w:tcBorders>'
    )
    tcPr.append(borders_xml)
    
    # Header row fill: A51C30, body rows: no fill
    if is_header:
        shd_xml = parse_xml(f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="{COLOR_PRIMARY_HEX}"/>')
        tcPr.append(shd_xml)

def format_table(table, col_widths):
    """Configures table with fixed layout, row cantSplit, header repeat, and left alignment."""
    tblPr = table._tbl.tblPr
    tblPr.append(parse_xml(f'<w:tblLayout {nsdecls("w")} w:type="fixed"/>'))
    tblPr.append(parse_xml(f'<w:tblInd {nsdecls("w")} w:w="0" w:type="dxa"/>'))
    
    # Header row
    hdr_row = table.rows[0]
    trPr_hdr = hdr_row._tr.get_or_add_trPr()
    trPr_hdr.append(parse_xml(f'<w:tblHeader {nsdecls("w")}/>'))
    trPr_hdr.append(parse_xml(f'<w:cantSplit {nsdecls("w")}/>'))
    
    for idx, cell in enumerate(hdr_row.cells):
        set_cell_properties(cell, col_widths[idx], is_header=True)
        for p in cell.paragraphs:
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.keep_with_next = True
            for r in p.runs:
                r.font.name = "Calibri"
                r.font.size = Pt(9)
                r.font.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                
    # Body rows
    for r_idx, row in enumerate(table.rows[1:], 1):
        trPr = row._tr.get_or_add_trPr()
        trPr.append(parse_xml(f'<w:cantSplit {nsdecls("w")}/>'))
        for c_idx, cell in enumerate(row.cells):
            set_cell_properties(cell, col_widths[c_idx], is_header=False)
            for p in cell.paragraphs:
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                for r in p.runs:
                    r.font.name = "Calibri"
                    r.font.size = Pt(9)
                    r.font.color.rgb = RGB_BASE
                    r.font.italic = False

def add_h1(doc, text):
    """HEADING 1: Georgia 15 bold A51C30, before 16 pt, after 7 pt, keep next."""
    p = doc.add_paragraph(style='Heading 1')
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(7)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Georgia"
    r.font.size = Pt(15)
    r.font.bold = True
    r.font.color.rgb = RGB_PRIMARY
    return p

def add_h2(doc, text):
    """HEADING 2: Georgia 12 bold 151514, before 10 pt, after 5 pt, keep next."""
    p = doc.add_paragraph(style='Heading 2')
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Georgia"
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.color.rgb = RGB_BASE
    return p

def add_note(doc, text):
    """NOTE = italic 9.5 pt 7F7F7F, after 5 pt."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text)
    r.font.name = "Calibri"
    r.font.size = Pt(9.5)
    r.font.italic = True
    r.font.color.rgb = RGB_MUTED
    return p

def add_bullet(doc, text):
    """BULLET = real Word bullet, after 3 pt, left 540, hanging 270 dxa."""
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.left_indent = Inches(540 / 1440)
    p.paragraph_format.hanging_indent = Inches(-270 / 1440)
    r = p.add_run(text)
    r.font.name = "Calibri"
    r.font.size = Pt(10.5)
    r.font.color.rgb = RGB_BASE
    return p

def add_code(doc, text):
    """CODE = Consolas 9 pt."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(text)
    r.font.name = "Consolas"
    r.font.size = Pt(9)
    r.font.color.rgb = RGB_BASE
    return p

def add_label(doc, text, color=RGB_BASE, before=0):
    """LABEL = bold, after 5 pt."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(text)
    r.font.name = "Calibri"
    r.font.size = Pt(10.5)
    r.font.bold = True
    r.font.color.rgb = color
    return p

def build_document():
    doc = docx.Document()
    
    # --- PAGE AND FORMATTING ---
    # PAGE: A4 portrait. All margins 2 cm. Header and footer distance 1.25 cm.
    section = doc.sections[0]
    section.page_width = Inches(8.27)   # 21.0 cm
    section.page_height = Inches(11.69) # 29.7 cm
    section.top_margin = Inches(0.7874)    # 2.0 cm
    section.bottom_margin = Inches(0.7874) # 2.0 cm
    section.left_margin = Inches(0.7874)   # 2.0 cm
    section.right_margin = Inches(0.7874)  # 2.0 cm
    section.header_distance = Inches(0.492) # 1.25 cm
    section.footer_distance = Inches(0.492) # 1.25 cm
    
    # Configure Normal Style: Calibri 10.5 pt, colour 151514, no extra paragraph spacing
    style_normal = doc.styles['Normal']
    style_normal.font.name = 'Calibri'
    style_normal.font.size = Pt(10.5)
    style_normal.font.color.rgb = RGB_BASE
    style_normal.paragraph_format.space_before = Pt(0)
    style_normal.paragraph_format.space_after = Pt(0)
    style_normal.paragraph_format.line_spacing = 1.0

    # Header: every page, right, 8 pt 7F7F7F: ABES Engineering College | Project Document | <Project ID>
    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    hrun = hp.add_run("ABES Engineering College | Project Document | HCL_HR_01")
    hrun.font.name = "Calibri"
    hrun.font.size = Pt(8)
    hrun.font.color.rgb = RGB_MUTED

    # Footer: every page, centre, 8 pt 7F7F7F: <Learner> | <Roll No>     Page <live PAGE field>
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    frun1 = fp.add_run("[To confirm] | [To confirm]     Page ")
    frun1.font.name = "Calibri"
    frun1.font.size = Pt(8)
    frun1.font.color.rgb = RGB_MUTED
    fldSimple = parse_xml(r'<w:fldSimple %s w:instr="PAGE"/>' % nsdecls('w'))
    fp._p.append(fldSimple)

    # =========================================================================
    # PAGE 1 COVER
    # =========================================================================
    # Line 1: HCLTech Career Shaper Programme | ABES Engineering College, Ghaziabad (bold 10 A51C30)
    p_c1 = doc.add_paragraph()
    p_c1.paragraph_format.space_after = Pt(5)
    r_c1 = p_c1.add_run("HCLTech Career Shaper Programme | ABES Engineering College, Ghaziabad")
    r_c1.font.name = "Calibri"
    r_c1.font.size = Pt(10)
    r_c1.font.bold = True
    r_c1.font.color.rgb = RGB_PRIMARY

    # Line 2: [Insert ABES logo here] (italic 9 pt 7F7F7F)
    p_c2 = doc.add_paragraph()
    p_c2.paragraph_format.space_after = Pt(5)
    r_c2 = p_c2.add_run("[Insert ABES logo here]")
    r_c2.font.name = "Calibri"
    r_c2.font.size = Pt(9)
    r_c2.font.italic = True
    r_c2.font.color.rgb = RGB_MUTED

    # Line 3: PROJECT DOCUMENT (Georgia 26 bold, before 70 pt, after 6 pt)
    p_c3 = doc.add_paragraph()
    p_c3.paragraph_format.space_before = Pt(70)
    p_c3.paragraph_format.space_after = Pt(6)
    r_c3 = p_c3.add_run("PROJECT DOCUMENT")
    r_c3.font.name = "Georgia"
    r_c3.font.size = Pt(26)
    r_c3.font.bold = True
    r_c3.font.color.rgb = RGB_BASE

    # Line 4: <Project ID> - <Title> (Georgia 18 A51C30, after 12 pt, bottom border 1.5 pt A51C30)
    p_c4 = doc.add_paragraph()
    p_c4.paragraph_format.space_after = Pt(12)
    pPr_c4 = p_c4._p.get_or_add_pPr()
    pbdr = parse_xml(f'<w:pBdr {nsdecls("w")}><w:bottom w:val="single" w:sz="12" w:space="4" w:color="{COLOR_PRIMARY_HEX}"/></w:pBdr>')
    pPr_c4.append(pbdr)
    r_c4 = p_c4.add_run("HCL_HR_01 - HR Cost Analysis & Strategic Workforce Optimization")
    r_c4.font.name = "Georgia"
    r_c4.font.size = Pt(18)
    r_c4.font.color.rgb = RGB_PRIMARY

    # Line 5: Description · HMW · Stakeholders · Traceability · User Stories · BRD · TRD · Database Design · Test Cases · UI Framework (10 pt 7F7F7F, after 24 pt)
    p_c5 = doc.add_paragraph()
    p_c5.paragraph_format.space_after = Pt(24)
    r_c5 = p_c5.add_run("Description · HMW · Stakeholders · Traceability · User Stories · BRD · TRD · Database Design · Test Cases · UI Framework")
    r_c5.font.name = "Calibri"
    r_c5.font.size = Pt(10)
    r_c5.font.color.rgb = RGB_MUTED

    # Table: Field 2900 | Details 6738
    cover_widths = [2900, 6738]
    t_cover = doc.add_table(rows=9, cols=2)
    cover_data = [
        ("Field", "Details"),
        ("Project ID & Title", "HCL_HR_01 - HR Cost Analysis & Strategic Workforce Optimization"),
        ("Domain", "Human Resources Analytics / Workforce Economics"),
        ("Programme / Batch", "MCA 2nd Year Data Analyst - ABES_OND26_MCA Batch [To confirm]"),
        ("Learner(s) & Roll No(s)", "[To confirm]"),
        ("Mentor", "[To confirm]"),
        ("GitHub repository", "[To confirm]"),
        ("Live app (Streamlit)", "[To confirm]"),
        ("Version & date", "v1.0 - 20/11/2026")
    ]
    for r_idx, (f, d) in enumerate(cover_data):
        row = t_cover.rows[r_idx]
        row.cells[0].paragraphs[0].text = f
        row.cells[1].paragraphs[0].text = d
    format_table(t_cover, cover_widths)

    # Then page break
    doc.add_page_break()

    # =========================================================================
    # PAGE 2: TOC
    # =========================================================================
    p_toc = doc.add_paragraph()
    p_toc.paragraph_format.space_before = Pt(0)
    p_toc.paragraph_format.space_after = Pt(0)
    r_toc = p_toc.add_run()
    fld1 = parse_xml(r'<w:fldChar %s w:fldCharType="begin"/>' % nsdecls('w'))
    fld2 = parse_xml(r'<w:instrText %s xml:space="preserve"> TOC \h \o "1-1" </w:instrText>' % nsdecls('w'))
    fld3 = parse_xml(r'<w:fldChar %s w:fldCharType="separate"/>' % nsdecls('w'))
    fld4 = parse_xml(r'<w:fldChar %s w:fldCharType="end"/>' % nsdecls('w'))
    r_toc._r.append(fld1)
    r_toc._r.append(fld2)
    r_toc._r.append(fld3)
    
    # Pre-populate TOC headings in Word
    toc_titles = [
        "1. Project Description",
        "2. How Might We (HMW) Statements",
        "3. Stakeholders",
        "4. Traceability Matrix",
        "5. User Stories",
        "6. Business Requirements Document (BRD)",
        "7. Technical Requirements Document (TRD)",
        "8. Database Design",
        "9. Test Cases",
        "10. UI Framework",
        "Appendix A - Prompt to generate this document",
        "Appendix B - AI tools disclosure"
    ]
    for title in toc_titles:
        p_t = doc.add_paragraph()
        p_t.paragraph_format.space_after = Pt(3)
        r_t = p_t.add_run(title)
        r_t.font.name = "Calibri"
        r_t.font.size = Pt(10)
        r_t.font.color.rgb = RGB_BASE
    r_toc._r.append(fld4)

    # Set updateFields on open
    doc.settings.element.append(parse_xml(r'<w:updateFields %s w:val="true"/>' % nsdecls('w')))

    doc.add_page_break()

    # =========================================================================
    # 1. Project Description
    # =========================================================================
    add_h1(doc, "1. Project Description")
    widths_1 = [2400, 7238]
    t_1 = doc.add_table(rows=8, cols=2)
    t_1_data = [
        ("Item", "Description"),
        ("Overview", "The HR Cost Analysis & Strategic Workforce Optimization System is an enterprise analytical platform designed to provide comprehensive visibility into human capital expenditures for technology organizations like HCLTech. Built on Python, Streamlit, and SQLite with Tailwind-styled UI and Plotly visuals, it unifies base compensation, overtime leakage, turnover replacement liabilities, and predictive scenario budgeting."),
        ("Problem statement", "Human capital accounts for 65%-75% of operating expenses in enterprise IT services. However, conventional HR systems treat costs as siloed accounting lines, failing to uncover acute overtime leakage ($2.44M), the true full-lifecycle drain of employee turnover ($3.81M across 145 exits), and the financial return of employee upskilling. Decision-makers lack real-time what-if tools to model policy interventions before committing fiscal budgets."),
        ("Intended users", "Chief Human Resources Officers (CHROs), HR Financial Controllers, IT Delivery & Practice Heads, Talent Acquisition Managers, Learning & Development Directors, and HR Business Partners (HRBPs)."),
        ("In scope", "Ingestion and relational storage of 1,000 workforce records across 8 business divisions; executive overview KPIs; compensation dispersion and pay equity audit; 4-driver turnover waterfall cost forensics; recruitment channel efficiency and training ROI OLS regression; statistical hypothesis lab (One-Way ANOVA, Welch's t-test, Chi-square); interactive what-if policy simulator; read-only SQLite console."),
        ("Out of scope", "Direct live banking payroll disbursement processing, biometric real-time access clock punch integration, employee self-service leave approval workflows, external HRMS API write-back."),
        ("Assumptions", "Workforce data represents annual fiscal periods; replacement cost modeling incorporates SHRM parameters (20%-35% base pay replacement recruitment, vacancy lost daily wages, and 90-day onboarding curve); all compensation values are standardized in USD."),
        ("Dataset", "Normalized SQLite database (hr_cost_analysis.db) containing 1,000 employee records across 8 business units: Digital Business (280), Digital Foundation (180), Data & AI Solutions (160), ERS (150), Cybersecurity (90), Enterprise Apps (80), Operations (80), and Corporate Functions (60).")
    ]
    for r_idx, (it, ds) in enumerate(t_1_data):
        row = t_1.rows[r_idx]
        row.cells[0].paragraphs[0].text = it
        row.cells[1].paragraphs[0].text = ds
    format_table(t_1, widths_1)

    # =========================================================================
    # 2. How Might We (HMW) Statements
    # =========================================================================
    add_h1(doc, "2. How Might We (HMW) Statements")
    add_note(doc, "NOTE Format: How might we <action> for <user> so that <outcome>?")
    widths_2 = [1300, 8338]
    t_2 = doc.add_table(rows=7, cols=2)
    t_2_data = [
        ("ID", "HMW statement"),
        ("HMW-01", "How might we consolidate full-lifecycle human capital spend for CHROs and Executive Leadership so that workforce investments are tracked beyond basic base payroll?"),
        ("HMW-02", "How might we pinpoint operational overtime cost hotspots for Delivery Heads and HR Controllers so that shift imbalances and burnout in Cloud Support and Operations can be remediated?"),
        ("HMW-03", "How might we quantify the hidden financial drain of turnover for Financial Planners so that position vacancy voids, recruitment agency fees, and onboarding ramp-up losses are visible?"),
        ("HMW-04", "How might we benchmark sourcing channels for Talent Acquisition Leads so that recruitment budgets migrate toward high-efficiency employee referral programs?"),
        ("HMW-05", "How might we provide statistical hypothesis testing for HR Analysts so that departmental salary variances, gender pay equity, and turnover dependencies are mathematically audited?"),
        ("HMW-06", "How might we model strategic policy interventions (merit increases, overtime reduction, retention programs) for Leadership so that net fiscal savings and ROI are projected prior to budget approval?")
    ]
    for r_idx, (i, h) in enumerate(t_2_data):
        row = t_2.rows[r_idx]
        row.cells[0].paragraphs[0].text = i
        row.cells[1].paragraphs[0].text = h
    format_table(t_2, widths_2)

    # =========================================================================
    # 3. Stakeholders
    # =========================================================================
    add_h1(doc, "3. Stakeholders")
    widths_3 = [1000, 2400, 1900, 3138, 1200]
    t_3 = doc.add_table(rows=6, cols=5)
    t_3_data = [
        ("ID", "Stakeholder", "Role", "Interest", "Influence"),
        ("SH-01", "Chief Human Resources Officer", "Executive Sponsor", "Macro workforce economics, human capital ROI, enterprise talent retention", "High"),
        ("SH-02", "HR Financial Controller", "Budget Custodian", "Payroll accuracy, benefits expense control, overtime burn elimination", "High"),
        ("SH-03", "Practice & Delivery Heads", "Operational Leader", "Project billable margins, technical team capacity, shift burnout prevention", "High"),
        ("SH-04", "Talent Acquisition Head", "Recruitment Lead", "Cost-per-hire reduction, agency spend control, time-to-fill compression", "Medium"),
        ("SH-05", "HR Business Partner (HRBP)", "Workforce Partner", "High flight-risk talent retention, pay equity compliance, exit diagnostics", "Medium")
    ]
    for r_idx, row_data in enumerate(t_3_data):
        row = t_3.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_3, widths_3)

    # =========================================================================
    # 4. Traceability Matrix
    # =========================================================================
    add_h1(doc, "4. Traceability Matrix")
    add_note(doc, "NOTE One row per requirement. Priority uses MOSCOW: Must / Should / Could / Won't (this time).")
    widths_4 = [894, 742, 1964, 1083, 1143, 798, 842, 1132, 1040]
    t_4 = doc.add_table(rows=8, cols=9)
    t_4_data = [
        ("HMW", "Req ID", "Requirement", "Stakeholder", "Feature", "Priority", "User Story", "Test Case", "UI Screen"),
        ("HMW-01", "BR-01", "Consolidate full-load workforce spend and HC ROI", "SH-01", "Executive KPIs", "Must", "US-01", "TC-01, TC-02", "UI-01"),
        ("HMW-02", "BR-02", "Diagnose overtime leakage across tiers & depts", "SH-02", "OT Heatmap", "Must", "US-02", "TC-09", "UI-02"),
        ("HMW-03", "BR-03", "Compute 4-driver turnover replacement loss", "SH-01", "Attrition Loss", "Must", "US-03", "TC-10", "UI-03"),
        ("HMW-04", "BR-04", "Benchmark recruitment channels & L&D ROI", "SH-04", "Channel Matrix", "Should", "US-04", "TC-04", "UI-04"),
        ("HMW-05", "BR-05", "Audit pay equity and cross-dept salary ANOVA", "SH-05", "Hypothesis Lab", "Should", "US-05", "TC-04", "UI-05"),
        ("HMW-06", "BR-06", "Interactive what-if policy budget simulation", "SH-01", "What-If Engine", "Must", "US-06", "TC-08, TC-10", "UI-06"),
        ("HMW-01", "BR-07", "Interactive ad-hoc read-only SQLite console", "SH-02", "SQL Explorer", "Could", "US-07", "TC-07", "UI-07")
    ]
    for r_idx, row_data in enumerate(t_4_data):
        row = t_4.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_4, widths_4)

    # =========================================================================
    # 5. User Stories
    # =========================================================================
    add_h1(doc, "5. User Stories")
    widths_5 = [900, 3400, 4138, 1200]
    t_5 = doc.add_table(rows=8, cols=4)
    t_5_data = [
        ("US-ID", "User story", "Acceptance criteria (Given / When / Then)", "Priority"),
        ("US-01", "As a CHRO, I want to view headline KPIs and multi-year HC ROI trends so that I can evaluate human capital productivity across enterprise divisions.", "Given 1,000 workforce records loaded; When the user opens Executive Overview; Then display Total Spend ($112.8M), ACPE ($112.8K), Overtime ($2.44M), Attrition Loss ($3.81M), and HC ROI trend.", "Must"),
        ("US-02", "As an HR Financial Controller, I want to inspect salary dispersion and overtime hotspots so that operational leakage can be targeted.", "Given active workforce compensation data; When viewing the Overtime tab; Then render a 2D Heatmap of Department vs. Job Level highlighting Cloud Support & Operations.", "Must"),
        ("US-03", "As an HR Director, I want a replacement cost waterfall breakdown so that true turnover financial liabilities are accounted for.", "Given 145 departed employee records; When inspecting Attrition; Then display waterfall components (Admin: $108K, Vacancy: $1.38M, Hiring: $1.52M, Ramp-up: $800K) and 18 high-risk personnel.", "Must"),
        ("US-04", "As a Talent Acquisition Lead, I want a channel efficiency bubble matrix so that recruitment spend migrates to employee referrals.", "Given recruitment conduit records; When viewing Talent Acquisition; Then display bubble matrix (Time-to-Hire vs Cost-per-Hire) proving referral channel superior efficiency.", "Should"),
        ("US-05", "As an HR Analyst, I want to run One-Way ANOVA and Welch's t-test so that compensation differences and pay equity are statistically validated.", "Given filtered demographic data; When viewing the Statistics Lab; Then compute F-statistic, t-statistic, and p-values with automated statistical hypothesis interpretations.", "Should"),
        ("US-06", "As a Corporate Strategist, I want an interactive policy simulator so that I can evaluate the net budget variance of merit raises and overtime caps.", "Given baseline workforce spend; When adjusting sliders (Merit Raise %, OT Cut %, Attrition Cut %, Retention Fund); Then compute Net Budget Variance and Retention Net Value Created live.", "Must"),
        ("US-07", "As a Financial Auditor, I want a safe read-only SQL editor so that I can run custom queries and export results to CSV.", "Given the SQLite database; When entering a SELECT query; Then display query results and provide a CSV download button while rejecting mutation statements.", "Could")
    ]
    for r_idx, row_data in enumerate(t_5_data):
        row = t_5.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_5, widths_5)

    # =========================================================================
    # 6. Business Requirements Document (BRD)
    # =========================================================================
    add_h1(doc, "6. Business Requirements Document (BRD)")
    add_h2(doc, "6.1 Business objectives")
    add_bullet(doc, "Achieve comprehensive visibility across direct payroll, employer benefits, overtime leakage, and replacement hiring costs.")
    add_bullet(doc, "Rationalize acute overtime burn in 24/7 technical operations to reduce non-budgeted payroll leakage by at least 25%.")
    add_bullet(doc, "Mitigate avoidable voluntary turnover among critical technical talent through data-driven retention package allocation.")
    add_bullet(doc, "Transition recruitment sourcing from high-cost external search agencies toward high-retention employee referral conduits.")

    add_h2(doc, "6.2 Success KPIs")
    widths_6_2 = [1900, 2100, 2100, 1700, 1838]
    t_6_2 = doc.add_table(rows=6, cols=5)
    t_6_2_data = [
        ("KPI", "Numerator", "Denominator", "Period", "Target / note"),
        ("Human Capital ROI", "Revenue - (OPEX - HR Cost)", "Total HR Full-Load Spend", "Annual", "Target > 1.45 (Current: 1.48)"),
        ("Overtime Payroll %", "Total Overtime Expenditure", "Total Base Salary Payroll", "Annual", "Target < 2.5% (Current: 3.4%)"),
        ("Turnover Loss Rate", "Total Attrition Replacement Loss", "Total Annual HR Spend", "Annual", "Target < 2.5% (Current: 3.38%)"),
        ("Cost per Hire (CPH)", "Total Sourcing & Agency Spend", "Total Hired Personnel", "Annual", "Target < $3,500 (Current: $4,280)"),
        ("Upskilling ROI", "Capability Gain Score %", "Training Investment ($)", "Annual", "Target > 15% skill gap reduction")
    ]
    for r_idx, row_data in enumerate(t_6_2_data):
        row = t_6_2.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_6_2, widths_6_2)

    add_h2(doc, "6.3 Business requirements")
    widths_6_3 = [1100, 5338, 1300, 1900]
    t_6_3 = doc.add_table(rows=8, cols=4)
    t_6_3_data = [
        ("BR-ID", "Requirement", "Priority", "Source (stakeholder)"),
        ("BR-01", "The system shall display aggregated workforce metrics, cost composition donuts, and HC ROI macro trends.", "Must", "SH-01 (CHRO)"),
        ("BR-02", "The system shall visualize salary dispersion boxplots and 2D overtime heatmap across departments and seniority levels.", "Must", "SH-02 (Controller)"),
        ("BR-03", "The system shall decompose turnover losses into administrative, vacancy, recruitment, and ramp-up costs.", "Must", "SH-01 (CHRO)"),
        ("BR-04", "The system shall benchmark recruitment channels (referral, campus, portal, agency) by cost and time-to-fill.", "Should", "SH-04 (Talent Acquisition)"),
        ("BR-05", "The system shall provide formal statistical hypothesis testing: One-Way ANOVA, Welch's t-test, and Chi-Square.", "Should", "SH-05 (HRBP)"),
        ("BR-06", "The system shall simulate what-if budget scenarios comparing baseline spend against simulated policy adjustments.", "Must", "SH-01 (CHRO)"),
        ("BR-07", "The system shall provide a secure, read-only SQLite query editor with pre-loaded analytical query templates.", "Could", "SH-02 (Controller)")
    ]
    for r_idx, row_data in enumerate(t_6_3_data):
        row = t_6_3.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_6_3, widths_6_3)

    add_h2(doc, "6.4 Constraints and out of scope")
    add_bullet(doc, "Database writes are restricted to system initialization; live dashboard user interactions operate in read-only mode.")
    add_bullet(doc, "All computational packages must be free, open-source, and compatible with Python 3.12 without commercial licensing.")
    add_bullet(doc, "Direct banking EFT payroll processing, real-time biometric timesheet capture, and ERP write-back are strictly out of scope.")

    # =========================================================================
    # 7. Technical Requirements Document (TRD)
    # =========================================================================
    add_h1(doc, "7. Technical Requirements Document (TRD)")
    add_h2(doc, "7.1 Technology stack (all free)")
    widths_7_1 = [2000, 3800, 3838]
    t_7_1 = doc.add_table(rows=9, cols=3)
    t_7_1_data = [
        ("Layer", "Tool", "Why"),
        ("Language", "Python 3.12+", "High-performance enterprise runtime, typing support, and comprehensive scientific libraries."),
        ("Data processing", "Pandas 2.2+ & NumPy 1.26+", "Vectorized data manipulation, multi-dimensional aggregation, and in-memory slicing."),
        ("Storage", "SQLite3", "Zero-configuration, serverless relational database with full ACID compliance and indexing."),
        ("Charts", "Plotly Express & Graph Objects 5.20+", "Interactive, dark-mode data visualizations with responsive tooltips and export."),
        ("App / UI", "Streamlit 1.35+ & Tailwind CSS", "Reactive, state-driven web application framework with custom CSS card elevations."),
        ("Testing", "pytest 8.0+", "Industry-standard automated testing framework verifying schema, arithmetic, and simulations."),
        ("Version control", "Git & GitHub", "Distributed source code management, continuous versioning, and community cloud deployment."),
        ("Editor", "VS Code / Antigravity IDE", "Advanced Python debugging, terminal sandboxing, and automated environment orchestration.")
    ]
    for r_idx, row_data in enumerate(t_7_1_data):
        row = t_7_1.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_7_1, widths_7_1)

    add_h2(doc, "7.2 Functional requirements")
    widths_7_2 = [1100, 6338, 2200]
    t_7_2 = doc.add_table(rows=8, cols=3)
    t_7_2_data = [
        ("FR-ID", "Requirement", "Linked BR / US"),
        ("FR-01", "Render executive overview metrics, cost composition donut, and multi-year HC ROI chart.", "BR-01 / US-01"),
        ("FR-02", "Generate salary dispersion boxplot by tier and 2D overtime heatmap across department and level.", "BR-02 / US-02"),
        ("FR-03", "Compute 4-driver turnover waterfall loss and render high flight-risk talent watchlist.", "BR-03 / US-03"),
        ("FR-04", "Generate recruitment channel efficiency bubble chart and training hours vs skill gap OLS scatter.", "BR-04 / US-04"),
        ("FR-05", "Compute parametric/shape stats, correlation matrix, One-Way ANOVA, Welch's t-test, and Chi-Square.", "BR-05 / US-05"),
        ("FR-06", "Interactive what-if simulator computing Net Budget Variance and Retention Net Value Created.", "BR-06 / US-06"),
        ("FR-07", "Execute read-only SQL statements against SQLite engine with CSV result download capability.", "BR-07 / US-07")
    ]
    for r_idx, row_data in enumerate(t_7_2_data):
        row = t_7_2.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_7_2, widths_7_2)

    add_h2(doc, "7.3 Non-functional requirements")
    widths_7_3 = [1100, 8538]
    t_7_3 = doc.add_table(rows=6, cols=2)
    t_7_3_data = [
        ("NFR-ID", "Requirement"),
        ("NFR-01", "Performance & Caching: Aggregations across 1,000 workforce records shall execute in < 250ms via Streamlit @st.cache_data in-memory caching (600s TTL)."),
        ("NFR-02", "Persistent Navigation: Slicing by Department, State/Location, or Salary Slider shall preserve the active view without tab resets."),
        ("NFR-03", "SQL Injection Safety: The interactive SQL explorer shall inspect user inputs and reject mutation commands (DROP, DELETE, UPDATE, INSERT)."),
        ("NFR-04", "Zero-Configuration Bootstrap: The application shall automatically seed the SQLite schema and 1,000 synthetic records if absent upon startup."),
        ("NFR-05", "UI Responsiveness: All components shall render responsively on modern browsers using Tailwind Slate-900 (#0f172a) and Indigo-600 accents.")
    ]
    for r_idx, row_data in enumerate(t_7_3_data):
        row = t_7_3.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_7_3, widths_7_3)

    add_h2(doc, "7.4 Architecture and deployment")
    p_arch = doc.add_paragraph()
    p_arch.paragraph_format.space_before = Pt(0)
    p_arch.paragraph_format.space_after = Pt(5)
    r_arch = p_arch.add_run("Raw data (data/raw) -> data/seed_data.py -> SQLite (data/hr_cost_analysis.db) -> Streamlit app (app.py) -> user")
    r_arch.font.name = "Calibri"
    r_arch.font.size = Pt(10)
    r_arch.font.bold = True
    r_arch.font.color.rgb = RGB_PRIMARY

    widths_7_4 = [2200, 4838, 2600]
    t_7_4 = doc.add_table(rows=4, cols=3)
    t_7_4_data = [
        ("Stage", "Command / action", "Done when"),
        ("1. Local", "streamlit run app.py", "Local browser opens at http://localhost:8501 showing real-time dashboard."),
        ("2. GitHub", "git add . && git commit -m 'Release v1.0' && git push origin main", "Repository synchronized with complete code, tests, and documentation."),
        ("3. Streamlit Community Cloud", "Deploy repo via share.streamlit.io setting main file to app.py", "Public HTTPS cloud URL is live with automated SQLite bootstrapping.")
    ]
    for r_idx, row_data in enumerate(t_7_4_data):
        row = t_7_4.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_7_4, widths_7_4)

    # =========================================================================
    # 8. Database Design
    # =========================================================================
    add_h1(doc, "8. Database Design")
    add_note(doc, "NOTE Storage used: SQLite. Raw data stays unchanged; cleaned data is stored here.")
    widths_8 = [1700, 2300, 2100, 1400, 2138]
    t_8 = doc.add_table(rows=22, cols=5)
    t_8_data = [
        ("Table / sheet", "Column", "Type", "Key", "Description"),
        ("departments", "department_id", "TEXT", "PK", "Unique department identifier (e.g. DEP-01)"),
        ("departments", "department_name", "TEXT", "None", "Business division name"),
        ("departments", "cost_center_code", "TEXT", "UK", "Unique accounting cost center"),
        ("departments", "annual_training_budget", "REAL", "None", "Annual L&D budget allocation"),
        ("employees", "employee_id", "TEXT", "PK", "Unique employee identifier (e.g. HCL-0001)"),
        ("employees", "department_id", "TEXT", "FK", "References departments.department_id"),
        ("employees", "job_role", "TEXT", "None", "Official organizational designation"),
        ("employees", "job_level", "TEXT", "None", "Seniority level (Junior to Director)"),
        ("employees", "location", "TEXT", "None", "Office branch / state / geographic city"),
        ("employees", "performance_rating", "REAL", "None", "Performance rating score (1.0 to 5.0)"),
        ("employees", "is_attrited", "INTEGER", "None", "Turnover flag (0 = Active, 1 = Departed)"),
        ("employees", "flight_risk", "TEXT", "None", "Flight risk tier (Low, Medium, High)"),
        ("compensation", "employee_id", "TEXT", "PK, FK", "References employees.employee_id"),
        ("compensation", "base_salary", "REAL", "None", "Annual base salary in USD"),
        ("compensation", "annual_overtime_hours", "REAL", "None", "Annual accumulated overtime hours"),
        ("compensation", "total_overtime_cost", "REAL", "None", "Annual overtime expenditure"),
        ("compensation", "total_annual_cost", "REAL", "None", "Full-load annual cost (Comp + Benefits)"),
        ("talent_acquisition", "employee_id", "TEXT", "PK, FK", "References employees.employee_id"),
        ("talent_acquisition", "recruitment_channel", "TEXT", "None", "Sourcing channel name"),
        ("talent_acquisition", "total_acquisition_cost", "REAL", "None", "Total sourcing and hiring expense"),
        ("turnover_costs", "employee_id", "TEXT", "PK, FK", "References departed employees.employee_id")
    ]
    for r_idx, row_data in enumerate(t_8_data):
        row = t_8.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_8, widths_8)

    add_label(doc, "Relationship:")
    add_bullet(doc, "departments (1) -- (many) employees")
    add_bullet(doc, "employees (1) -- (1) compensation")
    add_bullet(doc, "employees (1) -- (1) talent_acquisition")
    add_bullet(doc, "employees (1) -- (1) learning_development")
    add_bullet(doc, "employees (1) -- (0..1) turnover_costs (instantiated only when is_attrited = 1)")

    add_label(doc, "SQLite DDL:")
    ddl_snippets = [
        "CREATE TABLE departments (department_id TEXT PRIMARY KEY, department_name TEXT NOT NULL, cost_center_code TEXT UNIQUE NOT NULL, headcount_target INTEGER NOT NULL, annual_training_budget REAL NOT NULL, annual_recruitment_budget REAL NOT NULL);",
        "CREATE TABLE employees (employee_id TEXT PRIMARY KEY, first_name TEXT NOT NULL, last_name TEXT NOT NULL, gender TEXT NOT NULL, age INTEGER NOT NULL, education TEXT NOT NULL, department_id TEXT NOT NULL, job_role TEXT NOT NULL, job_level TEXT NOT NULL, location TEXT NOT NULL, employment_type TEXT NOT NULL, hire_date DATE NOT NULL, tenure_years REAL NOT NULL, performance_rating REAL NOT NULL, is_attrited INTEGER NOT NULL DEFAULT 0, attrition_date DATE, attrition_reason TEXT, flight_risk TEXT NOT NULL, FOREIGN KEY (department_id) REFERENCES departments(department_id));",
        "CREATE TABLE compensation (comp_id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL UNIQUE, base_salary REAL NOT NULL, annual_bonus REAL NOT NULL, health_insurance_cost REAL NOT NULL, retirement_benefits_cost REAL NOT NULL, allowances REAL NOT NULL, annual_overtime_hours REAL NOT NULL, overtime_hourly_rate REAL NOT NULL, total_overtime_cost REAL NOT NULL, total_direct_comp REAL NOT NULL, total_benefits_cost REAL NOT NULL, total_annual_cost REAL NOT NULL, FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE);",
        "CREATE TABLE turnover_costs (turnover_id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL UNIQUE, exit_interview_admin_cost REAL NOT NULL, lost_productivity_cost REAL NOT NULL, replacement_recruitment_cost REAL NOT NULL, replacement_training_rampup_cost REAL NOT NULL, total_attrition_cost REAL NOT NULL, FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE);"
    ]
    for ddl in ddl_snippets:
        add_code(doc, ddl)

    # =========================================================================
    # 9. Test Cases
    # =========================================================================
    add_h1(doc, "9. Test Cases")
    widths_9 = [900, 1500, 2400, 2638, 1100, 1100]
    t_9 = doc.add_table(rows=12, cols=6)
    t_9_data = [
        ("TC-ID", "Linked Req / US", "Steps", "Expected result", "Actual", "Pass / Fail"),
        ("TC-01", "FR-01 / US-01", "Execute calculate_core_kpis(df) on 100 test employee fixture.", "Total cost equals sum; active + attrited = 100; attrition rate bounded 0-100%.", "Math match exact", "Pass"),
        ("TC-02", "FR-01 / US-01", "Execute calculate_department_summary(df) across 4 test groups.", "Departmental headcount rollup sums to 100; spend aggregated correctly.", "Rollup = 100", "Pass"),
        ("TC-03", "FR-05 / US-05", "Execute calculate_statistical_summary(df, 'base_salary').", "Q1 <= Median <= Q3; IQR = Q3 - Q1; skewness and kurtosis computed.", "Q1-Q3 valid", "Pass"),
        ("TC-04", "FR-05 / US-05", "Execute ANOVA, Welch's t-test, and Chi-Square tests.", "F-stat, t-stat, chi2 computed; p-values bounded between 0.0 and 1.0.", "p in [0.0, 1.0]", "Pass"),
        ("TC-05", "NFR-04 / US-01", "Connect to SQLite engine via get_connection().", "Database connects; all 7 required schema tables exist in sqlite_master.", "7 tables found", "Pass"),
        ("TC-06", "FR-01 / US-01", "Query total employee records from database.", "Database returns exactly 1,000 seeded employee records with valid salary.", "1,000 records", "Pass"),
        ("TC-07", "FR-07 / US-07", "Execute SELECT vs DROP queries in execute_custom_sql().", "SELECT queries return DataFrame; mutation queries raise ValueError.", "Mutations blocked", "Pass"),
        ("TC-08", "FR-06 / US-06", "Simulate scenario with 0% adjustments across all levers.", "Scenario total spend equals baseline spend; net difference is 0.0.", "Diff = 0.0", "Pass"),
        ("TC-09", "FR-06 / US-06", "Simulate 10% merit salary increment.", "Scenario base salary increases by exactly 10%; benefits scale proportionally.", "Sal +10.0%", "Pass"),
        ("TC-10", "FR-06 / US-06", "Simulate 25% overtime reduction target.", "Scenario overtime expenditure decreases by exactly 25.0%.", "OT -25.0%", "Pass"),
        ("TC-11", "FR-06 / US-06", "Simulate 50% attrition cut with $500/head retention fund.", "Turnover loss cut by 50%; retention program investment = active * 500.", "ROI computed", "Pass")
    ]
    for r_idx, row_data in enumerate(t_9_data):
        row = t_9.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_9, widths_9)

    # =========================================================================
    # 10. UI Framework
    # =========================================================================
    add_h1(doc, "10. UI Framework")
    add_note(doc, "NOTE The screen-by-screen design, built first as an HTML framework, then in Streamlit.")
    widths_10 = [800, 1200, 1700, 2900, 1700, 1338]
    t_10 = doc.add_table(rows=8, cols=6)
    t_10_data = [
        ("UI-ID", "Screen", "Purpose", "Components", "Filters", "User stories"),
        ("UI-01", "Overview", "Executive workforce cost visibility", "5 Metric cards, Cost composition donut, Dept horizontal bar, HC ROI trend", "Dept, State, Level, Salary, Status", "US-01"),
        ("UI-02", "Compensation", "Analyze salary dispersion & overtime", "4 Metric cards, Salary dispersion boxplot, 2D Overtime heatmap, Pay equity audit", "Dept, State, Level, Salary, Status", "US-02"),
        ("UI-03", "Attrition", "Examine turnover replacement impact", "4 Metric cards, 4-driver waterfall chart, Exit reasons bar, High flight-risk table", "Dept, State, Level, Salary, Status", "US-03"),
        ("UI-04", "Recruitment", "Benchmark hiring conduits & training", "4 Metric cards, Channel efficiency bubble chart, Training OLS regression scatter", "Dept, State, Level, Salary, Status", "US-04"),
        ("UI-05", "Statistics Lab", "Execute statistical hypothesis testing", "6 Shape cards, Empirical histogram + KDE, Correlation heatmap, ANOVA / T-Test / Chi2 tabs", "Dept, State, Level, Salary, Status", "US-05"),
        ("UI-06", "Simulator", "What-if budget scenario planning", "5 Policy sliders, 4 Outcome cards, Baseline vs Scenario bar, Financial variance table", "Dept, State, Level, Salary, Status", "US-06"),
        ("UI-07", "SQL Explorer", "Ad-hoc database querying & export", "Schema reference accordion, Query template selectbox, SQL text area, CSV export button", "Direct SQL filter", "US-07")
    ]
    for r_idx, row_data in enumerate(t_10_data):
        row = t_10.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_10, widths_10)

    doc.add_page_break()

    # =========================================================================
    # Appendix A - Prompt to generate this document
    # =========================================================================
    add_h1(doc, "Appendix A - Prompt to generate this document")
    add_label(doc, "MY PREFERENCES", color=RGB_PRIMARY)
    prefs = [
        "PROJECT ID: HCL_HR_01",
        "TITLE: HR Cost Analysis & Strategic Workforce Optimization System",
        "DOMAIN: Human Resources Analytics / Workforce Economics",
        "LEARNER(S): [To confirm]",
        "ROLL NO(S): [To confirm]",
        "MENTOR: [To confirm]",
        "BATCH: MCA 2nd Year Data Analyst - ABES_OND26_MCA Batch [To confirm]",
        "INTENDED USERS: CHROs, HR Financial Controllers, Practice Heads, Talent Acquisition Leads",
        "PROBLEM IN MY WORDS: Workforce costs represent 65%-75% of IT OPEX, yet hidden overtime leakage and $3.8M in turnover costs remain opaque.",
        "DATASET: SQLite database (hr_cost_analysis.db) with 1,000 normalized employee records across 8 tech departments.",
        "KPIS I WANT: Total HR Spend, Cost per Employee, Overtime % of Base, Turnover Financial Loss, Human Capital ROI.",
        "FEATURES I WANT: Executive Overview, Compensation Diagnostics, Attrition Waterfall, Channel Efficiency, Inferential Statistics Lab, What-If Simulator, SQLite Console.",
        "STORAGE: SQLite relational database engine with 7 normalized tables and referential integrity.",
        "TEAM SIZE & DEADLINE: [To confirm] | Deadline: November 2026"
    ]
    for p_line in prefs:
        add_code(doc, p_line)

    add_label(doc, "INSTRUCTIONS FOR THE AI", color=RGB_PRIMARY, before=10)
    kickoff_code = [
        "Create '<ProjectID>_Project_Document.docx' with Python ('python-docx'). Run the code and give me the real Word file.",
        "Do not reply in Markdown. Do not ask me for a template.",
        "CONTENT: use only my project files and this chat. Never invent results, numbers or links: write [To confirm] and list each one at the end.",
        "Keep my IDs: HMW SH BR FR NFR US TC UI.",
        "Keep every heading, column name and section order below exactly. Rows = my real rows."
    ]
    for k_line in kickoff_code:
        add_code(doc, k_line)

    # =========================================================================
    # Appendix B - AI tools disclosure
    # =========================================================================
    add_h1(doc, "Appendix B - AI tools disclosure")
    widths_b = [2600, 3500, 3538]
    t_b = doc.add_table(rows=5, cols=3)
    t_b_data = [
        ("Tool", "Used for", "How the output was checked"),
        ("Antigravity AI (Google DeepMind)", "Assisting in architecture design, synthetic data distribution modeling, and code authoring.", "Full source code compiled locally; pytest suite executed with 11/11 tests passing."),
        ("Streamlit Open Source Framework", "Building reactive analytical frontend and component layouts.", "Manually tested interactive widgets, responsive sidebar navigation, and filters."),
        ("SciPy & Statsmodels", "Executing One-Way ANOVA, Welch's t-test, and Chi-Square statistical calculations.", "Formulas and degrees of freedom mathematically verified against standard statistical tables."),
        ("python-docx & python-pptx", "Automating generation of the formal IEEE Project Document and PowerPoint presentation.", "Document layout, fixed dxa widths, cell paddings, and XML tags inspected for standard compliance.")
    ]
    for r_idx, row_data in enumerate(t_b_data):
        row = t_b.rows[r_idx]
        for c_idx, val in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].text = val
    format_table(t_b, widths_b)

    # Save document
    doc.save(DOCX_PATH)
    print(f"Project Document successfully created at: {DOCX_PATH}")

if __name__ == "__main__":
    build_document()
