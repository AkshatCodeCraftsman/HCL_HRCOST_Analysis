"""
views/sql_explorer.py - Interactive SQLite Query and Workforce Data Explorer
"""

import streamlit as st
import pandas as pd
from modules.ui_components import render_section_header, render_alert
from modules.db import execute_custom_sql

SAMPLE_QUERIES = {
    "1. Top 10 Overtime Burden Employees": """
SELECT 
    e.employee_id,
    (e.first_name || ' ' || e.last_name) AS employee_name,
    d.department_name,
    e.job_role,
    c.base_salary,
    c.annual_overtime_hours,
    c.total_overtime_cost
FROM employees e
JOIN departments d ON e.department_id = d.department_id
JOIN compensation c ON e.employee_id = c.employee_id
ORDER BY c.total_overtime_cost DESC
LIMIT 10;
""",
    "2. High Flight-Risk Top Talent (Retention Priority)": """
SELECT 
    e.employee_id,
    (e.first_name || ' ' || e.last_name) AS employee_name,
    d.department_name,
    e.job_role,
    e.performance_rating,
    e.flight_risk,
    c.base_salary,
    ROUND(c.base_salary * 0.45 + 5000, 2) AS estimated_replacement_cost
FROM employees e
JOIN departments d ON e.department_id = d.department_id
JOIN compensation c ON e.employee_id = c.employee_id
WHERE e.is_attrited = 0 
  AND e.flight_risk = 'High' 
  AND e.performance_rating >= 3.8
ORDER BY c.base_salary DESC;
""",
    "3. Departmental Cost & Turnover Matrix": """
SELECT 
    d.department_name,
    COUNT(e.employee_id) AS total_headcount,
    SUM(CASE WHEN e.is_attrited = 1 THEN 1 ELSE 0 END) AS leavers_count,
    ROUND(SUM(CASE WHEN e.is_attrited = 1 THEN 1.0 ELSE 0.0 END) / COUNT(e.employee_id) * 100, 1) AS attrition_rate_pct,
    ROUND(SUM(c.base_salary), 0) AS total_base_payroll,
    ROUND(SUM(c.total_overtime_cost), 0) AS total_overtime,
    ROUND(SUM(c.total_annual_cost), 0) AS total_annual_spend
FROM employees e
JOIN departments d ON e.department_id = d.department_id
JOIN compensation c ON e.employee_id = c.employee_id
GROUP BY d.department_name
ORDER BY total_annual_spend DESC;
""",
    "4. Recruitment Channel ROI & Time-to-Hire": """
SELECT 
    ta.recruitment_channel,
    COUNT(e.employee_id) AS total_hires,
    ROUND(AVG(ta.time_to_hire_days), 1) AS avg_days_to_hire,
    ROUND(AVG(ta.sourcing_cost), 2) AS avg_sourcing_cost,
    ROUND(AVG(ta.agency_fees), 2) AS avg_agency_fee,
    ROUND(AVG(ta.total_acquisition_cost), 2) AS avg_total_cost_per_hire,
    ROUND(AVG(e.performance_rating), 2) AS avg_hire_performance
FROM talent_acquisition ta
JOIN employees e ON ta.employee_id = e.employee_id
GROUP BY ta.recruitment_channel
ORDER BY avg_total_cost_per_hire DESC;
""",
    "5. Turnover Financial Breakdown of Departed Staff": """
SELECT 
    e.employee_id,
    (e.first_name || ' ' || e.last_name) AS employee_name,
    d.department_name,
    e.attrition_reason,
    tc.exit_interview_admin_cost,
    tc.lost_productivity_cost,
    tc.replacement_recruitment_cost,
    tc.replacement_training_rampup_cost,
    tc.total_attrition_cost
FROM turnover_costs tc
JOIN employees e ON tc.employee_id = e.employee_id
JOIN departments d ON e.department_id = d.department_id
ORDER BY tc.total_attrition_cost DESC
LIMIT 15;
"""
}

def render_sql_explorer_view():
    """Renders interactive SQL sandbox and data extraction console."""
    render_section_header("Interactive SQLite Query Console", "Run live ad-hoc SQL queries directly against the HR Cost database")

    with st.expander("📖 Database Schema Reference", expanded=False):
        st.markdown("""
        - **`departments`**: `department_id`, `department_name`, `cost_center_code`, `headcount_target`, `annual_training_budget`, `annual_recruitment_budget`
        - **`employees`**: `employee_id`, `first_name`, `last_name`, `gender`, `age`, `education`, `department_id`, `job_role`, `job_level`, `location`, `employment_type`, `hire_date`, `tenure_years`, `performance_rating`, `is_attrited`, `attrition_date`, `attrition_reason`, `flight_risk`
        - **`compensation`**: `employee_id`, `base_salary`, `annual_bonus`, `health_insurance_cost`, `retirement_benefits_cost`, `allowances`, `annual_overtime_hours`, `overtime_hourly_rate`, `total_overtime_cost`, `total_direct_comp`, `total_benefits_cost`, `total_annual_cost`
        - **`talent_acquisition`**: `employee_id`, `recruitment_channel`, `sourcing_cost`, `agency_fees`, `onboarding_cost`, `signon_bonus`, `time_to_hire_days`, `total_acquisition_cost`
        - **`learning_development`**: `employee_id`, `courses_completed`, `training_hours`, `certification_cost`, `lms_license_cost`, `external_workshop_cost`, `total_training_cost`, `skill_gap_reduction_pct`
        - **`turnover_costs`**: `employee_id`, `exit_interview_admin_cost`, `lost_productivity_cost`, `replacement_recruitment_cost`, `replacement_training_rampup_cost`, `total_attrition_cost`
        """)

    # Query selector
    selected_preset = st.selectbox("Load Sample Analytical Query:", list(SAMPLE_QUERIES.keys()), index=0)
    query_text = st.text_area("SQL Statement (Read-Only):", value=SAMPLE_QUERIES[selected_preset].strip(), height=160)

    execute_btn = st.button("▶ Run Query", type="primary")

    if execute_btn or query_text:
        try:
            result_df = execute_custom_sql(query_text)
            st.success(f"Query returned {len(result_df):,} rows.")
            st.dataframe(result_df, use_container_width=True)

            # Export to CSV
            csv_data = result_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Export Result to CSV",
                data=csv_data,
                file_name="hr_cost_query_export.csv",
                mime="text/csv"
            )
        except Exception as e:
            st.error(f"SQL Execution Error: {str(e)}")
