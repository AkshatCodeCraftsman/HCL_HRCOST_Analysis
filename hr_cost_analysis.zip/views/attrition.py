"""
views/attrition.py - Turnover Dynamics & Financial Replacement Cost Analytics
"""

import streamlit as st
import pandas as pd
import plotly.express as px
from modules.ui_components import render_kpi_card, render_section_header, render_alert
from modules.analytics import calculate_core_kpis, run_chi_square_attrition_department
from modules.charts import chart_attrition_waterfall, SEQUENCE, PALETTE

def render_attrition_view(df: pd.DataFrame):
    """Renders attrition cost dynamics and flight risk modeling."""
    kpis = calculate_core_kpis(df)
    if not kpis:
        st.warning("No data available.")
        return

    attrited_df = df[df['is_attrited'] == 1]
    active_df = df[df['is_attrited'] == 0]

    # Metric Row
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        render_kpi_card(
            title="Total Departures",
            value=f"{kpis['attrited_headcount']:,}",
            subtext=f"Out of {kpis['total_headcount']:,} employees",
            icon="🚪",
            color_accent="rose"
        )
    with c2:
        render_kpi_card(
            title="Attrition Rate",
            value=f"{kpis['attrition_rate']:.1f}%",
            subtext="Annualized Turnover",
            delta="14.2% Benchmark",
            delta_positive=(kpis['attrition_rate'] <= 14.2),
            icon="📊",
            color_accent="amber"
        )
    with c3:
        render_kpi_card(
            title="Total Financial Loss",
            value=f"${kpis['total_attrition_financial_loss']/1e3:,.0f}K",
            subtext="Full replacement burden",
            icon="💸",
            color_accent="rose"
        )
    with c4:
        render_kpi_card(
            title="Avg Cost / Leaver",
            value=f"${kpis['avg_attrition_cost_per_leaver']:,.0f}",
            subtext="Vacancy + Hire + Rampup",
            icon="🏷️",
            color_accent="indigo"
        )

    st.markdown("<div style='height: 1rem;'></div>", unsafe_allow_html=True)

    # Waterfall Chart Section
    render_section_header("The Financial Anatomy of Employee Turnover", "Breakdown of exit processing, vacancy lost productivity, recruitment replacement, and onboarding ramp-up")
    st.plotly_chart(chart_attrition_waterfall(df), use_container_width=True)

    # Reasons & Departmental Contingency
    render_section_header("Attrition Drivers & Departmental Dependencies", "Analysis of primary exit rationales and statistical concentration")
    
    col_reasons, col_flight = st.columns([1.2, 1])
    with col_reasons:
        if not attrited_df.empty:
            reason_counts = attrited_df['attrition_reason'].value_counts().reset_index()
            reason_counts.columns = ['Reason', 'Count']
            fig_reasons = px.bar(
                reason_counts,
                x='Count',
                y='Reason',
                orientation='h',
                color='Count',
                color_continuous_scale="Purples",
                title="Primary Exit Drivers Reported in Exit Interviews"
            )
            fig_reasons.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                height=340,
                margin=dict(l=20, r=20, t=40, b=20),
                coloraxis_showscale=False
            )
            st.plotly_chart(fig_reasons, use_container_width=True)

    with col_flight:
        flight_counts = active_df['flight_risk'].value_counts().reset_index()
        flight_counts.columns = ['Risk Level', 'Employees']
        fig_flight = px.pie(
            flight_counts,
            names='Risk Level',
            values='Employees',
            color='Risk Level',
            color_discrete_map={"Low": PALETTE["emerald"], "Medium": PALETTE["amber"], "High": PALETTE["rose"]},
            hole=0.5,
            title="Active Workforce Flight Risk Profile"
        )
        fig_flight.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=340,
            margin=dict(l=20, r=20, t=40, b=20)
        )
        st.plotly_chart(fig_flight, use_container_width=True)

    # Chi-Square Test Callout
    chi_res = run_chi_square_attrition_department(df)
    if "error" not in chi_res:
        if chi_res["is_significant"]:
            render_alert(
                f"{chi_res['interpretation']} Targeted retention packages should be allocated to these departments to optimize return on retention capital.",
                alert_type="warning",
                title="Statistical Cluster Found (Chi-Square Test)"
            )
        else:
            render_alert(
                chi_res['interpretation'],
                alert_type="info",
                title="Uniform Attrition Distribution"
            )

    # High Flight-Risk Critical Talent Table
    render_section_header("High Flight Risk Critical Talent Watchlist", "Active high-performing personnel whose departure would incur peak replacement costs")
    high_risk_talent = active_df[
        (active_df['flight_risk'] == 'High') & 
        (active_df['performance_rating'] >= 3.8)
    ].copy()
    
    # Calculate estimated potential departure liability
    high_risk_talent['Estimated Replacement Liability ($)'] = (
        high_risk_talent['base_salary'] * 0.45 + 5000
    ).round(0)

    display_cols = [
        'employee_id', 'full_name', 'department_name', 'job_role',
        'job_level', 'tenure_years', 'performance_rating',
        'base_salary', 'Estimated Replacement Liability ($)'
    ]
    show_df = high_risk_talent[display_cols].sort_values(
        by='Estimated Replacement Liability ($)', ascending=False
    ).head(10)

    show_df.rename(columns={
        'employee_id': 'Emp ID',
        'full_name': 'Employee Name',
        'department_name': 'Department',
        'job_role': 'Job Role',
        'job_level': 'Level',
        'tenure_years': 'Tenure (Yrs)',
        'performance_rating': 'Perf Rating',
        'base_salary': 'Current Base ($)'
    }, inplace=True)

    st.dataframe(
        show_df.style.format({
            'Current Base ($)': '${:,.0f}',
            'Estimated Replacement Liability ($)': '${:,.0f}',
            'Perf Rating': '{:.2f}',
            'Tenure (Yrs)': '{:.1f}'
        }),
        use_container_width=True,
        hide_index=True
    )
