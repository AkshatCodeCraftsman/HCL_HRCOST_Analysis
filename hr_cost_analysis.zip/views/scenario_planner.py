"""
views/scenario_planner.py - What-If Cost Simulation and Budget Scenario Planner
"""

import streamlit as st
import pandas as pd
from modules.ui_components import render_kpi_card, render_section_header, render_alert
from modules.analytics import simulate_cost_scenario
from modules.charts import chart_scenario_comparison

def render_scenario_planner_view(df: pd.DataFrame):
    """Renders interactive budget simulation and ROI scenario modeling."""
    if df.empty:
        st.warning("No data available.")
        return

    render_section_header("What-If HR Budget & Strategic Policy Simulator", "Model fiscal impacts of compensation reviews, overtime rationalization, and retention programs")

    # Control Sliders in columns
    ctrl_col1, ctrl_col2 = st.columns(2)
    with ctrl_col1:
        salary_inc = st.slider(
            "1. Annual Merit Salary Increment (%)",
            min_value=0.0, max_value=15.0, value=3.5, step=0.5,
            help="Annual compensation raise across active workforce"
        )
        ot_red = st.slider(
            "2. Overtime Reduction Policy Target (%)",
            min_value=0.0, max_value=60.0, value=25.0, step=5.0,
            help="Projected overtime hours compressed via workload balancing and automation"
        )
        training_adj = st.slider(
            "3. Training & Upskilling Budget Adjustment (%)",
            min_value=-25.0, max_value=50.0, value=15.0, step=5.0,
            help="Increase or decrease in corporate learning & certifications fund"
        )

    with ctrl_col2:
        attr_red = st.slider(
            "4. Target Attrition Reduction (%)",
            min_value=0.0, max_value=50.0, value=20.0, step=5.0,
            help="Target decrease in leavers achieved through retention initiatives"
        )
        retention_cost = st.slider(
            "5. Retention Program Investment ($ / Active Employee)",
            min_value=0, max_value=2500, value=450, step=50,
            help="Dedicated annual budget per employee for wellness, retention bonuses, and engagement"
        )

    # Run simulation
    sim = simulate_cost_scenario(
        df,
        salary_increment_pct=salary_inc,
        overtime_reduction_pct=ot_red,
        attrition_reduction_pct=attr_red,
        retention_program_spend_per_head=retention_cost,
        training_adjustment_pct=training_adj
    )

    baseline = sim["baseline"]
    scenario = sim["scenario"]
    var = sim["variance"]

    st.markdown("<div style='height: 1rem;'></div>", unsafe_allow_html=True)

    # Simulation Outcome KPI Tiles
    s1, s2, s3, s4 = st.columns(4)
    with s1:
        render_kpi_card(
            title="Baseline Annual Spend",
            value=f"${baseline['total_spend']/1e6:.2f}M",
            subtext="Current Run-Rate",
            color_accent="slate",
            icon="🏦"
        )
    with s2:
        render_kpi_card(
            title="Simulated Annual Spend",
            value=f"${scenario['total_spend']/1e6:.2f}M",
            subtext="Post-Policy Run-Rate",
            color_accent="indigo",
            icon="📊"
        )
    with s3:
        is_net_saving = var['net_savings'] > 0
        diff_val = abs(var['net_difference'])
        diff_prefix = "-" if is_net_saving else "+"
        render_kpi_card(
            title="Net Budget Variance",
            value=f"{diff_prefix}${diff_val/1e3:,.0f}K",
            subtext=f"{var['pct_change']:+.2f}% Overall Change",
            delta="Net Savings" if is_net_saving else "Added Investment",
            delta_positive=is_net_saving,
            color_accent="emerald" if is_net_saving else "rose",
            icon="⚖️"
        )
    with s4:
        # Retention ROI calculation: turnover loss saved minus retention program investment
        turnover_saved = baseline['attrition_loss'] - scenario['attrition_loss']
        retention_net_roi = turnover_saved - scenario['retention_program']
        render_kpi_card(
            title="Retention Net Value Created",
            value=f"${retention_net_roi/1e3:,.0f}K",
            subtext=f"Turnover Saved: ${turnover_saved/1e3:,.0f}K",
            delta_positive=(retention_net_roi > 0),
            color_accent="cyan",
            icon="🚀"
        )

    # Comparison Chart
    st.plotly_chart(chart_scenario_comparison(sim), use_container_width=True)

    # Detailed Financial Variance Table
    render_section_header("Line-Item Financial Breakdown & Variance Table")
    
    rows = [
        ("Base Payroll", baseline["base_salary"], scenario["base_salary"]),
        ("Overtime Expense", baseline["overtime"], scenario["overtime"]),
        ("Benefits & Perks", baseline["benefits"], scenario["benefits"]),
        ("Training & Development", baseline["training"], scenario["training"]),
        ("Turnover / Replacement Loss", baseline["attrition_loss"], scenario["attrition_loss"]),
        ("Targeted Retention Program", baseline["retention_program"], scenario["retention_program"]),
        ("Total Workforce Expenditure", baseline["total_spend"], scenario["total_spend"])
    ]

    variance_records = []
    for category, base_val, scen_val in rows:
        diff = scen_val - base_val
        pct = (diff / base_val * 100) if base_val > 0 else (100.0 if scen_val > 0 else 0.0)
        variance_records.append({
            "Cost Center / Category": category,
            "Baseline Spend ($)": base_val,
            "Scenario Spend ($)": scen_val,
            "Variance ($)": diff,
            "Change (%)": pct
        })

    var_df = pd.DataFrame(variance_records)
    st.dataframe(
        var_df.style.format({
            "Baseline Spend ($)": "${:,.0f}",
            "Scenario Spend ($)": "${:,.0f}",
            "Variance ($)": "${:+,.0f}",
            "Change (%)": "{:+.1f}%"
        }),
        use_container_width=True,
        hide_index=True
    )
