"""
views/overview.py - Executive HR Cost & Workforce Dashboard View
"""

import streamlit as st
import pandas as pd
from modules.ui_components import render_kpi_card, render_section_header, render_alert
from modules.analytics import calculate_core_kpis, calculate_department_summary
from modules.charts import chart_cost_composition_donut, chart_dept_cost_breakdown, chart_historical_hc_roi
from modules.db import get_company_kpis

def render_overview_view(df: pd.DataFrame):
    """Renders executive summary dashboard."""
    kpis = calculate_core_kpis(df)
    if not kpis:
        render_alert("No workforce data found matching selected filters. Try broadening your filter selection.", alert_type="warning")
        return

    # Top KPI Grid
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        render_kpi_card(
            title="Total Headcount",
            value=f"{kpis['total_headcount']:,}",
            subtext=f"Active: {kpis['active_headcount']:,} | Exit: {kpis['attrited_headcount']:,}",
            icon="👥",
            color_accent="indigo"
        )
    with col2:
        cost_val = kpis['total_annual_cost']
        cost_str = f"${cost_val/1e6:.2f}M" if cost_val >= 1e6 else f"${cost_val/1e3:.0f}K"
        render_kpi_card(
            title="Total HR Spend",
            value=cost_str,
            subtext="Annual Full-Load Cost",
            icon="💳",
            color_accent="emerald"
        )
    with col3:
        render_kpi_card(
            title="Cost / Employee",
            value=f"${kpis['avg_cost_per_employee']:,.0f}",
            subtext=f"Median: ${kpis['median_cost_per_employee']:,.0f}",
            icon="📊",
            color_accent="cyan"
        )
    with col4:
        render_kpi_card(
            title="Overtime Spend",
            value=f"${kpis['total_overtime_cost']/1e3:,.0f}K",
            subtext=f"{kpis['overtime_pct_base']:.1f}% of Base Payroll",
            icon="⏱️",
            color_accent="amber"
        )
    with col5:
        render_kpi_card(
            title="Attrition Loss",
            value=f"${kpis['total_attrition_financial_loss']/1e3:,.0f}K",
            subtext=f"{kpis['attrition_rate']:.1f}% Attrition Rate",
            delta=f"{kpis['attrited_headcount']} Leavers",
            delta_positive=(kpis['attrited_headcount'] == 0),
            icon="📉",
            color_accent="rose"
        )

    # Executive Charts Row
    st.markdown("<div style='height: 1rem;'></div>", unsafe_allow_html=True)
    c1, c2 = st.columns([1, 1.25])
    with c1:
        st.plotly_chart(chart_cost_composition_donut(df), use_container_width=True)
    with c2:
        st.plotly_chart(chart_dept_cost_breakdown(df), use_container_width=True)

    # Departmental Summary Table
    render_section_header("Departmental Financial Benchmarks", "Summary of headcount, total expenditure, and turnover impact by division in filtered scope")
    dept_df = calculate_department_summary(df)
    
    if not dept_df.empty:
        format_dict = {
            'Total Spend ($)': '${:,.0f}',
            'Avg Base Salary ($)': '${:,.0f}',
            'Total Overtime ($)': '${:,.0f}',
            'Total Overtime (Hrs)': '{:,.1f}',
            'Total Benefits ($)': '${:,.0f}',
            'Avg Cost Per Hire ($)': '${:,.0f}',
            'Avg Training Spend ($)': '${:,.0f}',
            'Turnover Loss ($)': '${:,.0f}',
            'Avg Cost Per Employee ($)': '${:,.0f}',
            'Attrition Rate (%)': '{:.1f}%'
        }
        st.dataframe(dept_df.style.format(format_dict), use_container_width=True, hide_index=True)

    # Historical Financial Trend & HC ROI
    render_section_header("Enterprise Human Capital ROI Trend", "Macro corporate fiscal performance across historical annual cohorts")
    kpi_records = get_company_kpis()
    st.plotly_chart(chart_historical_hc_roi(kpi_records), use_container_width=True)
