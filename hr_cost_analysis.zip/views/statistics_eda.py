"""
views/statistics_eda.py - Exploratory Data Analysis & Inferential Statistics Lab
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from modules.ui_components import render_kpi_card, render_section_header, render_alert
from modules.analytics import (
    calculate_statistical_summary,
    run_anova_salary_by_department,
    run_ttest_gender_pay,
    run_chi_square_attrition_department
)
from modules.charts import chart_correlation_heatmap, PALETTE

def render_statistics_eda_view(df: pd.DataFrame):
    """Renders EDA distributions, correlation matrices, and hypothesis tests."""
    if df.empty:
        render_alert("No data available for the current filter criteria.", alert_type="warning")
        return

    # Section 1: Distribution Analysis
    render_section_header("Univariate Distribution & Shape Analysis", "Inspect parametric and non-parametric characteristics of numerical workforce dimensions")

    metric_options = {
        "Base Salary ($)": "base_salary",
        "Total Annual Cost ($)": "total_annual_cost",
        "Annual Overtime Hours": "annual_overtime_hours",
        "Total Overtime Cost ($)": "total_overtime_cost",
        "Total Benefits Cost ($)": "total_benefits_cost",
        "Performance Rating (1-5)": "performance_rating",
        "Tenure (Years)": "tenure_years",
        "Age (Years)": "age",
        "Training Hours": "training_hours"
    }

    selected_label = st.selectbox("Select Dimension to Inspect:", list(metric_options.keys()), index=0)
    selected_col = metric_options[selected_label]

    stats_dict = calculate_statistical_summary(df, selected_col)
    if not stats_dict:
        render_alert("No numerical data points found for this dimension.", alert_type="warning")
        return

    # Stat cards row
    s1, s2, s3, s4, s5, s6 = st.columns(6)
    with s1:
        render_kpi_card("Mean (μ)", f"{stats_dict['mean']:,.1f}", "Sample Average", color_accent="indigo")
    with s2:
        render_kpi_card("Median", f"{stats_dict['median']:,.1f}", "50th Percentile", color_accent="cyan")
    with s3:
        render_kpi_card("Std Dev (σ)", f"{stats_dict['std']:,.1f}", "Dispersion", color_accent="slate")
    with s4:
        render_kpi_card("IQR", f"{stats_dict['iqr']:,.1f}", "Q3 - Q1 Spread", color_accent="emerald")
    with s5:
        skew_val = stats_dict['skewness']
        skew_type = "Right/Positive" if skew_val > 0.5 else ("Left/Negative" if skew_val < -0.5 else "Symmetric")
        render_kpi_card("Skewness", f"{skew_val:.2f}", skew_type, color_accent="amber")
    with s6:
        kurt_val = stats_dict['kurtosis']
        kurt_type = "Leptokurtic (Heavy)" if kurt_val > 1 else ("Platykurtic (Light)" if kurt_val < -1 else "Mesokurtic (Normal)")
        render_kpi_card("Kurtosis", f"{kurt_val:.2f}", kurt_type, color_accent="violet")

    # Histogram & Box distribution
    dist_c1, dist_c2 = st.columns([2, 1])
    with dist_c1:
        fig_hist = px.histogram(
            df,
            x=selected_col,
            nbins=min(35, max(5, len(df)//2)),
            marginal="box",
            color_discrete_sequence=[PALETTE['indigo']],
            title=f"Empirical Frequency Distribution: {selected_label}"
        )
        fig_hist.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            height=380,
            margin=dict(l=30, r=20, t=50, b=30)
        )
        st.plotly_chart(fig_hist, use_container_width=True)

    with dist_c2:
        quantiles = pd.DataFrame({
            "Metric": ["Min (0%)", "25th Percentile (Q1)", "Median (50%)", "75th Percentile (Q3)", "Max (100%)", "IQR", "Sample N"],
            "Value": [
                f"{stats_dict['min']:,.2f}",
                f"{stats_dict['q1']:,.2f}",
                f"{stats_dict['median']:,.2f}",
                f"{stats_dict['q3']:,.2f}",
                f"{stats_dict['max']:,.2f}",
                f"{stats_dict['iqr']:,.2f}",
                f"{stats_dict['count']:,}"
            ]
        })
        st.markdown("<div style='height: 1.5rem;'></div>", unsafe_allow_html=True)
        st.dataframe(quantiles, use_container_width=True, hide_index=True)

    # Section 2: Multivariate Correlation Matrix
    render_section_header("Multivariate Correlation Matrix", "Pearson correlation coefficients quantifying linear relationships across HR metrics")
    st.plotly_chart(chart_correlation_heatmap(df), use_container_width=True)

    # Section 3: Inferential Statistics & Hypothesis Testing Lab
    render_section_header("Inferential Hypothesis Testing Lab", "Formal statistical validation of workforce variance, pay equity, and turnover associations")

    test_tab1, test_tab2, test_tab3 = st.tabs([
        "1. One-Way ANOVA (Department vs Salary)",
        "2. Welch's T-Test (Gender Pay Equity)",
        "3. Chi-Square Test (Department vs Attrition)"
    ])

    with test_tab1:
        st.markdown(r"""
        **Hypothesis Formulation:**
        - **Null Hypothesis ($H_0$):** Mean base salaries are equal across all departments ($\mu_1 = \mu_2 = \dots = \mu_k$).
        - **Alternative Hypothesis ($H_1$):** At least one department has a significantly different mean base salary.
        """)
        anova_res = run_anova_salary_by_department(df)
        if "error" in anova_res:
            render_alert(
                f"ANOVA test requires at least 2 distinct departments with sufficient employees. (Note: Currently filtered to {df['department_name'].nunique()} department). Select 'All Departments' to compare across business units.",
                alert_type="info",
                title="Cross-Department Comparison Note"
            )
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                render_kpi_card("F-Statistic", f"{anova_res['f_statistic']:.3f}", "Between / Within Variance", color_accent="indigo")
            with c2:
                render_kpi_card("P-Value", f"{anova_res['p_value']:.4e}", "Significance Threshold: 0.05", color_accent="cyan")
            with c3:
                status_text = "Reject H0 (Significant)" if anova_res['is_significant'] else "Fail to Reject H0"
                render_kpi_card("Decision", status_text, "α = 0.05 Level", color_accent="emerald" if anova_res['is_significant'] else "slate")
            
            render_alert(anova_res['interpretation'], alert_type="info" if not anova_res['is_significant'] else "success", title="Statistical Interpretation")

    with test_tab2:
        st.markdown(r"""
        **Hypothesis Formulation:**
        - **Null Hypothesis ($H_0$):** There is no significant difference between the average base salaries of male and female employees ($\mu_{male} = \mu_{female}$).
        - **Alternative Hypothesis ($H_1$):** A statistically significant pay difference exists ($\mu_{male} \neq \mu_{female}$).
        """)
        ttest_res = run_ttest_gender_pay(df)
        if "error" in ttest_res:
            render_alert("Insufficient sample size for Male/Female cohorts in the current filtered subset.", alert_type="info")
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                render_kpi_card("t-Statistic", f"{ttest_res['t_statistic']:.3f}", "Welch's Two-Sample", color_accent="indigo")
            with c2:
                render_kpi_card("P-Value", f"{ttest_res['p_value']:.4e}", "Significance Threshold: 0.05", color_accent="cyan")
            with c3:
                status_text = "Significant Disparity" if ttest_res['is_significant'] else "Pay Equity Confirmed"
                render_kpi_card("Decision", status_text, f"Raw Gap: {ttest_res['pay_gap_pct']:.1f}%", color_accent="rose" if ttest_res['is_significant'] else "emerald")
            
            render_alert(ttest_res['interpretation'], alert_type="warning" if ttest_res['is_significant'] else "success", title="Statistical Interpretation")

    with test_tab3:
        st.markdown("""
        **Hypothesis Formulation:**
        - **Null Hypothesis ($H_0$):** Employee attrition is independent of the department.
        - **Alternative Hypothesis ($H_1$):** Attrition is dependent on the department.
        """)
        chi_res = run_chi_square_attrition_department(df)
        if "error" in chi_res:
            render_alert("Chi-square test requires data across multiple departments with both active and attrited personnel.", alert_type="info")
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                render_kpi_card("Chi² Statistic", f"{chi_res['chi2']:.3f}", f"Degrees of Freedom: {chi_res['dof']}", color_accent="indigo")
            with c2:
                render_kpi_card("P-Value", f"{chi_res['p_value']:.4e}", "Significance Threshold: 0.05", color_accent="cyan")
            with c3:
                status_text = "Dependent (Significant)" if chi_res['is_significant'] else "Independent (Uniform)"
                render_kpi_card("Decision", status_text, "α = 0.05 Level", color_accent="amber" if chi_res['is_significant'] else "slate")
            
            render_alert(chi_res['interpretation'], alert_type="warning" if chi_res['is_significant'] else "info", title="Statistical Interpretation")
