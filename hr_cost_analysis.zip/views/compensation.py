"""
views/compensation.py - Compensation, Benefits, and Overtime Analytics View
"""

import streamlit as st
import pandas as pd
from modules.ui_components import render_kpi_card, render_section_header, render_alert
from modules.analytics import calculate_core_kpis, run_ttest_gender_pay
from modules.charts import chart_salary_distribution_box, chart_overtime_heatmap

def render_compensation_view(df: pd.DataFrame):
    """Renders comprehensive compensation and payroll analysis."""
    kpis = calculate_core_kpis(df)
    if not kpis:
        st.warning("No data available.")
        return

    # Metric Row
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        render_kpi_card(
            title="Base Payroll",
            value=f"${kpis['total_base_payroll']/1e6:.2f}M",
            subtext=f"Mean: ${kpis['avg_base_salary']:,.0f}",
            icon="💵",
            color_accent="indigo"
        )
    with c2:
        render_kpi_card(
            title="Benefits & Perks",
            value=f"${kpis['total_benefits_cost']/1e6:.2f}M",
            subtext=f"{kpis['benefits_pct_base']:.1f}% of Base Payroll",
            icon="🛡️",
            color_accent="cyan"
        )
    with c3:
        render_kpi_card(
            title="Total Overtime",
            value=f"${kpis['total_overtime_cost']/1e3:,.0f}K",
            subtext=f"{kpis['total_overtime_hours']:,.0f} Total Hours",
            icon="⏳",
            color_accent="amber"
        )
    with c4:
        bonus_total = float(df['annual_bonus'].sum())
        render_kpi_card(
            title="Performance Bonus",
            value=f"${bonus_total/1e6:.2f}M",
            subtext=f"Avg: ${bonus_total/len(df):,.0f} / emp",
            icon="🎯",
            color_accent="emerald"
        )

    st.markdown("<div style='height: 1rem;'></div>", unsafe_allow_html=True)

    # Salary Dispersion Section
    render_section_header("Salary Dispersion Analysis", "Interactive distribution boxplots by organizational dimension")
    box_col, toggle_col = st.columns([3, 1])
    with toggle_col:
        grouping = st.radio(
            "Group Salary Distribution By:",
            ["Job Level", "Department", "Education", "Location"],
            index=0
        )
        col_map = {
            "Job Level": "job_level",
            "Department": "department_name",
            "Education": "education",
            "Location": "location"
        }
    with box_col:
        st.plotly_chart(chart_salary_distribution_box(df, group_col=col_map[grouping]), use_container_width=True)

    # Overtime Hotspots Heatmap
    render_section_header("Overtime Cost Hotspots", "Pinpoint departments and seniority tiers incurring heavy overtime expense")
    st.plotly_chart(chart_overtime_heatmap(df), use_container_width=True)

    # Pay Equity & Gender Comparison
    render_section_header("Pay Equity & Gender Disparity Analysis", "Auditing compensation fairness across demographic cohorts")
    ttest_res = run_ttest_gender_pay(df)

    p1, p2, p3 = st.columns([1, 1, 2])
    with p1:
        render_kpi_card(
            title="Male Avg Base Salary",
            value=f"${ttest_res.get('male_mean', 0):,.0f}",
            subtext="Baseline Cohort",
            icon="👨",
            color_accent="indigo"
        )
    with p2:
        render_kpi_card(
            title="Female Avg Base Salary",
            value=f"${ttest_res.get('female_mean', 0):,.0f}",
            subtext=f"Raw Gap: {ttest_res.get('pay_gap_pct', 0):.1f}%",
            icon="👩",
            color_accent="cyan"
        )
    with p3:
        if ttest_res.get("is_significant", False):
            render_alert(
                f"{ttest_res.get('interpretation')} Recommended action: Run multivariate regression controlling for tenure and job role to check for structural bias.",
                alert_type="warning",
                title="Statistical Pay Gap Detected"
            )
        else:
            render_alert(
                f"{ttest_res.get('interpretation')} No statistically significant disparity found between genders at p < 0.05.",
                alert_type="success",
                title="Pay Equity Validated"
            )

    # Top Overtime Cost Roles Table
    render_section_header("Top Overtime Burden Roles", "Roles accumulating highest aggregate overtime cost")
    ot_by_role = df.groupby(['job_role', 'department_name']).agg({
        'employee_id': 'count',
        'annual_overtime_hours': 'sum',
        'total_overtime_cost': 'sum'
    }).reset_index()
    ot_by_role.rename(columns={
        'job_role': 'Job Role',
        'department_name': 'Department',
        'employee_id': 'Headcount',
        'annual_overtime_hours': 'Total OT Hours',
        'total_overtime_cost': 'Total OT Cost ($)'
    }, inplace=True)
    ot_by_role = ot_by_role.sort_values(by='Total OT Cost ($)', ascending=False).head(8)
    st.dataframe(
        ot_by_role.style.format({
            'Total OT Hours': '{:,.1f}',
            'Total OT Cost ($)': '${:,.0f}'
        }),
        use_container_width=True,
        hide_index=True
    )
